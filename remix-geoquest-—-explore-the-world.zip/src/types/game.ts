export type Language = 'ar' | 'en' | 'tr';

export type ContinentId =
  | 'all'
  | 'africa'
  | 'asia'
  | 'europe'
  | 'north_america'
  | 'south_america'
  | 'oceania';

export type Difficulty = 'easy' | 'medium' | 'hard';
export type DifficultySetting = Difficulty | 'mixed';

export type GameMode =
  | 'quick_play'
  | 'world_challenge'
  | 'country_hunt'
  | 'capital_hunt'
  | 'landmark_hunt'
  | 'neighbor_challenge'
  | 'continents'
  | 'time_attack'
  | 'endless';

export type QuestionType =
  | 'country_locate'
  | 'country_north_of'
  | 'country_south_of'
  | 'capital_locate'
  | 'city_locate'
  | 'landmark'
  | 'wonder'
  | 'flag_region'
  | 'riddle'
  | 'neighbor_border'
  | 'neighbor_between'
  | 'sea'
  | 'ocean'
  | 'island'
  | 'river'
  | 'lake'
  | 'mountain'
  | 'desert'
  | 'strait';

export type QuestionCategoryId =
  | 'cat_capitals'
  | 'cat_borders'
  | 'cat_cities'
  | 'cat_landmarks'
  | 'cat_mountains_rivers'
  | 'cat_seas_islands'
  | 'cat_map_locate'
  | 'cat_flags_regions'
  | 'cat_wonders'
  | 'cat_riddles';

export interface QuestionCategoryDef {
  id: QuestionCategoryId;
  index: number;
  title: LocalizedText;
  description: LocalizedText;
  questionQuota: number; // e.g. 100000
}

export interface CityPoint {
  id: string;
  countryId?: string;
  name: LocalizedText;
  countryName: LocalizedText;
  continent: ContinentId;
  coordinates: [number, number];
  isCapital: boolean;
  fact: LocalizedText;
}

export type GameSpeed = 'relaxed' | 'normal' | 'fast';

export type GameScreen = 'TITLE_MENU' | 'PLAYING' | 'ATLAS_EXPLORE' | 'RESULTS';

export interface LocalizedText {
  ar: string;
  en: string;
  tr?: string;
}

export interface CountryMeta {
  id: string; // ISO 3166-1 numeric string matching world-atlas e.g. '392'
  name: LocalizedText;
  capital: LocalizedText;
  continent: Exclude<ContinentId, 'all'>;
  difficulty: Difficulty;
  center: [number, number]; // [lon, lat]
  capitalCoords: [number, number]; // [lon, lat]
  areaKm2?: number;
  neighbors: string[]; // Array of ISO numeric IDs
  northNeighbor?: string;
  southNeighbor?: string;
  betweenPair?: [string, string];
  fact: LocalizedText;
}

export interface LandmarkMeta {
  id: string;
  type:
    | 'sea'
    | 'ocean'
    | 'island'
    | 'river'
    | 'lake'
    | 'mountain'
    | 'desert'
    | 'strait'
    | 'city'
    | 'landmark'
    | 'wonder';
  name: LocalizedText;
  continent: ContinentId;
  difficulty: Difficulty;
  coordinates: [number, number]; // [lon, lat]
  toleranceKm: number;
  countryHint?: LocalizedText;
  directionHint: LocalizedText;
  fact: LocalizedText;
}

export interface GeoQuestion {
  id: string;
  question: LocalizedText;
  type: QuestionType;
  targetKind: 'country' | 'coordinate';
  correctAnswer: LocalizedText;
  targetCountryId?: string;
  flagCountryId?: string;
  validCountryIds?: string[]; // e.g. multiple valid bordering countries
  targetLocationName: LocalizedText;
  coordinates: [number, number]; // [lon, lat]
  toleranceKm: number;
  continent: ContinentId;
  difficulty: Difficulty;
  hints: LocalizedText[]; // 4 progressive hints
  points: number;
  fact: LocalizedText;
}

export interface GameSettings {
  language: Language;
  soundEnabled: boolean;
  volume: number; // 0 to 1
  darkMode: boolean;
  gameSpeed: GameSpeed;
  questionCount: number; // 5 | 10 | 20 | 50
  difficulty: DifficultySetting;
  youtubeUrl: string;
}

export interface AchievementDef {
  id: string;
  title: LocalizedText;
  description: LocalizedText;
  xpReward: number;
}

export interface RunHistoryItem {
  id: string;
  date: string;
  mode: GameMode;
  score: number;
  correctCount: number;
  totalQuestions: number;
  bestStreak: number;
}

export interface PlayerProfile {
  xp: number;
  gamesPlayed: number;
  totalCorrect: number;
  totalAnswered: number;
  bestScore: number;
  bestStreak: number;
  modeBestScores: Partial<Record<GameMode, number>>;
  unlockedAchievements: string[];
  continentsMastered: Exclude<ContinentId, 'all'>[];
  history: RunHistoryItem[];
}

export interface RoundResult {
  question: GeoQuestion;
  solved: boolean;
  skipped: boolean;
  timedOut: boolean;
  attemptsUsed: number;
  hintsUsed: number;
  pointsEarned: number;
  timeSpentSec: number;
  lastDistanceKm?: number;
  clickedCoords?: [number, number];
}

export interface MapMarker {
  id: string;
  coordinates: [number, number];
  kind: 'guess-wrong' | 'guess-correct' | 'target' | 'explore';
  label?: string;
}

export interface MapArc {
  from: [number, number];
  to: [number, number];
}
