import { useCallback, useEffect, useState } from 'react';
import {
  AchievementDef,
  ContinentId,
  DifficultySetting,
  GameMode,
  GameScreen,
  GameSettings,
  PlayerProfile,
  QuestionCategoryId,
  RoundResult,
} from './types/game';
import {
  loadProfile,
  loadSettings,
  recordCompletedRun,
  resetProfileStorage,
  saveSettings,
} from './utils/storage';
import { soundEngine } from './utils/sound';
import { TitleScreen } from './components/TitleScreen';
import { GamePlayScreen } from './components/GamePlayScreen';
import { AtlasExploreScreen, AtlasLayerMode } from './components/AtlasExploreScreen';
import { MapProjectionMode } from './components/map/WorldMap';
import { ResultsScreen } from './components/ResultsScreen';
import { ChallengesModal } from './components/ChallengesModal';
import { StatsModal } from './components/StatsModal';
import { SettingsModal } from './components/SettingsModal';

export default function App() {
  const [settings, setSettings] = useState<GameSettings>(() => loadSettings());
  const [profile, setProfile] = useState<PlayerProfile>(() => loadProfile());

  const [screen, setScreen] = useState<GameScreen>('TITLE_MENU');
  const [atlasLayer, setAtlasLayer] = useState<AtlasLayerMode>('both');
  const [atlasProjection, setAtlasProjection] =
    useState<MapProjectionMode>('mercator');
  const [activeMode, setActiveMode] = useState<GameMode>('quick_play');
  const [activeContinent, setActiveContinent] = useState<ContinentId>('all');
  const [activeDifficulty, setActiveDifficulty] =
    useState<DifficultySetting>('mixed');
  const [activeCategory, setActiveCategory] = useState<
    QuestionCategoryId | undefined
  >(undefined);
  const [runKey, setRunKey] = useState(1);

  const [showChallenges, setShowChallenges] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [showSettings, setShowSettings] = useState(false);

  const [lastRunSummary, setLastRunSummary] = useState<{
    score: number;
    runBestStreak: number;
    results: RoundResult[];
    xpEarned: number;
    newlyUnlocked: AchievementDef[];
  } | null>(null);

  // Sync HTML dir/lang/dark class and sound engine
  useEffect(() => {
    const html = document.documentElement;
    html.lang = settings.language;
    html.dir = settings.language === 'ar' ? 'rtl' : 'ltr';
    if (settings.darkMode) {
      html.classList.add('dark');
    } else {
      html.classList.remove('dark');
    }
    soundEngine.configure(settings.soundEnabled, settings.volume);
    saveSettings(settings);
  }, [settings]);

  const startGame = useCallback(
    (
      mode: GameMode,
      continent: ContinentId = 'all',
      difficulty: DifficultySetting = settings.difficulty,
      category?: QuestionCategoryId
    ) => {
      soundEngine.playClick();
      setActiveMode(mode);
      setActiveContinent(continent);
      setActiveDifficulty(difficulty);
      setActiveCategory(category);
      setRunKey((k) => k + 1);
      setShowChallenges(false);
      setScreen('PLAYING');
    },
    [settings.difficulty]
  );

  const handleFinishGame = useCallback(
    ({
      score,
      runBestStreak,
      results,
    }: {
      score: number;
      runBestStreak: number;
      results: RoundResult[];
    }) => {
      const outcome = recordCompletedRun({
        profile,
        mode: activeMode,
        continent: activeContinent,
        score,
        results,
        runBestStreak,
      });
      setProfile(outcome.updatedProfile);
      setLastRunSummary({
        score,
        runBestStreak,
        results,
        xpEarned: outcome.xpEarned,
        newlyUnlocked: outcome.newlyUnlocked,
      });
      setScreen('RESULTS');
    },
    [activeContinent, activeMode, profile]
  );

  return (
    <div className="min-h-screen w-full">
      {screen === 'TITLE_MENU' && (
        <TitleScreen
          settings={settings}
          profile={profile}
          onStartAdventure={() => setShowChallenges(true)}
          onQuickPlay={() => startGame('quick_play', 'all', settings.difficulty)}
          onOpenWorldMap={() => {
            soundEngine.playClick();
            setAtlasLayer('both');
            setAtlasProjection('mercator');
            setScreen('ATLAS_EXPLORE');
          }}
          onOpenCitiesMap={() => {
            soundEngine.playClick();
            setAtlasLayer('cities');
            setAtlasProjection('mercator');
            setScreen('ATLAS_EXPLORE');
          }}
          onOpenSphericalEarth={() => {
            soundEngine.playClick();
            setAtlasLayer('both');
            setAtlasProjection('globe');
            setScreen('ATLAS_EXPLORE');
          }}
          onOpenChallenges={() => {
            soundEngine.playClick();
            setShowChallenges(true);
          }}
          onOpenStats={() => {
            soundEngine.playClick();
            setShowStats(true);
          }}
          onOpenSettings={() => {
            soundEngine.playClick();
            setShowSettings(true);
          }}
          onToggleLanguage={() => {
            soundEngine.playClick();
            setSettings((s) => ({
              ...s,
              language:
                s.language === 'ar' ? 'en' : s.language === 'en' ? 'tr' : 'ar',
            }));
          }}
          onSelectLanguage={(language) => {
            soundEngine.playClick();
            setSettings((s) => ({ ...s, language }));
          }}
          onToggleSound={() => {
            setSettings((s) => ({ ...s, soundEnabled: !s.soundEnabled }));
          }}
        />
      )}

      {screen === 'PLAYING' && (
        <GamePlayScreen
          key={runKey}
          settings={settings}
          mode={activeMode}
          continent={activeContinent}
          difficulty={activeDifficulty}
          category={activeCategory}
          onFinishGame={handleFinishGame}
          onExitToMenu={() => setScreen('TITLE_MENU')}
        />
      )}

      {screen === 'ATLAS_EXPLORE' && (
        <AtlasExploreScreen
          settings={settings}
          initialLayer={atlasLayer}
          initialProjection={atlasProjection}
          onBack={() => setScreen('TITLE_MENU')}
        />
      )}

      {screen === 'RESULTS' && lastRunSummary && (
        <ResultsScreen
          settings={settings}
          profile={profile}
          mode={activeMode}
          score={lastRunSummary.score}
          runBestStreak={lastRunSummary.runBestStreak}
          results={lastRunSummary.results}
          xpEarned={lastRunSummary.xpEarned}
          newlyUnlocked={lastRunSummary.newlyUnlocked}
          onPlayAgain={() =>
            startGame(activeMode, activeContinent, activeDifficulty, activeCategory)
          }
          onBackHome={() => setScreen('TITLE_MENU')}
        />
      )}

      {showChallenges && (
        <ChallengesModal
          settings={settings}
          profile={profile}
          onClose={() => setShowChallenges(false)}
          onStartMode={(mode, cont, diff, cat) => startGame(mode, cont, diff, cat)}
        />
      )}

      {showStats && (
        <StatsModal
          settings={settings}
          profile={profile}
          onResetProfile={() => setProfile(resetProfileStorage())}
          onClose={() => setShowStats(false)}
        />
      )}

      {showSettings && (
        <SettingsModal
          settings={settings}
          onUpdateSettings={(next) => setSettings(next)}
          onClose={() => setShowSettings(false)}
        />
      )}
    </div>
  );
}
