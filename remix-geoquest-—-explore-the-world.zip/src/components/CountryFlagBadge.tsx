import React, { useState } from 'react';
import { getCountryAlpha2, getCountryFlagEmoji } from '../utils/countryFlags';

interface CountryFlagBadgeProps {
  countryId?: string | null;
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export const CountryFlagBadge: React.FC<CountryFlagBadgeProps> = ({
  countryId,
  size = 'md',
  className = '',
}) => {
  const [imgFailed, setImgFailed] = useState(false);

  const iso2 = getCountryAlpha2(countryId);
  const emoji = getCountryFlagEmoji(countryId);

  if (!iso2 && !emoji) return null;

  const sizeClass =
    size === 'sm'
      ? 'w-5 h-3.5'
      : size === 'lg'
      ? 'w-9 h-6'
      : 'w-6 h-4';

  if (!iso2 || imgFailed) {
    return (
      <span
        className={`inline-flex items-center justify-center leading-none shrink-0 ${
          size === 'lg' ? 'text-xl' : size === 'sm' ? 'text-sm' : 'text-base'
        } ${className}`}
        aria-hidden="true"
      >
        {emoji || '🏳️'}
      </span>
    );
  }

  return (
    <img
      src={`https://flagcdn.com/w40/${iso2}.png`}
      srcSet={`https://flagcdn.com/w80/${iso2}.png 2x`}
      alt=""
      loading="eager"
      onError={() => setImgFailed(true)}
      className={`${sizeClass} rounded-[3px] object-cover border border-slate-400/35 shadow-xs shrink-0 inline-block ${className}`}
    />
  );
};
