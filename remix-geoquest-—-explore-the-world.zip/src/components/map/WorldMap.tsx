import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { geoDistance, geoGraticule10, geoMercator, geoOrthographic, geoPath } from 'd3-geo';
import {
  ZoomIn,
  ZoomOut,
  RotateCcw,
  Compass,
  Satellite,
  Layers,
  Globe,
  Map as MapIcon,
  Moon,
  Hexagon,
  Loader2,
  Tag,
} from 'lucide-react';
import { CityPoint, ContinentId, Language, MapArc, MapMarker } from '../../types/game';
import { COUNTRY_BY_ID } from '../../data/countriesData';
import { CONTINENT_VIEWPORTS, formatCoords } from '../../utils/geoMath';
import {
  CONTINENT_LABELS,
  UI_TEXT,
  locCityCountryName,
  locCityName,
  locMapCountryName,
  t,
} from '../../data/i18n';
import {
  findCountryAtLonLat,
  NEIGHBOR_COLOR_PALETTE,
  RAW_COUNTRY_NAME_BY_ID,
  WORLD_COUNTRIES,
  WORLD_COUNTRIES_FAST,
} from '../../utils/worldTopology';
import {
  CityBoundaryFeature,
  fetchCityBoundariesForBbox,
  fetchCityBoundariesForCity,
} from '../../utils/cityBoundariesOverpass';
import { GlobeSatelliteCanvas } from './GlobeSatelliteCanvas';

export type MapProjectionMode = 'mercator' | 'globe';
export type MapStyleMode = 'satellite' | 'vector' | 'black';

// Web Mercator world circumference C = 1024 at k = 1, aligned to 256px XYZ tiles
const WORLD_SIZE = 1024;
const SVG_WIDTH = 1024;
const SVG_HEIGHT = 560;
const MERCATOR_CENTER_X = 512;
const MERCATOR_CENTER_Y = 320;
const GRID_ORIGIN_X = MERCATOR_CENTER_X - WORLD_SIZE / 2; // 0
const GRID_ORIGIN_Y = MERCATOR_CENTER_Y - WORLD_SIZE / 2; // -192

const GLOBE_BASE_RADIUS = 242;
const DEFAULT_GLOBE_ROT: [number, number] = [-26, -22];

const MIN_ZOOM = 1;
const MAX_ZOOM = 14;
const MAX_GLOBE_ZOOM = 10;

// Deterministic starfield for the Spherical Earth cosmic backdrop
const STARFIELD: Array<{ x: number; y: number; r: number; o: number }> = Array.from(
  { length: 72 },
  (_, i) => {
    const s1 = Math.sin(i * 12.9898) * 43758.5453;
    const s2 = Math.sin(i * 78.233 + 1.7) * 24634.6345;
    const fx = s1 - Math.floor(s1);
    const fy = s2 - Math.floor(s2);
    return {
      x: Math.round(fx * SVG_WIDTH * 10) / 10,
      y: Math.round(fy * SVG_HEIGHT * 10) / 10,
      r: i % 5 === 0 ? 1.35 : i % 2 === 0 ? 0.9 : 0.65,
      o: 0.25 + (i % 6) * 0.11,
    };
  }
);

const CITY_BOUNDARY_PALETTE = [
  { fill: 'rgba(245, 158, 11, 0.14)', stroke: '#FBBF24' },
  { fill: 'rgba(14, 165, 233, 0.14)', stroke: '#38BDF8' },
  { fill: 'rgba(16, 185, 129, 0.14)', stroke: '#34D399' },
  { fill: 'rgba(168, 85, 247, 0.14)', stroke: '#C084FC' },
  { fill: 'rgba(244, 63, 94, 0.13)', stroke: '#FB7185' },
  { fill: 'rgba(20, 184, 166, 0.14)', stroke: '#2DD4BF' },
];

export interface MapClickPayload {
  coordinates: [number, number]; // [lon, lat]
  countryId: string | null;
  countryNameRaw: string | null;
}

interface WorldMapProps {
  language: Language;
  darkMode: boolean;
  interactive?: boolean;
  ambientMode?: boolean;
  showClouds?: boolean;
  showCountryNames?: boolean;
  showCountryNamesToggle?: boolean;
  showCountryNamesOnHover?: boolean;
  showContinentBar?: boolean;
  showCityPins?: boolean;
  showCityNames?: boolean;
  defaultShowCityBoundaries?: boolean;
  selectedCityForBoundaries?: CityPoint | null;
  highlightedCityCountryId?: string | null;
  cityPoints?: CityPoint[];
  selectedCityId?: string | null;
  projectionMode?: MapProjectionMode;
  defaultProjectionMode?: MapProjectionMode;
  onProjectionModeChange?: (mode: MapProjectionMode) => void;
  focusTarget?: { center: [number, number]; zoom: number; key: number } | null;
  highlightedCountryIds?: string[];
  wrongCountryIds?: string[];
  secondaryHighlightIds?: string[];
  markers?: MapMarker[];
  arc?: MapArc | null;
  onMapClick?: (payload: MapClickPayload) => void;
  onCityClick?: (city: CityPoint) => void;
  className?: string;
}

interface SatelliteTile {
  key: string;
  url: string;
  x: number;
  y: number;
  size: number;
}

function getVisibleTiles(
  z: number,
  transform: { x: number; y: number; k: number }
): SatelliteTile[] {
  const n = Math.pow(2, z);
  const tileSize = WORLD_SIZE / n;

  const minWorldX =
    (0 - SVG_WIDTH / 2 - transform.x) / transform.k + SVG_WIDTH / 2;
  const maxWorldX =
    (SVG_WIDTH - SVG_WIDTH / 2 - transform.x) / transform.k + SVG_WIDTH / 2;
  const minWorldY =
    (0 - SVG_HEIGHT / 2 - transform.y) / transform.k + SVG_HEIGHT / 2;
  const maxWorldY =
    (SVG_HEIGHT - SVG_HEIGHT / 2 - transform.y) / transform.k + SVG_HEIGHT / 2;

  const minTx = Math.max(0, Math.floor((minWorldX - GRID_ORIGIN_X) / tileSize));
  const maxTx = Math.min(
    n - 1,
    Math.floor((maxWorldX - GRID_ORIGIN_X) / tileSize)
  );
  const minTy = Math.max(0, Math.floor((minWorldY - GRID_ORIGIN_Y) / tileSize));
  const maxTy = Math.min(
    n - 1,
    Math.floor((maxWorldY - GRID_ORIGIN_Y) / tileSize)
  );

  const tiles: SatelliteTile[] = [];
  for (let ty = minTy; ty <= maxTy; ty++) {
    for (let tx = minTx; tx <= maxTx; tx++) {
      tiles.push({
        key: `${z}-${tx}-${ty}`,
        url: `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${ty}/${tx}`,
        x: GRID_ORIGIN_X + tx * tileSize,
        y: GRID_ORIGIN_Y + ty * tileSize,
        size: tileSize,
      });
    }
  }
  return tiles;
}

function shortestAngleDelta(from: number, to: number): number {
  let d = ((to - from + 540) % 360) - 180;
  if (d < -180) d += 360;
  return d;
}

const EMPTY_STRING_ARRAY: string[] = [];
const EMPTY_CITY_POINTS: CityPoint[] = [];
const EMPTY_MARKERS: MapMarker[] = [];

export const WorldMap: React.FC<WorldMapProps> = ({
  language,
  darkMode,
  interactive = true,
  ambientMode = false,
  showClouds = true,
  showCountryNames = false,
  showCountryNamesToggle = false,
  showCountryNamesOnHover = false,
  showContinentBar = false,
  showCityPins = false,
  showCityNames = true,
  defaultShowCityBoundaries = false,
  selectedCityForBoundaries = null,
  highlightedCityCountryId = null,
  cityPoints = EMPTY_CITY_POINTS,
  selectedCityId = null,
  projectionMode: controlledProjection,
  defaultProjectionMode = 'mercator',
  onProjectionModeChange,
  focusTarget = null,
  highlightedCountryIds = EMPTY_STRING_ARRAY,
  wrongCountryIds = EMPTY_STRING_ARRAY,
  secondaryHighlightIds = EMPTY_STRING_ARRAY,
  markers = EMPTY_MARKERS,
  arc = null,
  onMapClick,
  onCityClick,
  className = '',
}) => {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const globeOverlayCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const mercatorCityCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const animFrameRef = useRef<number | null>(null);
  const lastHoverCheckRef = useRef<number>(0);

  const [containerSize, setContainerSize] = useState<{ w: number; h: number }>({
    w: 1024,
    h: 560,
  });

  useEffect(() => {
    const el = containerRef.current;
    if (!el || typeof ResizeObserver === 'undefined') return;
    const update = () => {
      const rect = el.getBoundingClientRect();
      if (rect.width > 0 && rect.height > 0) {
        setContainerSize((prev) =>
          Math.abs(prev.w - rect.width) < 0.5 && Math.abs(prev.h - rect.height) < 0.5
            ? prev
            : { w: rect.width, h: rect.height }
        );
      }
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const [internalProjection, setInternalProjection] =
    useState<MapProjectionMode>(defaultProjectionMode);
  const activeProjectionMode = controlledProjection ?? internalProjection;
  const isGlobe = activeProjectionMode === 'globe';

  const setProjectionMode = useCallback(
    (next: MapProjectionMode) => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      if (controlledProjection === undefined) {
        setInternalProjection(next);
      }
      onProjectionModeChange?.(next);
    },
    [controlledProjection, onProjectionModeChange]
  );

  const [mapStyle, setMapStyle] = useState<MapStyleMode>('satellite');
  const satelliteMode = mapStyle === 'satellite';
  const isBlackMap = mapStyle === 'black';
  const [globeTextureReady, setGlobeTextureReady] = useState(false);
  const [isGlobeInteracting, setIsGlobeInteracting] = useState(false);
  const [showCityBoundaries, setShowCityBoundaries] = useState<boolean>(
    Boolean(defaultShowCityBoundaries)
  );
  const [cityBoundaries, setCityBoundaries] = useState<CityBoundaryFeature[]>([]);
  const [cityBoundariesLoading, setCityBoundariesLoading] = useState<boolean>(false);
  const [countryNamesEnabled, setCountryNamesEnabled] = useState<boolean>(
    Boolean(showCountryNames)
  );

  useEffect(() => {
    setShowCityBoundaries(Boolean(defaultShowCityBoundaries));
  }, [defaultShowCityBoundaries]);

  useEffect(() => {
    setCountryNamesEnabled(Boolean(showCountryNames));
  }, [showCountryNames]);

  // Flat Mercator pan/zoom state
  const [transform, setTransform] = useState<{ x: number; y: number; k: number }>({
    x: 0,
    y: 0,
    k: 1,
  });
  const transformRef = useRef(transform);
  transformRef.current = transform;

  // 3D Spherical Earth rotation, zoom & cloud drift state
  const [globeState, setGlobeState] = useState<{
    rot: [number, number];
    zoom: number;
    cloudDrift?: number;
  }>({
    rot: DEFAULT_GLOBE_ROT,
    zoom: 1,
    cloudDrift: 0,
  });
  const globeRef = useRef(globeState);
  globeRef.current = globeState;

  const [activeContinent, setActiveContinent] = useState<ContinentId>('all');
  const [hoveredCountry, setHoveredCountry] = useState<{
    id: string;
    name: string;
  } | null>(null);
  const [hoveredCity, setHoveredCity] = useState<CityPoint | null>(null);
  const [pointerCoords, setPointerCoords] = useState<[number, number] | null>(null);
  const [cursorScreenPos, setCursorScreenPos] = useState<{ x: number; y: number } | null>(null);

  // Drag state
  const dragState = useRef<{
    isDown: boolean;
    startClientX: number;
    startClientY: number;
    startTx: number;
    startTy: number;
    startRot: [number, number];
    moved: boolean;
    pointerId: number | null;
  }>({
    isDown: false,
    startClientX: 0,
    startClientY: 0,
    startTx: 0,
    startTy: 0,
    startRot: DEFAULT_GLOBE_ROT,
    moved: false,
    pointerId: null,
  });

  // Web Mercator projection aligned 1:1 with XYZ Satellite tiles
  const mercatorProjection = useMemo(() => {
    return geoMercator()
      .scale(WORLD_SIZE / (2 * Math.PI))
      .translate([MERCATOR_CENTER_X, MERCATOR_CENTER_Y]);
  }, []);

  // 3D Spherical Earth Orthographic projection
  const globeProjection = useMemo(() => {
    return geoOrthographic()
      .scale(GLOBE_BASE_RADIUS * globeState.zoom)
      .translate([SVG_WIDTH / 2, SVG_HEIGHT / 2])
      .rotate([globeState.rot[0], globeState.rot[1], 0])
      .clipAngle(90);
  }, [globeState.rot, globeState.zoom]);

  const activeProjection = isGlobe ? globeProjection : mercatorProjection;
  const pathGen = useMemo(() => geoPath(activeProjection), [activeProjection]);

  // Project country paths, graticule, and globe sphere outline for Flat Mercator SVG only.
  // Globe mode draws directly onto a HiDPI Canvas2D overlay so rotation/zoom stays 60fps.
  const { countryPaths, graticulePath } = useMemo(() => {
    if (isGlobe) {
      return { countryPaths: [], graticulePath: '' };
    }
    const paths = WORLD_COUNTRIES
      .map((item) => ({
        key: item.key,
        id: item.id,
        rawName: item.rawName,
        d: pathGen(item.feat) || '',
      }))
      .filter((p) => p.d.length > 0);

    const grat = pathGen(geoGraticule10()) || '';
    return { countryPaths: paths, graticulePath: grat };
  }, [isGlobe, pathGen]);

  // Visibility test on the visible front hemisphere of the Spherical Earth
  const isGeoVisible = useCallback(
    (coords: [number, number]): boolean => {
      if (!isGlobe) return true;
      const center: [number, number] = [-globeState.rot[0], -globeState.rot[1]];
      return geoDistance(coords, center) <= Math.PI / 2 - 0.015;
    },
    [globeState.rot, isGlobe]
  );

  // Clamp Mercator translation so flat map stays framed
  const clampTransform = useCallback(
    (x: number, y: number, k: number): { x: number; y: number; k: number } => {
      const clampedK = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, k));
      if (clampedK <= 1.01) {
        return { x: 0, y: 0, k: 1 };
      }
      const maxPanX = (SVG_WIDTH * (clampedK - 1)) / 2 + 120;
      const maxPanY = (SVG_HEIGHT * (clampedK - 1)) / 2 + 110;
      return {
        x: Math.max(-maxPanX, Math.min(maxPanX, x)),
        y: Math.max(-maxPanY, Math.min(maxPanY, y)),
        k: clampedK,
      };
    },
    []
  );

  // Smooth animated Mercator pan/zoom
  const animateTo = useCallback(
    (target: { x: number; y: number; k: number }, durationMs = 420) => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
      const start = { ...transformRef.current };
      const clampedTarget = clampTransform(target.x, target.y, target.k);
      const startTime = performance.now();

      const step = (now: number) => {
        const elapsed = now - startTime;
        const tNorm = Math.min(1, elapsed / durationMs);
        const ease = 1 - Math.pow(1 - tNorm, 3);
        const next = {
          x: start.x + (clampedTarget.x - start.x) * ease,
          y: start.y + (clampedTarget.y - start.y) * ease,
          k: start.k + (clampedTarget.k - start.k) * ease,
        };
        setTransform(next);
        if (tNorm < 1) {
          animFrameRef.current = requestAnimationFrame(step);
        } else {
          animFrameRef.current = null;
        }
      };
      animFrameRef.current = requestAnimationFrame(step);
    },
    [clampTransform]
  );

  // Smooth animated Spherical Earth rotation & zoom
  const animateGlobeTo = useCallback(
    (targetRot: [number, number], targetZoom: number, durationMs = 540) => {
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
      }
      setIsGlobeInteracting(true);
      const start = {
        rot: [...globeRef.current.rot] as [number, number],
        zoom: globeRef.current.zoom,
      };
      const clampedZoom = Math.max(1, Math.min(MAX_GLOBE_ZOOM, targetZoom));
      const clampedPhi = Math.max(-82, Math.min(82, targetRot[1]));
      const dLambda = shortestAngleDelta(start.rot[0], targetRot[0]);
      const dPhi = clampedPhi - start.rot[1];
      const startTime = performance.now();

      const step = (now: number) => {
        const elapsed = now - startTime;
        const tNorm = Math.min(1, elapsed / durationMs);
        const ease = 1 - Math.pow(1 - tNorm, 3);
        setGlobeState({
          rot: [start.rot[0] + dLambda * ease, start.rot[1] + dPhi * ease],
          zoom: start.zoom + (clampedZoom - start.zoom) * ease,
        });
        if (tNorm < 1) {
          animFrameRef.current = requestAnimationFrame(step);
        } else {
          animFrameRef.current = null;
          setIsGlobeInteracting(false);
        }
      };
      animFrameRef.current = requestAnimationFrame(step);
    },
    []
  );

  // Focus on specific lon/lat + zoom in active projection
  const focusOnCoords = useCallback(
    (center: [number, number], zoom: number) => {
      if (isGlobe) {
        const globeTargetZoom = Math.max(1, Math.min(MAX_GLOBE_ZOOM, zoom));
        animateGlobeTo([-center[0], -center[1]], globeTargetZoom, 560);
        return;
      }
      const projected = mercatorProjection(center);
      if (!projected) return;
      const [px, py] = projected;
      const tx = (SVG_WIDTH / 2 - px) * zoom;
      const ty = (SVG_HEIGHT / 2 - py) * zoom;
      animateTo({ x: tx, y: ty, k: zoom }, 520);
    },
    [animateGlobeTo, animateTo, isGlobe, mercatorProjection]
  );

  const lastAppliedFocusRef = useRef<string | null>(null);

  useEffect(() => {
    if (!focusTarget) {
      lastAppliedFocusRef.current = null;
      return;
    }
    const token = `${focusTarget.key}:${isGlobe ? 'g' : 'm'}`;
    if (lastAppliedFocusRef.current === token) return;
    lastAppliedFocusRef.current = token;
    focusOnCoords(focusTarget.center, focusTarget.zoom);
  }, [focusTarget, focusOnCoords, isGlobe]);

  // Ambient drifting pan/spin on Title Screen
  useEffect(() => {
    if (!ambientMode) return;
    let frameId: number;
    const startTime = performance.now();
    const loop = (now: number) => {
      const sec = (now - startTime) / 1000;
      if (isGlobe) {
        setGlobeState({
          rot: [-22 - sec * 7.5, -16 + Math.sin(sec * 0.25) * 9],
          zoom: 1.06,
          cloudDrift: sec * 3.8,
        });
      } else {
        const lon = Math.sin(sec * 0.08) * 42 + 12;
        const lat = Math.cos(sec * 0.06) * 14 + 18;
        const projected = mercatorProjection([lon, lat]);
        if (projected) {
          const k = 1.85;
          setTransform({
            x: (SVG_WIDTH / 2 - projected[0]) * k,
            y: (SVG_HEIGHT / 2 - projected[1]) * k,
            k,
          });
        }
      }
      frameId = requestAnimationFrame(loop);
    };
    frameId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(frameId);
  }, [ambientMode, isGlobe, mercatorProjection]);

  useEffect(() => {
    return () => {
      if (animFrameRef.current) cancelAnimationFrame(animFrameRef.current);
    };
  }, []);

  const boundaryViewportKey =
    !showCityPins || !showCityBoundaries || ambientMode
      ? 'off'
      : selectedCityForBoundaries
      ? `city:${selectedCityForBoundaries.id}`
      : isGlobe
      ? globeState.zoom >= 2.3
        ? `g:${Math.round(globeState.rot[0] * 4)}:${Math.round(globeState.rot[1] * 4)}:${Math.round(globeState.zoom * 5)}`
        : 'unzoomed'
      : transform.k >= 2.8
      ? `m:${Math.round(transform.x / 8)}:${Math.round(transform.y / 8)}:${Math.round(transform.k * 5)}`
      : 'unzoomed';

  // Fetch real OpenStreetMap administrative city/district boundaries via Overpass API
  useEffect(() => {
    if (boundaryViewportKey === 'off' || boundaryViewportKey === 'unzoomed') {
      setCityBoundaries((prev) => (prev.length === 0 ? prev : []));
      setCityBoundariesLoading((prev) => (prev ? false : prev));
      return;
    }

    const controller = new AbortController();
    let timerId: number | null = null;

    if (selectedCityForBoundaries) {
      setCityBoundariesLoading((prev) => (prev ? prev : true));
      timerId = window.setTimeout(() => {
        fetchCityBoundariesForCity(selectedCityForBoundaries, controller.signal)
          .then((items) => {
            if (!controller.signal.aborted) {
              setCityBoundaries(items);
              setCityBoundariesLoading(false);
            }
          })
          .catch(() => {
            if (!controller.signal.aborted) {
              setCityBoundariesLoading(false);
            }
          });
      }, 140);

      return () => {
        controller.abort();
        if (timerId !== null) window.clearTimeout(timerId);
      };
    }

    timerId = window.setTimeout(() => {
      let south = 0;
      let north = 0;
      let west = 0;
      let east = 0;

      if (isGlobe) {
        const gCur = globeRef.current;
        const centerLon = -gCur.rot[0];
        const centerLat = -gCur.rot[1];
        const halfLat = Math.min(3.2, Math.max(0.45, 9.2 / gCur.zoom));
        const cosLat = Math.max(0.28, Math.cos((centerLat * Math.PI) / 180));
        const halfLon = Math.min(4.6, halfLat / cosLat);
        south = Math.max(-84, centerLat - halfLat);
        north = Math.min(84, centerLat + halfLat);
        west = Math.max(-180, centerLon - halfLon);
        east = Math.min(180, centerLon + halfLon);
      } else {
        const tCur = transformRef.current;
        const minWorldX =
          (SVG_WIDTH * 0.14 - SVG_WIDTH / 2 - tCur.x) / tCur.k + SVG_WIDTH / 2;
        const maxWorldX =
          (SVG_WIDTH * 0.86 - SVG_WIDTH / 2 - tCur.x) / tCur.k + SVG_WIDTH / 2;
        const minWorldY =
          (SVG_HEIGHT * 0.14 - SVG_HEIGHT / 2 - tCur.y) / tCur.k + SVG_HEIGHT / 2;
        const maxWorldY =
          (SVG_HEIGHT * 0.86 - SVG_HEIGHT / 2 - tCur.y) / tCur.k + SVG_HEIGHT / 2;
        const nw = mercatorProjection.invert?.([minWorldX, minWorldY]);
        const se = mercatorProjection.invert?.([maxWorldX, maxWorldY]);
        if (!nw || !se) return;
        const centerLat = (nw[1] + se[1]) / 2;
        const centerLon = (nw[0] + se[0]) / 2;
        const halfLat = Math.min(3.4, Math.abs(nw[1] - se[1]) / 2);
        const halfLon = Math.min(4.8, Math.abs(se[0] - nw[0]) / 2);
        south = Math.max(-84, centerLat - halfLat);
        north = Math.min(84, centerLat + halfLat);
        west = Math.max(-180, centerLon - halfLon);
        east = Math.min(180, centerLon + halfLon);
      }

      if (north - south < 0.05 || east - west < 0.05) return;

      setCityBoundariesLoading(true);
      fetchCityBoundariesForBbox(south, west, north, east, controller.signal)
        .then((items) => {
          if (!controller.signal.aborted) {
            setCityBoundaries(items);
            setCityBoundariesLoading(false);
          }
        })
        .catch(() => {
          if (!controller.signal.aborted) {
            setCityBoundariesLoading(false);
          }
        });
    }, 520);

    return () => {
      controller.abort();
      if (timerId !== null) window.clearTimeout(timerId);
    };
  }, [
    boundaryViewportKey,
    isGlobe,
    mercatorProjection,
    selectedCityForBoundaries,
  ]);

  // Convert client screen coordinates to internal 1024x560 map space
  const clientToSvgCoords = useCallback(
    (clientX: number, clientY: number): { x: number; y: number } | null => {
      if (isGlobe) {
        const canvas = globeOverlayCanvasRef.current;
        if (!canvas) return null;
        const rect = canvas.getBoundingClientRect();
        if (rect.width <= 0 || rect.height <= 0) return null;
        return {
          x: ((clientX - rect.left) / rect.width) * SVG_WIDTH,
          y: ((clientY - rect.top) / rect.height) * SVG_HEIGHT,
        };
      }
      const svg = svgRef.current;
      if (!svg) return null;
      const ctm = svg.getScreenCTM();
      if (!ctm) return null;
      const pt = svg.createSVGPoint();
      pt.x = clientX;
      pt.y = clientY;
      const svgPt = pt.matrixTransform(ctm.inverse());
      return { x: svgPt.x, y: svgPt.y };
    },
    [isGlobe]
  );

  // Convert client screen position to geographic [lon, lat]
  const clientToMapCoords = useCallback(
    (clientX: number, clientY: number): [number, number] | null => {
      const svgPt = clientToSvgCoords(clientX, clientY);
      if (!svgPt) return null;

      if (isGlobe) {
        const distFromCenter = Math.hypot(
          svgPt.x - SVG_WIDTH / 2,
          svgPt.y - SVG_HEIGHT / 2
        );
        if (distFromCenter > GLOBE_BASE_RADIUS * globeRef.current.zoom) {
          return null;
        }
        const inverted = globeProjection.invert?.([svgPt.x, svgPt.y]);
        if (
          !inverted ||
          Number.isNaN(inverted[0]) ||
          Number.isNaN(inverted[1])
        ) {
          return null;
        }
        return [inverted[0], inverted[1]];
      }

      const { x, y, k } = transformRef.current;
      const mapX = (svgPt.x - SVG_WIDTH / 2 - x) / k + SVG_WIDTH / 2;
      const mapY = (svgPt.y - SVG_HEIGHT / 2 - y) / k + SVG_HEIGHT / 2;
      const inverted = mercatorProjection.invert?.([mapX, mapY]);
      if (!inverted || Number.isNaN(inverted[0]) || Number.isNaN(inverted[1])) {
        return null;
      }
      return [inverted[0], inverted[1]];
    },
    [clientToSvgCoords, globeProjection, isGlobe, mercatorProjection]
  );

  // Zoom around SVG center or pointer
  const handleZoomBy = useCallback(
    (factor: number, clientX?: number, clientY?: number) => {
      if (!interactive) return;

      if (isGlobe) {
        const cur = globeRef.current;
        const nextZoom = Math.max(1, Math.min(MAX_GLOBE_ZOOM, cur.zoom * factor));
        if (nextZoom === cur.zoom) return;
        if (clientX !== undefined) {
          setGlobeState({ rot: cur.rot, zoom: nextZoom });
        } else {
          animateGlobeTo(cur.rot, nextZoom, 240);
        }
        return;
      }

      const cur = transformRef.current;
      const nextK = Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, cur.k * factor));
      if (nextK === cur.k) return;

      if (clientX !== undefined && clientY !== undefined && svgRef.current) {
        const ctm = svgRef.current.getScreenCTM();
        if (ctm) {
          const pt = svgRef.current.createSVGPoint();
          pt.x = clientX;
          pt.y = clientY;
          const svgPt = pt.matrixTransform(ctm.inverse());
          const dx = svgPt.x - SVG_WIDTH / 2;
          const dy = svgPt.y - SVG_HEIGHT / 2;
          const scaleRatio = nextK / cur.k;
          const nextX = dx - (dx - cur.x) * scaleRatio;
          const nextY = dy - (dy - cur.y) * scaleRatio;
          setTransform(clampTransform(nextX, nextY, nextK));
          return;
        }
      }

      const scaleRatio = nextK / cur.k;
      animateTo(
        {
          x: cur.x * scaleRatio,
          y: cur.y * scaleRatio,
          k: nextK,
        },
        220
      );
    },
    [animateGlobeTo, animateTo, clampTransform, interactive, isGlobe]
  );

  const handleWheel = useCallback(
    (e: React.WheelEvent<HTMLElement | SVGSVGElement>) => {
      if (!interactive) return;
      e.preventDefault();
      const factor = e.deltaY < 0 ? 1.22 : 0.82;
      handleZoomBy(factor, e.clientX, e.clientY);
    },
    [handleZoomBy, interactive]
  );

  const handlePointerDown = useCallback(
    (e: React.PointerEvent<HTMLElement | SVGSVGElement>) => {
      if (!interactive || e.button !== 0) return;
      if (animFrameRef.current) {
        cancelAnimationFrame(animFrameRef.current);
        animFrameRef.current = null;
      }
      dragState.current = {
        isDown: true,
        startClientX: e.clientX,
        startClientY: e.clientY,
        startTx: transformRef.current.x,
        startTy: transformRef.current.y,
        startRot: [...globeRef.current.rot] as [number, number],
        moved: false,
        pointerId: e.pointerId,
      };
    },
    [interactive]
  );

  const mercatorCityEntries = useMemo(() => {
    if (cityPoints.length === 0) return [];
    const out: Array<{ city: CityPoint; wx: number; wy: number }> = [];
    for (const city of cityPoints) {
      const pt = mercatorProjection(city.coordinates);
      if (!pt) continue;
      out.push({ city, wx: pt[0], wy: pt[1] });
    }
    return out;
  }, [cityPoints, mercatorProjection]);

  const findNearestVisibleGlobeCity = useCallback(
    (svgX: number, svgY: number, maxDist = 11): CityPoint | null => {
      if (!showCityPins || cityPoints.length === 0) return null;
      let best: CityPoint | null = null;
      let bestDist = maxDist;
      const center: [number, number] = [-globeRef.current.rot[0], -globeRef.current.rot[1]];

      for (const city of cityPoints) {
        if (geoDistance(city.coordinates, center) > Math.PI / 2 - 0.015) continue;
        const pt = globeProjection(city.coordinates);
        if (!pt) continue;
        const d = Math.hypot(pt[0] - svgX, pt[1] - svgY);
        if (d < bestDist) {
          bestDist = d;
          best = city;
        }
      }
      return best;
    },
    [cityPoints, globeProjection, showCityPins]
  );

  const findNearestVisibleMercatorCity = useCallback(
    (svgX: number, svgY: number, maxDist = 10): CityPoint | null => {
      if (!showCityPins || mercatorCityEntries.length === 0) return null;
      const { x, y, k } = transformRef.current;
      let best: CityPoint | null = null;
      let bestDist = maxDist;
      for (const entry of mercatorCityEntries) {
        const sx = (entry.wx - SVG_WIDTH / 2) * k + SVG_WIDTH / 2 + x;
        const sy = (entry.wy - SVG_HEIGHT / 2) * k + SVG_HEIGHT / 2 + y;
        if (sx < -20 || sx > SVG_WIDTH + 20 || sy < -20 || sy > SVG_HEIGHT + 20) continue;
        const d = Math.hypot(sx - svgX, sy - svgY);
        if (d < bestDist) {
          bestDist = d;
          best = entry.city;
        }
      }
      return best;
    },
    [mercatorCityEntries, showCityPins]
  );

  const handlePointerMove = useCallback(
    (e: React.PointerEvent<HTMLElement | SVGSVGElement>) => {
      if (!interactive) return;

      if (dragState.current.isDown) {
        const dxScreen = e.clientX - dragState.current.startClientX;
        const dyScreen = e.clientY - dragState.current.startClientY;
        if (Math.hypot(dxScreen, dyScreen) > 5) {
          dragState.current.moved = true;
        }

        if (dragState.current.moved) {
          const targetEl = isGlobe ? globeOverlayCanvasRef.current : svgRef.current;
          if (!targetEl) return;
          const rect = targetEl.getBoundingClientRect();
          const scaleX = SVG_WIDTH / Math.max(1, rect.width);
          const scaleY = SVG_HEIGHT / Math.max(1, rect.height);

          if (isGlobe) {
            setIsGlobeInteracting(true);
            const uniformScale = Math.min(scaleX, scaleY);
            const sensitivity = 92 / (GLOBE_BASE_RADIUS * globeRef.current.zoom);
            const nextLambda =
              dragState.current.startRot[0] + dxScreen * uniformScale * sensitivity;
            const nextPhi = Math.max(
              -82,
              Math.min(
                82,
                dragState.current.startRot[1] - dyScreen * uniformScale * sensitivity
              )
            );
            setGlobeState((prev) => ({
              ...prev,
              rot: [nextLambda, nextPhi],
            }));
            return;
          }

          const uniformScale = Math.max(scaleX, scaleY);
          const next = clampTransform(
            dragState.current.startTx + dxScreen * uniformScale,
            dragState.current.startTy + dyScreen * uniformScale,
            transformRef.current.k
          );
          setTransform(next);
        }
        return;
      }

      if (isGlobe) {
        const now = performance.now();
        if (now - lastHoverCheckRef.current < 45) return;
        lastHoverCheckRef.current = now;

        const svgPt = clientToSvgCoords(e.clientX, e.clientY);
        const geo = clientToMapCoords(e.clientX, e.clientY);
        setPointerCoords(geo);
        setCursorScreenPos(geo ? { x: e.clientX, y: e.clientY } : null);

        if (!geo || !svgPt) {
          setHoveredCity(null);
          setHoveredCountry(null);
          return;
        }

        const cityHit = findNearestVisibleGlobeCity(svgPt.x, svgPt.y, 10);
        setHoveredCity(cityHit);

        if (!cityHit && showCountryNamesOnHover) {
          const countryHit = findCountryAtLonLat(geo);
          if (countryHit) {
            const localizedName = locMapCountryName(
              countryHit.id,
              RAW_COUNTRY_NAME_BY_ID[countryHit.id] || countryHit.rawName,
              language
            );
            setHoveredCountry({ id: countryHit.id, name: localizedName });
          } else {
            setHoveredCountry(null);
          }
        } else if (cityHit) {
          setHoveredCountry(null);
        }
        return;
      }

      const now = performance.now();
      const shouldCheckHover = now - lastHoverCheckRef.current >= 45;
      if (shouldCheckHover) {
        lastHoverCheckRef.current = now;
      }

      const geo = clientToMapCoords(e.clientX, e.clientY);
      setPointerCoords(geo);
      setCursorScreenPos({ x: e.clientX, y: e.clientY });

      if (shouldCheckHover && showCityPins) {
        const svgPt = clientToSvgCoords(e.clientX, e.clientY);
        if (svgPt) {
          const cityHit = findNearestVisibleMercatorCity(svgPt.x, svgPt.y, 9);
          setHoveredCity(cityHit);
          if (cityHit) setHoveredCountry(null);
        }
      }
    },
    [
      clampTransform,
      clientToMapCoords,
      clientToSvgCoords,
      findNearestVisibleGlobeCity,
      findNearestVisibleMercatorCity,
      interactive,
      isGlobe,
      language,
      showCityPins,
      showCountryNamesOnHover,
    ]
  );

  const handlePointerUp = useCallback(
    (e: React.PointerEvent<HTMLElement | SVGSVGElement>) => {
      if (!interactive) return;
      const wasDrag = dragState.current.moved;
      dragState.current.isDown = false;
      dragState.current.moved = false;
      setIsGlobeInteracting(false);

      if (!wasDrag) {
        if (isGlobe) {
          const svgPt = clientToSvgCoords(e.clientX, e.clientY);
          if (svgPt && onCityClick) {
            const cityHit = findNearestVisibleGlobeCity(svgPt.x, svgPt.y, 11);
            if (cityHit) {
              onCityClick(cityHit);
              return;
            }
          }
          if (onMapClick) {
            const coords = clientToMapCoords(e.clientX, e.clientY);
            if (!coords) return;
            const countryHit = findCountryAtLonLat(coords);
            onMapClick({
              coordinates: coords,
              countryId: countryHit?.id || null,
              countryNameRaw: countryHit?.rawName || null,
            });
          }
          return;
        }

        const svgPt = clientToSvgCoords(e.clientX, e.clientY);
        if (svgPt && onCityClick) {
          const cityHit = findNearestVisibleMercatorCity(svgPt.x, svgPt.y, 10);
          if (cityHit) {
            onCityClick(cityHit);
            return;
          }
        }
        const targetEl = e.target as Element | null;
        if (onMapClick) {
          const coords = clientToMapCoords(e.clientX, e.clientY);
          if (!coords) return;
          const cId = targetEl?.getAttribute('data-country-id') || null;
          const cName = targetEl?.getAttribute('data-country-name') || null;
          onMapClick({
            coordinates: coords,
            countryId: cId,
            countryNameRaw: cName,
          });
        }
      }
    },
    [
      clientToMapCoords,
      clientToSvgCoords,
      findNearestVisibleGlobeCity,
      findNearestVisibleMercatorCity,
      interactive,
      isGlobe,
      onCityClick,
      onMapClick,
    ]
  );

  const handleSelectContinent = (cont: ContinentId) => {
    setActiveContinent(cont);
    const preset = CONTINENT_VIEWPORTS[cont];
    if (isGlobe) {
      if (cont === 'all') {
        animateGlobeTo(DEFAULT_GLOBE_ROT, 1, 520);
      } else {
        focusOnCoords(preset.center, preset.zoom);
      }
      return;
    }

    if (cont === 'all') {
      animateTo({ x: 0, y: 0, k: 1 }, 480);
    } else {
      focusOnCoords(preset.center, preset.zoom);
    }
  };

  // Compute satellite tile layers (Mercator flat mode only)
  const activeTileZoom = Math.min(
    7,
    Math.max(2, Math.floor(Math.log2(transform.k * 4)))
  );

  const baseTiles = useMemo(
    () => (!isGlobe && satelliteMode ? getVisibleTiles(2, transform) : []),
    [isGlobe, satelliteMode, transform]
  );
  const detailTiles = useMemo(
    () =>
      !isGlobe && satelliteMode && activeTileZoom > 2
        ? getVisibleTiles(activeTileZoom, transform)
        : [],
    [isGlobe, satelliteMode, activeTileZoom, transform]
  );

  // Precompute arc SVG path if provided
  const arcPath = useMemo(() => {
    if (!arc) return null;
    return pathGen({
      type: 'LineString',
      coordinates: [arc.from, arc.to],
    });
  }, [arc, pathGen]);

  const highlightedSet = useMemo(() => new Set(highlightedCountryIds), [highlightedCountryIds]);
  const wrongSet = useMemo(() => new Set(wrongCountryIds), [wrongCountryIds]);
  const secondaryColorIndexMap = useMemo(() => {
    const map = new Map<string, number>();
    secondaryHighlightIds.forEach((id, idx) => {
      if (!map.has(id)) map.set(id, idx);
    });
    return map;
  }, [secondaryHighlightIds]);

  const orderedCountryPaths = useMemo(() => {
    const base: typeof countryPaths = [];
    const neighbors: typeof countryPaths = [];
    const featured: typeof countryPaths = [];

    for (const c of countryPaths) {
      if (highlightedSet.has(c.id) || wrongSet.has(c.id) || (interactive && hoveredCountry?.id === c.id)) {
        featured.push(c);
      } else if (secondaryColorIndexMap.has(c.id)) {
        neighbors.push(c);
      } else {
        base.push(c);
      }
    }

    return [...base, ...neighbors, ...featured];
  }, [countryPaths, highlightedSet, wrongSet, secondaryColorIndexMap, interactive, hoveredCountry?.id]);

  const countryLabelEntries = useMemo(() => {
    const items = WORLD_COUNTRIES.map((c) => {
      const meta = COUNTRY_BY_ID[c.id];
      const center = meta?.center ?? c.center;
      const pt = mercatorProjection(center);
      return {
        id: c.id,
        coordinates: center,
        wx: pt ? pt[0] : 0,
        wy: pt ? pt[1] : 0,
        hasMercator: Boolean(pt),
        area: c.area,
        label: locMapCountryName(c.id, c.rawName, language),
      };
    });
    items.sort((a, b) => b.area - a.area);
    return items;
  }, [language, mercatorProjection]);

  const mercatorCityBoundaryPaths = useMemo(() => {
    if (isGlobe || !showCityPins || !showCityBoundaries || cityBoundaries.length === 0) {
      return [];
    }
    const mercatorPathGen = geoPath(mercatorProjection);
    return cityBoundaries
      .map((cb, idx) => {
        const d = mercatorPathGen(cb.feature) || '';
        if (!d) return null;
        const pt = mercatorProjection(cb.center);
        const palette = CITY_BOUNDARY_PALETTE[idx % CITY_BOUNDARY_PALETTE.length];
        const label =
          language === 'ar' ? cb.nameAr : language === 'tr' ? cb.nameTr : cb.nameEn;
        return {
          id: cb.id,
          d,
          cx: pt ? pt[0] : null,
          cy: pt ? pt[1] : null,
          label,
          fill: palette.fill,
          stroke: palette.stroke,
        };
      })
      .filter((item): item is NonNullable<typeof item> => item !== null);
  }, [cityBoundaries, isGlobe, language, mercatorProjection, showCityBoundaries, showCityPins]);

  const currentZoomVal = isGlobe ? globeState.zoom : transform.k;
  const invScale = isGlobe ? 1 : 1 / Math.sqrt(transform.k);
  const strokeDivisor = isGlobe ? 1 : transform.k;

  const continentsOrder: ContinentId[] = [
    'all',
    'asia',
    'africa',
    'europe',
    'north_america',
    'south_america',
    'oceania',
  ];

  const globeRadiusPx = GLOBE_BASE_RADIUS * globeState.zoom;
  const isGlobeSatelliteActive = isGlobe && satelliteMode && globeTextureReady;

  const globeAspectScale = Math.min(
    containerSize.w / (GLOBE_BASE_RADIUS * 2.16),
    containerSize.h / SVG_HEIGHT
  );
  const globeBoxW = Math.max(1, Math.round(SVG_WIDTH * globeAspectScale));
  const globeBoxH = Math.max(1, Math.round(SVG_HEIGHT * globeAspectScale));

  // Hardware-smooth Canvas2D vector/city overlay in 3D Globe mode (eliminates React/SVG DOM diff lag)
  useEffect(() => {
    if (!isGlobe) return;
    const canvas = globeOverlayCanvasRef.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const targetW = Math.max(1, Math.round(globeBoxW * dpr));
    const targetH = Math.max(1, Math.round(globeBoxH * dpr));
    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, targetW, targetH);

    const sx = targetW / SVG_WIDTH;
    const sy = targetH / SVG_HEIGHT;
    ctx.setTransform(sx, 0, 0, sy, 0, 0);

    const cx = SVG_WIDTH / 2;
    const cy = SVG_HEIGHT / 2;
    const r = globeRadiusPx;

    // 1. Atmospheric outer rim halo
    const atmosGrad = ctx.createRadialGradient(cx, cy, r * 0.85, cx, cy, r * 1.07);
    if (isBlackMap) {
      atmosGrad.addColorStop(0, 'rgba(148, 163, 184, 0.16)');
      atmosGrad.addColorStop(0.55, 'rgba(148, 163, 184, 0.06)');
      atmosGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
    } else {
      atmosGrad.addColorStop(0, 'rgba(56, 189, 248, 0.28)');
      atmosGrad.addColorStop(0.55, 'rgba(56, 189, 248, 0.11)');
      atmosGrad.addColorStop(1, 'rgba(56, 189, 248, 0)');
    }
    ctx.fillStyle = atmosGrad;
    ctx.beginPath();
    ctx.arc(cx, cy, r * 1.07, 0, Math.PI * 2);
    ctx.fill();

    const canvasPath = geoPath(globeProjection, ctx);

    // 2. Sphere ocean body (only when black map, vector mode, or texture still loading)
    ctx.beginPath();
    canvasPath({ type: 'Sphere' });
    if (!isGlobeSatelliteActive) {
      const oceanGrad = ctx.createRadialGradient(
        cx - r * 0.24,
        cy - r * 0.28,
        r * 0.08,
        cx,
        cy,
        r * 1.05
      );
      if (isBlackMap) {
        oceanGrad.addColorStop(0, '#070A10');
        oceanGrad.addColorStop(0.6, '#030407');
        oceanGrad.addColorStop(1, '#000000');
      } else if (darkMode) {
        oceanGrad.addColorStop(0, '#14497A');
        oceanGrad.addColorStop(0.55, '#0A2849');
        oceanGrad.addColorStop(1, '#041124');
      } else {
        oceanGrad.addColorStop(0, '#60A5FA');
        oceanGrad.addColorStop(0.55, '#2563EB');
        oceanGrad.addColorStop(1, '#1E3A8A');
      }
      ctx.fillStyle = oceanGrad;
      ctx.fill();
    }
    ctx.strokeStyle = isBlackMap
      ? 'rgba(148, 163, 184, 0.36)'
      : darkMode
      ? 'rgba(56, 189, 248, 0.45)'
      : 'rgba(14, 116, 144, 0.35)';
    ctx.lineWidth = 1.25;
    ctx.stroke();

    // 3. Latitude / Longitude Graticule (skipped in ambientMode to maximize spin framerate)
    if (!ambientMode) {
      ctx.save();
      ctx.beginPath();
      canvasPath(geoGraticule10());
      ctx.strokeStyle = isBlackMap
        ? 'rgba(148, 163, 184, 0.12)'
        : darkMode
        ? 'rgba(148, 163, 184, 0.16)'
        : 'rgba(51, 65, 85, 0.16)';
      ctx.lineWidth = 0.55;
      ctx.setLineDash([2.5, 2.5]);
      ctx.stroke();
      ctx.restore();
    }

    // 4. Batched Country Borders & Highlights
    const features =
      isGlobeInteracting || ambientMode ? WORLD_COUNTRIES_FAST : WORLD_COUNTRIES;

    const neighborQueue: Array<{ feat: (typeof features)[number]['feat']; colorIdx: number }> = [];
    const hoveredQueue: Array<(typeof features)[number]['feat']> = [];
    const wrongQueue: Array<(typeof features)[number]['feat']> = [];
    const highlightedQueue: Array<(typeof features)[number]['feat']> = [];

    ctx.beginPath();
    for (const item of features) {
      if (!ambientMode) {
        if (highlightedSet.has(item.id)) {
          highlightedQueue.push(item.feat);
          continue;
        }
        if (wrongSet.has(item.id)) {
          wrongQueue.push(item.feat);
          continue;
        }
        const secIdx = secondaryColorIndexMap.get(item.id);
        if (secIdx !== undefined) {
          neighborQueue.push({ feat: item.feat, colorIdx: secIdx });
          continue;
        }
        if (interactive && hoveredCountry?.id === item.id) {
          hoveredQueue.push(item.feat);
          continue;
        }
      }
      canvasPath(item.feat);
    }

    if (!ambientMode && !isGlobeSatelliteActive) {
      ctx.fillStyle = isBlackMap ? '#0E131B' : darkMode ? '#1D3F35' : '#DCE8DF';
      ctx.fill();
    }
    ctx.strokeStyle = isGlobeSatelliteActive
      ? ambientMode
        ? 'rgba(241, 245, 249, 0.24)'
        : 'rgba(241, 245, 249, 0.36)'
      : isBlackMap
      ? 'rgba(148, 163, 184, 0.5)'
      : darkMode
      ? 'rgba(148, 163, 184, 0.45)'
      : '#64748B';
    ctx.lineWidth = ambientMode ? 0.5 : 0.65;
    ctx.stroke();

    // Draw neighboring countries in distinct colors
    for (const nb of neighborQueue) {
      const palette =
        NEIGHBOR_COLOR_PALETTE[nb.colorIdx % NEIGHBOR_COLOR_PALETTE.length];
      ctx.beginPath();
      canvasPath(nb.feat);
      ctx.fillStyle = satelliteMode
        ? palette.fillSat
        : darkMode || isBlackMap
        ? palette.fillVecDark
        : palette.fillVecLight;
      ctx.fill();
      ctx.strokeStyle = palette.stroke;
      ctx.lineWidth = 1.25;
      ctx.stroke();
    }

    // Draw hovered country
    for (const feat of hoveredQueue) {
      ctx.beginPath();
      canvasPath(feat);
      ctx.fillStyle = satelliteMode
        ? 'rgba(56, 189, 248, 0.24)'
        : isBlackMap
        ? '#1E293B'
        : darkMode
        ? '#2B5B53'
        : '#CFE6DD';
      ctx.fill();
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 1.25;
      ctx.stroke();
    }

    // Draw wrong guesses
    for (const feat of wrongQueue) {
      ctx.beginPath();
      canvasPath(feat);
      ctx.fillStyle = satelliteMode ? 'rgba(239, 68, 68, 0.36)' : '#EF4444';
      ctx.fill();
      ctx.strokeStyle = '#FCA5A5';
      ctx.lineWidth = 1.35;
      ctx.stroke();
    }

    // Draw selected / primary highlighted country on top
    for (const feat of highlightedQueue) {
      ctx.beginPath();
      canvasPath(feat);
      ctx.fillStyle = satelliteMode ? 'rgba(16, 185, 129, 0.48)' : '#10B981';
      ctx.fill();
      ctx.strokeStyle = '#6EE7B7';
      ctx.lineWidth = 1.65;
      ctx.stroke();
    }

    // 4b. OpenStreetMap City / District Administrative Boundaries on Globe
    const viewCenter: [number, number] = [-globeState.rot[0], -globeState.rot[1]];
    if (showCityPins && showCityBoundaries && !ambientMode && cityBoundaries.length > 0) {
      const boundaryLabelBoxes: Array<[number, number, number, number]> = [];
      for (let i = 0; i < cityBoundaries.length; i++) {
        const cb = cityBoundaries[i];
        const palette = CITY_BOUNDARY_PALETTE[i % CITY_BOUNDARY_PALETTE.length];
        ctx.save();
        ctx.beginPath();
        canvasPath(cb.feature);
        ctx.fillStyle = palette.fill;
        ctx.fill();
        ctx.strokeStyle = palette.stroke;
        ctx.lineWidth = 1.0;
        ctx.setLineDash([3, 2]);
        ctx.stroke();
        ctx.restore();

        if (geoDistance(cb.center, viewCenter) <= Math.PI / 2 - 0.02) {
          const pt = globeProjection(cb.center);
          if (pt) {
            const label =
              language === 'ar' ? cb.nameAr : language === 'tr' ? cb.nameTr : cb.nameEn;
            ctx.save();
            ctx.font = '600 7.8px Cairo, Inter, sans-serif';
            const textW = ctx.measureText(label).width;
            const x1 = pt[0] - textW / 2 - 3;
            const x2 = pt[0] + textW / 2 + 3;
            const y1 = pt[1] - 9;
            const y2 = pt[1] + 4;
            const overlaps = boundaryLabelBoxes.some(
              (b) => x1 < b[2] && x2 > b[0] && y1 < b[3] && y2 > b[1]
            );
            if (!overlaps) {
              boundaryLabelBoxes.push([x1, y1, x2, y2]);
              ctx.textAlign = 'center';
              ctx.textBaseline = 'middle';
              ctx.lineJoin = 'round';
              ctx.strokeStyle = '#020617';
              ctx.lineWidth = 1.9;
              ctx.fillStyle = palette.stroke;
              ctx.strokeText(label, pt[0], pt[1]);
              ctx.fillText(label, pt[0], pt[1]);
            }
            ctx.restore();
          }
        }
      }
    }

    // 5. Vector-mode Spherical Limb Shading
    if (!isGlobeSatelliteActive) {
      ctx.save();
      ctx.beginPath();
      canvasPath({ type: 'Sphere' });
      ctx.clip();
      const limbGrad = ctx.createRadialGradient(
        cx - r * 0.28,
        cy - r * 0.32,
        r * 0.05,
        cx,
        cy,
        r * 1.04
      );
      limbGrad.addColorStop(0, 'rgba(255, 255, 255, 0.08)');
      limbGrad.addColorStop(0.68, 'rgba(0, 0, 0, 0)');
      limbGrad.addColorStop(1, 'rgba(2, 6, 23, 0.45)');
      ctx.fillStyle = limbGrad;
      ctx.fillRect(cx - r - 4, cy - r - 4, r * 2 + 8, r * 2 + 8);
      ctx.restore();
    }

    // 6. Geodesic Arc
    if (arc) {
      ctx.save();
      ctx.beginPath();
      canvasPath({
        type: 'LineString',
        coordinates: [arc.from, arc.to],
      });
      ctx.strokeStyle = '#F59E0B';
      ctx.lineWidth = 1.9;
      ctx.setLineDash([4, 3]);
      ctx.lineCap = 'round';
      ctx.stroke();
      ctx.restore();
    }

    // 7. Markers
    for (const m of markers) {
      if (geoDistance(m.coordinates, viewCenter) > Math.PI / 2 - 0.015) continue;
      const pt = globeProjection(m.coordinates);
      if (!pt) continue;
      const [mx, my] = pt;
      const mr = 5.5;
      if (m.kind === 'target' || m.kind === 'guess-correct') {
        ctx.beginPath();
        ctx.arc(mx, my, mr * 1.85, 0, Math.PI * 2);
        ctx.strokeStyle = m.kind === 'target' ? '#10B981' : '#34D399';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(mx, my, mr * 1.05, 0, Math.PI * 2);
        ctx.fillStyle = '#10B981';
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1.4;
        ctx.stroke();
      } else if (m.kind === 'explore') {
        ctx.beginPath();
        ctx.arc(mx, my, mr * 1.6, 0, Math.PI * 2);
        ctx.strokeStyle = '#F59E0B';
        ctx.lineWidth = 1.4;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(mx, my, mr * 0.95, 0, Math.PI * 2);
        ctx.fillStyle = '#F59E0B';
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1.3;
        ctx.stroke();
      } else {
        ctx.beginPath();
        ctx.arc(mx, my, mr * 0.85, 0, Math.PI * 2);
        ctx.fillStyle = '#EF4444';
        ctx.fill();
        ctx.strokeStyle = '#FFFFFF';
        ctx.lineWidth = 1.2;
        ctx.stroke();
      }
    }

    // 8. Country Names Layer on Globe (prominent, non-shrinking, clear hierarchy above countries)
    const placedCountryBoxes: Array<[number, number, number, number]> = [];
    if (!ambientMode) {
      const hasStatusHighlight =
        highlightedSet.size > 0 || wrongSet.size > 0 || secondaryColorIndexMap.size > 0;
      if (countryNamesEnabled || hasStatusHighlight) {
        ctx.save();
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.lineJoin = 'round';
        const zoomBoost = Math.min(2.2, (globeState.zoom - 1) * 0.55);

        const queue: Array<{
          x: number;
          y: number;
          label: string;
          fontSize: number;
          priority: number;
          fill: string;
          stroke: string;
        }> = [];

        for (const item of countryLabelEntries) {
          const isHighlighted = highlightedSet.has(item.id);
          const isWrong = wrongSet.has(item.id);
          const isNeighbor = secondaryColorIndexMap.has(item.id);
          const isHov = interactive && hoveredCountry?.id === item.id;
          if (!countryNamesEnabled && !isHighlighted && !isWrong && !isNeighbor) {
            continue;
          }
          if (geoDistance(item.coordinates, viewCenter) > Math.PI / 2 - 0.04) continue;
          const pt = globeProjection(item.coordinates);
          if (!pt) continue;
          const [px, py] = pt;
          if (px < 10 || px > SVG_WIDTH - 10 || py < 10 || py > SVG_HEIGHT - 10) continue;

          const baseSize =
            item.area > 0.008 ? 10.6 : item.area > 0.0018 ? 9.2 : 8.2;
          const fontSize = baseSize + zoomBoost;
          const priority = isHighlighted
            ? 100
            : isWrong
            ? 90
            : isNeighbor
            ? 80
            : isHov
            ? 70
            : item.area * 1000;

          const fill = isHighlighted
            ? '#6EE7B7'
            : isWrong
            ? '#FCA5A5'
            : isNeighbor
            ? '#FDE68A'
            : satelliteMode || darkMode || isBlackMap
            ? '#F8FAFC'
            : '#0F172A';
          const stroke =
            satelliteMode || darkMode || isBlackMap ? '#020617' : '#FFFFFF';

          queue.push({ x: px, y: py, label: item.label, fontSize, priority, fill, stroke });
        }

        queue.sort((a, b) => b.priority - a.priority);
        for (const item of queue) {
          ctx.font = `700 ${item.fontSize}px Cairo, Inter, sans-serif`;
          const textW = ctx.measureText(item.label).width;
          const x1 = item.x - textW / 2 - 4;
          const x2 = item.x + textW / 2 + 4;
          const y1 = item.y - item.fontSize * 0.65;
          const y2 = item.y + item.fontSize * 0.65;

          let overlaps = false;
          if (item.priority < 80) {
            for (let i = 0; i < placedCountryBoxes.length; i++) {
              const b = placedCountryBoxes[i];
              if (x1 < b[2] && x2 > b[0] && y1 < b[3] && y2 > b[1]) {
                overlaps = true;
                break;
              }
            }
          }
          if (overlaps) continue;

          placedCountryBoxes.push([x1, y1, x2, y2]);
          ctx.strokeStyle = item.stroke;
          ctx.lineWidth = 2.6;
          ctx.fillStyle = item.fill;
          ctx.strokeText(item.label, item.x, item.y);
          ctx.fillText(item.label, item.x, item.y);
        }
        ctx.restore();
      }
    }

    // 9. Cities Pin & Label Layer on Globe (ALL visible-hemisphere world cities rendered; compact labels anti-overlapped)
    if (showCityPins && !ambientMode && cityPoints.length > 0) {
      const labelQueue: Array<{
        x: number;
        y: number;
        pinR: number;
        label: string;
        bold: boolean;
        accent: boolean;
        priority: number;
      }> = [];

      for (const city of cityPoints) {
        if (geoDistance(city.coordinates, viewCenter) > Math.PI / 2 - 0.015) continue;
        const pt = globeProjection(city.coordinates);
        if (!pt) continue;
        const [px, py] = pt;
        if (px < -20 || px > SVG_WIDTH + 20 || py < -20 || py > SVG_HEIGHT + 20) continue;

        const isSelected = selectedCityId === city.id;
        const isHov = hoveredCity?.id === city.id;
        const isInSelectedCountry =
          Boolean(highlightedCityCountryId) &&
          city.countryId === highlightedCityCountryId;

        const pinR =
          isSelected || isHov
            ? 3.4
            : isInSelectedCountry
            ? 2.4
            : city.isCapital
            ? 2.0
            : 1.35;

        if (isSelected) {
          ctx.beginPath();
          ctx.arc(px, py, pinR * 2.0, 0, Math.PI * 2);
          ctx.strokeStyle = '#F59E0B';
          ctx.lineWidth = 1.15;
          ctx.stroke();
        }

        ctx.beginPath();
        ctx.arc(px, py, pinR, 0, Math.PI * 2);
        ctx.fillStyle = isSelected
          ? '#F59E0B'
          : isInSelectedCountry
          ? '#FBBF24'
          : city.isCapital
          ? '#38BDF8'
          : '#34D399';
        ctx.fill();
        ctx.strokeStyle = '#0F172A';
        ctx.lineWidth = 0.65;
        ctx.stroke();

        if (showCityNames) {
          const priority =
            isSelected || isHov
              ? 4
              : isInSelectedCountry
              ? 3
              : city.isCapital
              ? 2
              : 1;
          labelQueue.push({
            x: px,
            y: py,
            pinR,
            label: locCityName(city, language),
            bold: isSelected || isHov || city.isCapital,
            accent: isSelected || isHov || isInSelectedCountry,
            priority,
          });
        }
      }

      if (labelQueue.length > 0) {
        labelQueue.sort((a, b) => b.priority - a.priority);
        const placedBoxes: Array<[number, number, number, number]> = [...placedCountryBoxes];
        ctx.textAlign = 'center';
        ctx.textBaseline = 'bottom';
        ctx.lineJoin = 'round';
        ctx.strokeStyle = '#060E1A';
        ctx.lineWidth = 2.1;
        const globeCityZoomBoost = Math.min(2.0, (globeState.zoom - 1) * 0.45);

        for (const item of labelQueue) {
          const baseFontSize =
            item.priority >= 3 ? 10.0 : item.priority === 2 ? 9.0 : 8.2;
          const fontSize = baseFontSize + globeCityZoomBoost;
          ctx.font = `${item.bold ? 700 : 600} ${fontSize}px Cairo, Inter, sans-serif`;
          const textW = ctx.measureText(item.label).width;
          const labelY = item.y - item.pinR * 1.45;
          const x1 = item.x - textW / 2 - 3;
          const x2 = item.x + textW / 2 + 3;
          const y1 = labelY - fontSize - 2;
          const y2 = labelY + 1.5;

          let overlaps = false;
          if (item.priority < 4) {
            for (let i = 0; i < placedBoxes.length; i++) {
              const b = placedBoxes[i];
              if (x1 < b[2] && x2 > b[0] && y1 < b[3] && y2 > b[1]) {
                overlaps = true;
                break;
              }
            }
          }
          if (overlaps) continue;

          placedBoxes.push([x1, y1, x2, y2]);
          ctx.fillStyle = item.accent ? '#FDE68A' : '#F8FAFC';
          ctx.strokeText(item.label, item.x, labelY);
          ctx.fillText(item.label, item.x, labelY);
        }
      }
    }
  }, [
    ambientMode,
    arc,
    cityBoundaries,
    cityPoints,
    countryLabelEntries,
    countryNamesEnabled,
    darkMode,
    globeBoxH,
    globeBoxW,
    globeProjection,
    globeRadiusPx,
    globeState.rot,
    globeState.zoom,
    highlightedCityCountryId,
    highlightedSet,
    hoveredCity,
    hoveredCountry,
    interactive,
    isBlackMap,
    isGlobe,
    isGlobeInteracting,
    isGlobeSatelliteActive,
    language,
    markers,
    satelliteMode,
    secondaryColorIndexMap,
    selectedCityId,
    showCityBoundaries,
    showCityNames,
    showCityPins,
    wrongSet,
  ]);

  // Fast Canvas2D Country Names & City Pins/Labels Overlay for Flat Mercator (60fps)
  useEffect(() => {
    if (isGlobe) return;
    const canvas = mercatorCityCanvasRef.current;
    if (!canvas) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const w = Math.max(1, Math.round(containerSize.w));
    const h = Math.max(1, Math.round(containerSize.h));
    const targetW = Math.max(1, Math.round(w * dpr));
    const targetH = Math.max(1, Math.round(h * dpr));

    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
    }

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.clearRect(0, 0, targetW, targetH);

    if (ambientMode) return;

    const hasStatusHighlight =
      highlightedSet.size > 0 || wrongSet.size > 0 || secondaryColorIndexMap.size > 0;
    const shouldDrawCountries = countryNamesEnabled || hasStatusHighlight;
    const shouldDrawCities = showCityPins && mercatorCityEntries.length > 0;

    if (!shouldDrawCountries && !shouldDrawCities) return;

    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

    // Exact match to SVG preserveAspectRatio="xMidYMid slice"
    const sliceScale = Math.max(w / SVG_WIDTH, h / SVG_HEIGHT);
    const offsetX = (w - SVG_WIDTH * sliceScale) / 2;
    const offsetY = (h - SVG_HEIGHT * sliceScale) / 2;
    const { x: tx, y: ty, k } = transform;

    // 1. Country Names (drawn cleanly at readable size, anti-overlapped)
    const placedCountryBoxes: Array<[number, number, number, number]> = [];
    if (shouldDrawCountries) {
      ctx.save();
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.lineJoin = 'round';
      const zoomBoost = Math.min(2.8, Math.sqrt(k) * 0.75);

      const countryQueue: Array<{
        x: number;
        y: number;
        label: string;
        fontSize: number;
        priority: number;
        fill: string;
        stroke: string;
      }> = [];

      for (const item of countryLabelEntries) {
        if (!item.hasMercator) continue;
        const isHighlighted = highlightedSet.has(item.id);
        const isWrong = wrongSet.has(item.id);
        const isNeighbor = secondaryColorIndexMap.has(item.id);
        const isHov = interactive && hoveredCountry?.id === item.id;

        if (!countryNamesEnabled && !isHighlighted && !isWrong && !isNeighbor) {
          continue;
        }

        const sx = (item.wx - SVG_WIDTH / 2) * k + SVG_WIDTH / 2 + tx;
        const sy = (item.wy - SVG_HEIGHT / 2) * k + SVG_HEIGHT / 2 + ty;
        const px = offsetX + sx * sliceScale;
        const py = offsetY + sy * sliceScale;
        if (px < -40 || px > w + 40 || py < -20 || py > h + 20) continue;

        const baseSize =
          item.area > 0.008 ? 12.2 : item.area > 0.0018 ? 10.8 : 9.6;
        const fontSize = baseSize + zoomBoost;
        const priority = isHighlighted
          ? 100
          : isWrong
          ? 90
          : isNeighbor
          ? 80
          : isHov
          ? 70
          : item.area * 1000;

        const fill = isHighlighted
          ? '#6EE7B7'
          : isWrong
          ? '#FCA5A5'
          : isNeighbor
          ? '#FDE68A'
          : satelliteMode || darkMode || isBlackMap
          ? '#F8FAFC'
          : '#0F172A';
        const stroke =
          satelliteMode || darkMode || isBlackMap ? '#020617' : '#FFFFFF';

        countryQueue.push({
          x: px,
          y: py,
          label: item.label,
          fontSize,
          priority,
          fill,
          stroke,
        });
      }

      countryQueue.sort((a, b) => b.priority - a.priority);
      for (const item of countryQueue) {
        ctx.font = `700 ${item.fontSize}px Cairo, Inter, sans-serif`;
        const textW = ctx.measureText(item.label).width;
        const x1 = item.x - textW / 2 - 5;
        const x2 = item.x + textW / 2 + 5;
        const y1 = item.y - item.fontSize * 0.7;
        const y2 = item.y + item.fontSize * 0.7;

        let overlaps = false;
        if (item.priority < 80) {
          for (let i = 0; i < placedCountryBoxes.length; i++) {
            const b = placedCountryBoxes[i];
            if (x1 < b[2] && x2 > b[0] && y1 < b[3] && y2 > b[1]) {
              overlaps = true;
              break;
            }
          }
        }
        if (overlaps) continue;

        placedCountryBoxes.push([x1, y1, x2, y2]);
        ctx.strokeStyle = item.stroke;
        ctx.lineWidth = 3.0;
        ctx.fillStyle = item.fill;
        ctx.strokeText(item.label, item.x, item.y);
        ctx.fillText(item.label, item.x, item.y);
      }
      ctx.restore();
    }

    // 2. City Pins & Compact City Labels
    if (!shouldDrawCities) return;

    const labelQueue: Array<{
      x: number;
      y: number;
      pinR: number;
      label: string;
      bold: boolean;
      accent: boolean;
      priority: number;
    }> = [];

    for (const entry of mercatorCityEntries) {
      const sx = (entry.wx - SVG_WIDTH / 2) * k + SVG_WIDTH / 2 + tx;
      const sy = (entry.wy - SVG_HEIGHT / 2) * k + SVG_HEIGHT / 2 + ty;
      const px = offsetX + sx * sliceScale;
      const py = offsetY + sy * sliceScale;

      if (px < -24 || px > w + 24 || py < -24 || py > h + 24) continue;

      const city = entry.city;
      const isSelected = selectedCityId === city.id;
      const isHov = hoveredCity?.id === city.id;
      const isInSelectedCountry =
        Boolean(highlightedCityCountryId) &&
        city.countryId === highlightedCityCountryId;

      const pinR =
        isSelected || isHov
          ? 4.0
          : isInSelectedCountry
          ? 3.0
          : city.isCapital
          ? 2.5
          : 1.75;

      if (isSelected) {
        ctx.beginPath();
        ctx.arc(px, py, pinR * 2.0, 0, Math.PI * 2);
        ctx.strokeStyle = '#F59E0B';
        ctx.lineWidth = 1.25;
        ctx.stroke();
      }

      ctx.beginPath();
      ctx.arc(px, py, pinR, 0, Math.PI * 2);
      ctx.fillStyle = isSelected
        ? '#F59E0B'
        : isInSelectedCountry
        ? '#FBBF24'
        : city.isCapital
        ? '#38BDF8'
        : '#34D399';
      ctx.fill();
      ctx.strokeStyle = '#0F172A';
      ctx.lineWidth = 0.7;
      ctx.stroke();

      if (showCityNames) {
        const priority =
          isSelected || isHov
            ? 4
            : isInSelectedCountry
            ? 3
            : city.isCapital
            ? 2
            : 1;
        labelQueue.push({
          x: px,
          y: py,
          pinR,
          label: locCityName(city, language),
          bold: isSelected || isHov || city.isCapital,
          accent: isSelected || isHov || isInSelectedCountry,
          priority,
        });
      }
    }

    if (labelQueue.length > 0) {
      labelQueue.sort((a, b) => b.priority - a.priority);
      const placedBoxes: Array<[number, number, number, number]> = [...placedCountryBoxes];
      ctx.textAlign = 'center';
      ctx.textBaseline = 'bottom';
      ctx.lineJoin = 'round';
      ctx.strokeStyle = '#060E1A';
      ctx.lineWidth = 2.6;
      const cityZoomBoost = Math.min(2.4, Math.sqrt(k) * 0.55);

      for (const item of labelQueue) {
        const baseFontSize =
          item.priority >= 3 ? 12.0 : item.priority === 2 ? 10.8 : 9.8;
        const fontSize = baseFontSize + cityZoomBoost;
        ctx.font = `${item.bold ? 700 : 600} ${fontSize}px Cairo, Inter, sans-serif`;
        const textW = ctx.measureText(item.label).width;
        const labelY = item.y - item.pinR * 1.5;
        const x1 = item.x - textW / 2 - 3;
        const x2 = item.x + textW / 2 + 3;
        const y1 = labelY - fontSize - 2.5;
        const y2 = labelY + 1.5;

        let overlaps = false;
        if (item.priority < 4) {
          for (let i = 0; i < placedBoxes.length; i++) {
            const b = placedBoxes[i];
            if (x1 < b[2] && x2 > b[0] && y1 < b[3] && y2 > b[1]) {
              overlaps = true;
              break;
            }
          }
        }
        if (overlaps) continue;

        placedBoxes.push([x1, y1, x2, y2]);
        ctx.fillStyle = item.accent ? '#FDE68A' : '#F8FAFC';
        ctx.strokeText(item.label, item.x, labelY);
        ctx.fillText(item.label, item.x, labelY);
      }
    }
  }, [
    ambientMode,
    containerSize.h,
    containerSize.w,
    countryLabelEntries,
    countryNamesEnabled,
    darkMode,
    highlightedCityCountryId,
    highlightedSet,
    hoveredCity,
    hoveredCountry,
    interactive,
    isBlackMap,
    isGlobe,
    language,
    mercatorCityEntries,
    satelliteMode,
    secondaryColorIndexMap,
    selectedCityId,
    showCityNames,
    showCityPins,
    transform,
    wrongSet,
  ]);

  const worldContent = (
    <>
      {/* Flat Mercator Ocean Background */}
      <rect
        x={GRID_ORIGIN_X}
        y={GRID_ORIGIN_Y}
        width={WORLD_SIZE}
        height={WORLD_SIZE}
        fill={
          isBlackMap
            ? '#020408'
            : darkMode
            ? 'url(#oceanGradDark)'
            : 'url(#oceanGradLight)'
        }
      />

      {/* Satellite Imagery Layer (Mercator Flat Mode) */}
      {!isGlobe && satelliteMode && (
        <g className="pointer-events-none">
          {baseTiles.map((tile) => (
            <image
              key={tile.key}
              href={tile.url}
              x={tile.x}
              y={tile.y}
              width={tile.size + 0.6}
              height={tile.size + 0.6}
              preserveAspectRatio="none"
            />
          ))}
          {detailTiles.map((tile) => (
            <image
              key={tile.key}
              href={tile.url}
              x={tile.x}
              y={tile.y}
              width={tile.size + 0.4}
              height={tile.size + 0.4}
              preserveAspectRatio="none"
            />
          ))}
          {darkMode && (
            <rect
              x={GRID_ORIGIN_X}
              y={GRID_ORIGIN_Y}
              width={WORLD_SIZE}
              height={WORLD_SIZE}
              fill="rgba(4, 11, 24, 0.14)"
            />
          )}
        </g>
      )}

      {/* Latitude / Longitude Graticule */}
      <path
        d={graticulePath}
        fill="none"
        stroke={
          isBlackMap
            ? 'rgba(148, 163, 184, 0.11)'
            : satelliteMode
            ? 'rgba(226, 232, 240, 0.14)'
            : darkMode
            ? 'rgba(148, 163, 184, 0.12)'
            : 'rgba(51, 65, 85, 0.14)'
        }
        strokeWidth={0.55 / strokeDivisor}
        strokeDasharray={`${2.5 / strokeDivisor} ${2.5 / strokeDivisor}`}
      />

      {/* Countries Interactive Boundary Layer */}
      <g>
        {orderedCountryPaths.map((c) => {
          const isHighlighted = highlightedSet.has(c.id);
          const isWrong = wrongSet.has(c.id);
          const secondaryColorIdx = secondaryColorIndexMap.get(c.id);
          const isSecondary = secondaryColorIdx !== undefined;
          const isHovered = interactive && hoveredCountry?.id === c.id;

          let fill = isBlackMap
            ? '#0E131B'
            : satelliteMode
            ? 'rgba(15, 23, 42, 0.03)'
            : darkMode
            ? '#162C49'
            : '#F8FAFC';

          let stroke = isBlackMap
            ? 'rgba(148, 163, 184, 0.48)'
            : satelliteMode
            ? 'rgba(241, 245, 249, 0.34)'
            : darkMode
            ? '#294973'
            : '#94A3B8';

          if (isHighlighted) {
            fill = satelliteMode ? 'rgba(16, 185, 129, 0.48)' : '#10B981';
            stroke = '#6EE7B7';
          } else if (isWrong) {
            fill = satelliteMode ? 'rgba(239, 68, 68, 0.36)' : '#EF4444';
            stroke = '#FCA5A5';
          } else if (isSecondary) {
            const palette =
              NEIGHBOR_COLOR_PALETTE[
                secondaryColorIdx % NEIGHBOR_COLOR_PALETTE.length
              ];
            fill = satelliteMode
              ? palette.fillSat
              : darkMode || isBlackMap
              ? palette.fillVecDark
              : palette.fillVecLight;
            stroke = palette.stroke;
          } else if (isHovered) {
            fill = satelliteMode
              ? 'rgba(56, 189, 248, 0.24)'
              : isBlackMap
              ? '#1E293B'
              : darkMode
              ? '#2B5B53'
              : '#CFE6DD';
            stroke = '#38BDF8';
          }

          return (
            <path
              key={c.key}
              d={c.d}
              data-country-id={c.id}
              data-country-name={c.rawName}
              fill={fill}
              stroke={stroke}
              strokeWidth={
                (isHighlighted
                  ? 1.55
                  : isSecondary || isHovered
                  ? 1.25
                  : 0.65) / strokeDivisor
              }
              className="transition-colors duration-100"
              onPointerEnter={() => {
                if (!interactive) return;
                const localizedName = locMapCountryName(
                  c.id,
                  RAW_COUNTRY_NAME_BY_ID[c.id] || c.rawName,
                  language
                );
                setHoveredCountry({ id: c.id, name: localizedName });
              }}
            />
          );
        })}
      </g>

      {/* OpenStreetMap Administrative City / District Boundaries (Flat Mercator) */}
      {mercatorCityBoundaryPaths.length > 0 && (
        <g className="pointer-events-none">
          {mercatorCityBoundaryPaths.map((cb) => (
            <g key={cb.id}>
              <path
                d={cb.d}
                fill={cb.fill}
                stroke={cb.stroke}
                strokeWidth={1.15 / strokeDivisor}
                strokeDasharray={`${3.2 / strokeDivisor} ${2.2 / strokeDivisor}`}
              />
              {cb.cx !== null && cb.cy !== null && (
                <text
                  x={cb.cx}
                  y={cb.cy}
                  textAnchor="middle"
                  dominantBaseline="central"
                  fill={cb.stroke}
                  stroke="#020617"
                  strokeWidth={2.3 / strokeDivisor}
                  paintOrder="stroke"
                  fontSize={9.0 / strokeDivisor}
                  fontWeight={600}
                >
                  {cb.label}
                </text>
              )}
            </g>
          ))}
        </g>
      )}

      {/* Interactive Cities Pin & Label Layer (Flat Mercator SVG — viewport + zoom culled) */}

      {/* Geodesic Distance Arc */}
      {arcPath && (
        <path
          d={arcPath}
          fill="none"
          stroke="#F59E0B"
          strokeWidth={1.9 / strokeDivisor}
          strokeDasharray={`${4 / strokeDivisor} ${3 / strokeDivisor}`}
          strokeLinecap="round"
        />
      )}

      {/* Coordinate & Target Markers */}
      {markers.map((m) => {
        if (!isGeoVisible(m.coordinates)) return null;
        const pt = activeProjection(m.coordinates);
        if (!pt) return null;
        const [cx, cy] = pt;
        const r = 5.5 * invScale;

        if (m.kind === 'target') {
          return (
            <g key={m.id} transform={`translate(${cx}, ${cy})`} className="pointer-events-none">
              <circle
                r={r * 1.9}
                fill="none"
                stroke="#10B981"
                strokeWidth={1.6 * invScale}
                className="animate-pulse-ring"
              />
              <circle
                r={r * 1.05}
                fill="#10B981"
                stroke="#FFFFFF"
                strokeWidth={1.4 * invScale}
              />
            </g>
          );
        }

        if (m.kind === 'guess-correct') {
          return (
            <g key={m.id} transform={`translate(${cx}, ${cy})`} className="pointer-events-none">
              <circle
                r={r * 1.8}
                fill="none"
                stroke="#34D399"
                strokeWidth={1.5 * invScale}
                className="animate-pulse-ring"
              />
              <circle
                r={r}
                fill="#10B981"
                stroke="#FFFFFF"
                strokeWidth={1.4 * invScale}
              />
            </g>
          );
        }

        if (m.kind === 'explore') {
          return (
            <g key={m.id} transform={`translate(${cx}, ${cy})`} className="pointer-events-none">
              <circle
                r={r * 1.6}
                fill="none"
                stroke="#F59E0B"
                strokeWidth={1.4 * invScale}
                className="animate-pulse-ring"
              />
              <circle
                r={r * 0.95}
                fill="#F59E0B"
                stroke="#FFFFFF"
                strokeWidth={1.3 * invScale}
              />
            </g>
          );
        }

        return (
          <g key={m.id} transform={`translate(${cx}, ${cy})`} className="pointer-events-none">
            <circle
              r={r * 0.85}
              fill="#EF4444"
              stroke="#FFFFFF"
              strokeWidth={1.2 * invScale}
            />
          </g>
        );
      })}

    </>
  );

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full overflow-hidden select-none flex items-center justify-center ${
        isBlackMap
          ? 'bg-[#000000]'
          : isGlobe
          ? darkMode
            ? 'bg-[#020611]'
            : 'bg-[#CBDDF0]'
          : darkMode
          ? 'bg-[#040B15]'
          : 'bg-[#D4E4F4]'
      } ${className}`}
      onPointerLeave={() => {
        setHoveredCountry(null);
        setHoveredCity(null);
        setPointerCoords(null);
        dragState.current.isDown = false;
        setIsGlobeInteracting(false);
      }}
    >
      {/* Full-Viewport Cosmic Starfield in Spherical Earth Dark / Black Map Mode */}
      {isGlobe && (darkMode || isBlackMap) && (
        <svg
          viewBox={`0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`}
          preserveAspectRatio="xMidYMid slice"
          className="absolute inset-0 w-full h-full pointer-events-none"
        >
          {STARFIELD.map((s, idx) => (
            <circle
              key={idx}
              cx={s.x}
              cy={s.y}
              r={s.r}
              fill="#E2E8F0"
              opacity={s.o}
            />
          ))}
        </svg>
      )}

      {/* Synchronized Stage (1:1 aspect box in Globe mode so Satellite Canvas & SVG Borders match to 0.0px) */}
      <div
        className="relative shrink-0"
        style={
          isGlobe
            ? { width: globeBoxW, height: globeBoxH }
            : { width: '100%', height: '100%' }
        }
      >
        {isGlobe && satelliteMode && (
          <GlobeSatelliteCanvas
            rotation={globeState.rot}
            zoom={globeState.zoom}
            baseRadiusSvg={GLOBE_BASE_RADIUS}
            svgWidth={SVG_WIDTH}
            svgHeight={SVG_HEIGHT}
            stageWidth={globeBoxW}
            stageHeight={globeBoxH}
            darkMode={darkMode}
            isInteracting={isGlobeInteracting || ambientMode}
            showClouds={showClouds}
            cloudDriftDeg={globeState.cloudDrift ?? 0}
            cloudOpacity={
              ambientMode
                ? 0.84
                : Math.max(0, 0.36 * (1 - (globeState.zoom - 1) * 0.42))
            }
            onTextureReady={setGlobeTextureReady}
          />
        )}

        {isGlobe ? (
          <canvas
            ref={globeOverlayCanvasRef}
            className={`relative w-full h-full touch-none block ${
              interactive ? 'cursor-grab active:cursor-grabbing' : 'pointer-events-none'
            }`}
            onWheel={handleWheel}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
          />
        ) : (
          /* Interactive SVG Map Canvas (Flat Mercator Mode) */
          <>
            <svg
              ref={svgRef}
              viewBox={`0 0 ${SVG_WIDTH} ${SVG_HEIGHT}`}
              preserveAspectRatio="xMidYMid slice"
              className={`relative w-full h-full touch-none ${
                interactive ? 'cursor-grab active:cursor-grabbing' : 'pointer-events-none'
              }`}
              onWheel={handleWheel}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
            >
              <defs>
                <radialGradient id="oceanGradDark" cx="50%" cy="45%" r="65%">
                  <stop offset="0%" stopColor="#0A1E36" />
                  <stop offset="100%" stopColor="#040C18" />
                </radialGradient>
                <radialGradient id="oceanGradLight" cx="50%" cy="45%" r="65%">
                  <stop offset="0%" stopColor="#E6F0FA" />
                  <stop offset="100%" stopColor="#C7DCF0" />
                </radialGradient>
              </defs>

              <g
                transform={`translate(${SVG_WIDTH / 2 + transform.x}, ${
                  SVG_HEIGHT / 2 + transform.y
                }) scale(${transform.k}) translate(${-SVG_WIDTH / 2}, ${-SVG_HEIGHT / 2})`}
              >
                {worldContent}
              </g>
            </svg>
            <canvas
              ref={mercatorCityCanvasRef}
              className="absolute inset-0 w-full h-full pointer-events-none"
            />
          </>
        )}
      </div>

      {/* Hover Tooltip */}
      {interactive && cursorScreenPos && (hoveredCity || hoveredCountry || pointerCoords) && (
        <div
          className={`pointer-events-none fixed z-30 px-2.5 py-1.5 rounded-lg text-xs shadow-lg border transition-opacity duration-100 ${
            darkMode
              ? 'bg-slate-900/95 border-slate-700/80 text-slate-100'
              : 'bg-white/95 border-slate-200 text-slate-800'
          }`}
          style={{
            left: Math.min(window.innerWidth - 190, cursorScreenPos.x + 14),
            top: Math.max(12, cursorScreenPos.y - 38),
          }}
        >
          {hoveredCity && showCityPins && showCityNames ? (
            <div className="font-semibold whitespace-nowrap text-amber-400">
              {locCityName(hoveredCity, language)} ·{' '}
              {locCityCountryName(hoveredCity, language)}
            </div>
          ) : showCountryNamesOnHover && hoveredCountry?.name ? (
            <div className="font-semibold whitespace-nowrap">{hoveredCountry.name}</div>
          ) : null}
          {pointerCoords && (
            <div
              dir="ltr"
              className={`font-mono-tabular text-[11px] ${
                darkMode ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              {formatCoords(pointerCoords)}
            </div>
          )}
        </div>
      )}

      {/* Continent Quick-Focus Strip */}
      {interactive && showContinentBar && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 z-20 max-w-[94vw] overflow-x-auto">
          <div
            className={`flex items-center gap-1 p-1 rounded-xl border backdrop-blur-md shadow-lg ${
              darkMode
                ? 'bg-slate-900/85 border-slate-700/70'
                : 'bg-white/90 border-slate-200'
            }`}
          >
            {continentsOrder.map((cont) => {
              const active = activeContinent === cont;
              return (
                <button
                  key={cont}
                  type="button"
                  onClick={() => handleSelectContinent(cont)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
                    active
                      ? 'bg-amber-500 text-slate-950 font-semibold'
                      : darkMode
                      ? 'text-slate-300 hover:text-white hover:bg-slate-800/80'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  {t(CONTINENT_LABELS[cont], language)}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Map Style Selector (Satellite / Borders / Black Map / City Borders) — Visible on Every Interactive Map */}
      {interactive && (
        <div
          className={`absolute top-3 ${
            language === 'ar' ? 'left-3' : 'right-3'
          } z-20 flex flex-wrap items-center gap-1 p-1 rounded-xl border backdrop-blur-md shadow-lg max-w-[90vw] ${
            darkMode || isBlackMap
              ? 'bg-slate-900/90 border-slate-700/80 text-slate-200'
              : 'bg-white/95 border-slate-200 text-slate-700'
          }`}
        >
          <button
            type="button"
            onClick={() => setMapStyle('satellite')}
            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
              mapStyle === 'satellite'
                ? 'bg-amber-500 text-slate-950'
                : darkMode || isBlackMap
                ? 'hover:bg-slate-800 text-slate-300'
                : 'hover:bg-slate-100 text-slate-600'
            }`}
          >
            <Satellite className="w-3.5 h-3.5 shrink-0" />
            <span>
              {language === 'ar'
                ? 'قمر صناعي'
                : language === 'tr'
                ? 'Uydu'
                : 'Satellite'}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setMapStyle('vector')}
            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
              mapStyle === 'vector'
                ? 'bg-sky-500 text-slate-950'
                : darkMode || isBlackMap
                ? 'hover:bg-slate-800 text-slate-300'
                : 'hover:bg-slate-100 text-slate-600'
            }`}
          >
            <Layers className="w-3.5 h-3.5 shrink-0" />
            <span>
              {language === 'ar'
                ? 'الحدود'
                : language === 'tr'
                ? 'Sınırlar'
                : 'Borders'}
            </span>
          </button>
          <button
            type="button"
            onClick={() => setMapStyle('black')}
            className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
              mapStyle === 'black'
                ? 'bg-slate-950 text-white border border-slate-600 shadow-inner'
                : darkMode || isBlackMap
                ? 'hover:bg-slate-800 text-slate-300'
                : 'hover:bg-slate-100 text-slate-600'
            }`}
          >
            <Moon className="w-3.5 h-3.5 shrink-0" />
            <span>
              {language === 'ar'
                ? 'الخريطة السوداء'
                : language === 'tr'
                ? 'Siyah Harita'
                : 'Black Map'}
            </span>
          </button>

          {showCountryNamesToggle && (
            <button
              type="button"
              onClick={() => setCountryNamesEnabled((prev) => !prev)}
              title={t(UI_TEXT.countryNames, language)}
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                countryNamesEnabled
                  ? 'bg-amber-400 text-slate-950'
                  : darkMode || isBlackMap
                  ? 'hover:bg-slate-800 text-slate-300'
                  : 'hover:bg-slate-100 text-slate-600'
              }`}
            >
              <Tag className="w-3.5 h-3.5 shrink-0" />
              <span>{t(UI_TEXT.countryNames, language)}</span>
            </button>
          )}

          {showCityPins && (
            <button
              type="button"
              onClick={() => setShowCityBoundaries((prev) => !prev)}
              title={
                cityBoundariesLoading
                  ? t(UI_TEXT.loadingBoundaries, language)
                  : t(UI_TEXT.cityBoundaries, language)
              }
              className={`px-2.5 py-1.5 rounded-lg text-[11px] font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                showCityBoundaries
                  ? 'bg-emerald-500 text-slate-950'
                  : darkMode || isBlackMap
                  ? 'hover:bg-slate-800 text-slate-300'
                  : 'hover:bg-slate-100 text-slate-600'
              }`}
            >
              {cityBoundariesLoading ? (
                <Loader2 className="w-3.5 h-3.5 shrink-0 animate-spin" />
              ) : (
                <Hexagon className="w-3.5 h-3.5 shrink-0" />
              )}
              <span>
                {cityBoundariesLoading
                  ? t(UI_TEXT.loadingBoundaries, language)
                  : t(UI_TEXT.cityBoundaries, language)}
              </span>
            </button>
          )}
        </div>
      )}

      {/* Projection, Map Style Cycle, Zoom & Reset Controls */}
      {interactive && (
        <div
          className={`absolute z-20 flex flex-col gap-1.5 ${
            language === 'ar' ? 'left-3 sm:left-4' : 'right-3 sm:right-4'
          } bottom-20 sm:bottom-6`}
        >
          {/* Spherical Earth / Flat Map Toggle */}
          <button
            type="button"
            onClick={() => setProjectionMode(isGlobe ? 'mercator' : 'globe')}
            title={
              isGlobe
                ? t(UI_TEXT.flatMap, language)
                : t(UI_TEXT.sphericalEarth, language)
            }
            aria-label={t(UI_TEXT.sphericalEarth, language)}
            className={`w-10 h-10 rounded-xl border flex items-center justify-center shadow-md transition-colors cursor-pointer ${
              isGlobe
                ? 'bg-sky-500 border-sky-400 text-slate-950 hover:bg-sky-400'
                : darkMode
                ? 'bg-slate-900/90 border-slate-700/80 text-sky-400 hover:bg-slate-800'
                : 'bg-white/95 border-slate-200 text-sky-700 hover:bg-slate-50'
            }`}
          >
            {isGlobe ? (
              <MapIcon className="w-4 h-4" />
            ) : (
              <Globe className="w-4 h-4" />
            )}
          </button>

          {/* Quick Map Style Cycle Button (Satellite -> Borders -> Black Map) */}
          <button
            type="button"
            onClick={() =>
              setMapStyle((prev) =>
                prev === 'satellite'
                  ? 'vector'
                  : prev === 'vector'
                  ? 'black'
                  : 'satellite'
              )
            }
            title={
              language === 'ar'
                ? mapStyle === 'satellite'
                  ? 'خريطة القمر الصناعي (اضغط للتبديل)'
                  : mapStyle === 'vector'
                  ? 'خريطة الحدود (اضغط للتبديل)'
                  : 'الخريطة السوداء (اضغط للتبديل)'
                : language === 'tr'
                ? mapStyle === 'satellite'
                  ? 'Uydu Haritası (değiştirmek için tıkla)'
                  : mapStyle === 'vector'
                  ? 'Sınır Haritası (değiştirmek için tıkla)'
                  : 'Siyah Harita (değiştirmek için tıkla)'
                : mapStyle === 'satellite'
                ? 'Satellite Map (click to switch)'
                : mapStyle === 'vector'
                ? 'Borders Map (click to switch)'
                : 'Black Map (click to switch)'
            }
            aria-label="Switch Map Style"
            className={`w-10 h-10 rounded-xl border flex items-center justify-center shadow-md transition-colors cursor-pointer ${
              mapStyle === 'black'
                ? 'bg-slate-950 border-slate-600 text-white hover:bg-slate-900'
                : mapStyle === 'satellite'
                ? 'bg-amber-500 border-amber-400 text-slate-950 hover:bg-amber-400'
                : darkMode
                ? 'bg-slate-900/90 border-slate-700/80 text-slate-200 hover:bg-slate-800'
                : 'bg-white/95 border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            {mapStyle === 'black' ? (
              <Moon className="w-4 h-4" />
            ) : mapStyle === 'satellite' ? (
              <Satellite className="w-4 h-4" />
            ) : (
              <Layers className="w-4 h-4" />
            )}
          </button>

          <button
            type="button"
            onClick={() => handleZoomBy(1.45)}
            title={t(UI_TEXT.zoomIn, language)}
            aria-label={t(UI_TEXT.zoomIn, language)}
            className={`w-10 h-10 rounded-xl border flex items-center justify-center shadow-md transition-colors cursor-pointer ${
              darkMode
                ? 'bg-slate-900/90 border-slate-700/80 text-slate-200 hover:bg-slate-800 hover:text-white'
                : 'bg-white/95 border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <ZoomIn className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => handleZoomBy(0.68)}
            title={t(UI_TEXT.zoomOut, language)}
            aria-label={t(UI_TEXT.zoomOut, language)}
            className={`w-10 h-10 rounded-xl border flex items-center justify-center shadow-md transition-colors cursor-pointer ${
              darkMode
                ? 'bg-slate-900/90 border-slate-700/80 text-slate-200 hover:bg-slate-800 hover:text-white'
                : 'bg-white/95 border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <ZoomOut className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveContinent('all');
              if (isGlobe) {
                animateGlobeTo(DEFAULT_GLOBE_ROT, 1, 480);
              } else {
                animateTo({ x: 0, y: 0, k: 1 }, 420);
              }
            }}
            title={t(UI_TEXT.resetMap, language)}
            aria-label={t(UI_TEXT.resetMap, language)}
            className={`w-10 h-10 rounded-xl border flex items-center justify-center shadow-md transition-colors cursor-pointer ${
              darkMode
                ? 'bg-slate-900/90 border-slate-700/80 text-slate-200 hover:bg-slate-800 hover:text-white'
                : 'bg-white/95 border-slate-200 text-slate-700 hover:bg-slate-50'
            }`}
          >
            <RotateCcw className="w-4 h-4" />
          </button>
          <div
            className={`w-10 py-1 rounded-lg border text-center font-mono-tabular text-[11px] flex items-center justify-center gap-0.5 ${
              darkMode
                ? 'bg-slate-900/80 border-slate-800 text-slate-400'
                : 'bg-white/90 border-slate-200 text-slate-500'
            }`}
          >
            <Compass className="w-3 h-3 text-amber-500 shrink-0" />
            <span>{currentZoomVal.toFixed(1)}x</span>
          </div>
        </div>
      )}
    </div>
  );
};
