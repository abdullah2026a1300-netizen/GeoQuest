import React, { useEffect, useRef, useState } from 'react';

interface GlobeSatelliteCanvasProps {
  rotation: [number, number]; // [lambdaDeg, phiDeg]
  zoom: number;
  baseRadiusSvg: number;
  svgWidth: number;
  svgHeight: number;
  stageWidth: number;
  stageHeight: number;
  darkMode: boolean;
  isInteracting?: boolean;
  showClouds?: boolean;
  cloudDriftDeg?: number;
  cloudOpacity?: number;
  onTextureReady?: (ready: boolean) => void;
}

interface MosaicCanvasData {
  canvas: HTMLCanvasElement;
  level: number;
}

const TILE_PX = 256;
const DEG_TO_RAD = Math.PI / 180;
const RAD_TO_DEG = 180 / Math.PI;
const TWO_PI = Math.PI * 2;
const INV_TWO_PI = 1 / TWO_PI;
const INV_PI = 1 / Math.PI;
const QUARTER_PI = Math.PI / 4;
const MAX_MERC_LAT = 1.4844222297453322; // ~85.051129 deg

// Power-of-two seamless 3D spherical cloud texture (512x256)
const CLOUD_W = 512;
const CLOUD_H = 256;
let cachedCloudRgba: Uint8Array | null = null;

function hash3(ix: number, iy: number, iz: number): number {
  let n = (ix * 374761393 + iy * 668265263 + iz * 2147483647) | 0;
  n = (n ^ (n >>> 13)) * 1274126177;
  n = n ^ (n >>> 16);
  return (n >>> 0) / 4294967295;
}

function smoothNoise3(x: number, y: number, z: number): number {
  const ix = Math.floor(x);
  const iy = Math.floor(y);
  const iz = Math.floor(z);
  const fx = x - ix;
  const fy = y - iy;
  const fz = z - iz;
  const ux = fx * fx * (3 - 2 * fx);
  const uy = fy * fy * (3 - 2 * fy);
  const uz = fz * fz * (3 - 2 * fz);

  const c000 = hash3(ix, iy, iz);
  const c100 = hash3(ix + 1, iy, iz);
  const c010 = hash3(ix, iy + 1, iz);
  const c110 = hash3(ix + 1, iy + 1, iz);
  const c001 = hash3(ix, iy, iz + 1);
  const c101 = hash3(ix + 1, iy, iz + 1);
  const c011 = hash3(ix, iy + 1, iz + 1);
  const c111 = hash3(ix + 1, iy + 1, iz + 1);

  const x00 = c000 + (c100 - c000) * ux;
  const x10 = c010 + (c110 - c010) * ux;
  const x01 = c001 + (c101 - c001) * ux;
  const x11 = c011 + (c111 - c011) * ux;

  const y0 = x00 + (x10 - x00) * uy;
  const y1 = x01 + (x11 - x01) * uy;

  return y0 + (y1 - y0) * uz;
}

function fbm3(x: number, y: number, z: number): number {
  let sum = 0;
  let amp = 0.54;
  let freq = 2.6;
  for (let i = 0; i < 4; i++) {
    sum += amp * smoothNoise3(x * freq, y * freq, z * freq);
    freq *= 2.15;
    amp *= 0.48;
  }
  return sum;
}

function getGlobalCloudRgba(): Uint8Array {
  if (cachedCloudRgba) return cachedCloudRgba;
  const rgba = new Uint8Array(CLOUD_W * CLOUD_H * 4);

  for (let py = 0; py < CLOUD_H; py++) {
    const lat = (0.5 - (py + 0.5) / CLOUD_H) * Math.PI;
    const cosLat = Math.cos(lat);
    const sinLat = Math.sin(lat);

    for (let px = 0; px < CLOUD_W; px++) {
      const lon = ((px + 0.5) / CLOUD_W) * TWO_PI - Math.PI;
      const swirledLon = lon + 0.28 * Math.sin(lat * 3.0);
      const sx = cosLat * Math.cos(swirledLon);
      const sy = cosLat * Math.sin(swirledLon);
      const sz = sinLat;

      const warpX = fbm3(sx + 3.1, sy - 1.7, sz + 2.4) * 0.45;
      const warpY = fbm3(sx - 2.3, sy + 4.1, sz - 1.2) * 0.45;
      const val = fbm3(sx + warpX, sy + warpY, sz);

      let density = (val - 0.46) / 0.30;
      if (density < 0) density = 0;
      else if (density > 1) density = 1;
      density = density * density * (3 - 2 * density);

      const byteVal = (density * 255) | 0;
      const idx = (py * CLOUD_W + px) * 4;
      rgba[idx] = byteVal;
      rgba[idx + 1] = byteVal;
      rgba[idx + 2] = byteVal;
      rgba[idx + 3] = 255;
    }
  }

  cachedCloudRgba = rgba;
  return rgba;
}

let cachedMosaic: MosaicCanvasData | null = null;
let loadStarted = false;
const mosaicListeners = new Set<(m: MosaicCanvasData) => void>();

// LRU cache for on-demand HD tile HTMLImageElements (z=5 and z=6)
const MAX_HD_TILES = 140;
const hdImageCache = new Map<string, HTMLImageElement>();
const hdInFlight = new Set<string>();
const hdTileListeners = new Set<() => void>();

async function loadTileGridCanvas(
  zoomLevel: number,
  batchSize = 16
): Promise<MosaicCanvasData | null> {
  const n = Math.pow(2, zoomLevel);
  const fullSize = n * TILE_PX;
  const off = document.createElement('canvas');
  off.width = fullSize;
  off.height = fullSize;
  const ctx = off.getContext('2d');
  if (!ctx) return null;

  const coords: Array<{ tx: number; ty: number }> = [];
  for (let ty = 0; ty < n; ty++) {
    for (let tx = 0; tx < n; tx++) {
      coords.push({ tx, ty });
    }
  }

  let loadedCount = 0;
  for (let i = 0; i < coords.length; i += batchSize) {
    const slice = coords.slice(i, i + batchSize);
    await Promise.all(
      slice.map(
        ({ tx, ty }) =>
          new Promise<void>((resolve) => {
            const img = new Image();
            img.crossOrigin = 'anonymous';
            img.onload = () => {
              try {
                ctx.drawImage(img, tx * TILE_PX, ty * TILE_PX, TILE_PX, TILE_PX);
                loadedCount++;
              } catch {
                // ignore draw failure
              }
              resolve();
            };
            img.onerror = () => resolve();
            img.src = `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${zoomLevel}/${ty}/${tx}`;
          })
      )
    );
  }

  if (loadedCount === 0) return null;
  return { canvas: off, level: zoomLevel };
}

function ensureMosaicLoaded(allowZ4: boolean) {
  if (loadStarted) return;
  loadStarted = true;

  loadTileGridCanvas(2, 16).then((m2) => {
    if (m2 && (!cachedMosaic || cachedMosaic.level < 2)) {
      cachedMosaic = m2;
      mosaicListeners.forEach((cb) => cb(m2));
    }
    loadTileGridCanvas(3, 16).then((m3) => {
      if (m3 && (!cachedMosaic || cachedMosaic.level < 3)) {
        cachedMosaic = m3;
        mosaicListeners.forEach((cb) => cb(m3));
      }
      if (allowZ4) {
        loadTileGridCanvas(4, 16).then((m4) => {
          if (m4) {
            cachedMosaic = m4;
            mosaicListeners.forEach((cb) => cb(m4));
          }
        });
      }
    });
  });
}

function lonLatToTile(lonDeg: number, latDeg: number, z: number): { tx: number; ty: number } {
  const n = Math.pow(2, z);
  let u = ((lonDeg + 180) / 360) % 1;
  if (u < 0) u += 1;
  const latRad = Math.max(-85, Math.min(85, latDeg)) * DEG_TO_RAD;
  const v = 0.5 - Math.log(Math.tan(QUARTER_PI + latRad * 0.5)) * INV_TWO_PI;
  const tx = Math.min(n - 1, Math.max(0, Math.floor(u * n)));
  const ty = Math.min(n - 1, Math.max(0, Math.floor(v * n)));
  return { tx, ty };
}

function getPatchBounds(
  rotation: [number, number],
  zoom: number
): { z: number; startTx: number; startTy: number; n: number } | null {
  if (zoom < 1.75) return null;
  const z = zoom >= 3.6 ? 6 : 5;
  const n = Math.pow(2, z);
  const center = lonLatToTile(-rotation[0], -rotation[1], z);
  const startTx = (((center.tx - 2) % n) + n) % n;
  const startTy = Math.max(0, Math.min(n - 4, center.ty - 2));
  return { z, startTx, startTy, n };
}

function requestDetailPatchTiles(rotation: [number, number], zoom: number) {
  const patch = getPatchBounds(rotation, zoom);
  if (!patch) return;
  const { z, startTx, startTy, n } = patch;

  for (let dy = 0; dy < 4; dy++) {
    const ty = startTy + dy;
    for (let dx = 0; dx < 4; dx++) {
      const tx = (startTx + dx) % n;
      const key = `${z}/${tx}/${ty}`;
      if (hdImageCache.has(key) || hdInFlight.has(key)) continue;

      hdInFlight.add(key);
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        hdInFlight.delete(key);
        if (hdImageCache.size >= MAX_HD_TILES) {
          const oldest = hdImageCache.keys().next().value;
          if (oldest) hdImageCache.delete(oldest);
        }
        hdImageCache.set(key, img);
        hdTileListeners.forEach((cb) => cb());
      };
      img.onerror = () => {
        hdInFlight.delete(key);
      };
      img.src = `https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/${z}/${ty}/${tx}`;
    }
  }
}

const VERT_SHADER_SRC = `
attribute vec2 aPos;
varying vec2 vUv;
void main() {
  vUv = vec2(aPos.x * 0.5 + 0.5, 0.5 - aPos.y * 0.5);
  gl_Position = vec4(aPos, 0.0, 1.0);
}
`;

const FRAG_SHADER_SRC = `
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif

varying vec2 vUv;

uniform sampler2D uBaseTex;
uniform sampler2D uDetailTex;
uniform sampler2D uCloudTex;

uniform vec2 uCanvasSize;
uniform vec2 uSvgSize;
uniform float uBaseRadiusSvg;
uniform float uZoom;

uniform float uLambdaRad;
uniform float uCosPhi;
uniform float uSinPhi;

uniform float uHasDetail;
uniform vec4 uDetailBounds;

uniform float uShowClouds;
uniform float uCloudDriftRad;
uniform float uCloudOpacity;

uniform float uAmbientFloor;
uniform float uLightGain;
uniform float uRimStrength;

const float PI = 3.141592653589793;
const float INV_TWO_PI = 0.15915494309189535;
const float INV_PI = 0.3183098861837907;
const float QUARTER_PI = 0.7853981633974483;
const float MAX_MERC_LAT = 1.4844222297453322;

void main() {
  float px = vUv.x * uCanvasSize.x;
  float py = vUv.y * uCanvasSize.y;
  float scaleToCanvas = uCanvasSize.x / uSvgSize.x;
  float cx = uCanvasSize.x * 0.5;
  float cy = (uSvgSize.y * 0.5) * scaleToCanvas;
  float R = uBaseRadiusSvg * uZoom * scaleToCanvas;

  float y1 = (px - cx) / R;
  float z1 = -(py - cy) / R;
  float r2 = y1 * y1 + z1 * z1;
  if (r2 > 1.0) discard;

  float rDist = sqrt(r2);
  float x1 = sqrt(max(0.0, 1.0 - r2));

  float x0 = x1 * uCosPhi + z1 * uSinPhi;
  float y0 = y1;
  float z0 = z1 * uCosPhi - x1 * uSinPhi;

  float lat = asin(clamp(z0, -1.0, 1.0));
  float lon = atan(y0, x0) - uLambdaRad;

  float u = fract((lon + PI) * INV_TWO_PI);
  float latClamped = clamp(lat, -MAX_MERC_LAT, MAX_MERC_LAT);
  float v = 0.5 - log(tan(QUARTER_PI + latClamped * 0.5)) * INV_TWO_PI;

  vec3 earthCol = texture2D(uBaseTex, vec2(u, v)).rgb;

  if (uHasDetail > 0.5) {
    float du = fract(u - uDetailBounds.x);
    float dv = v - uDetailBounds.y;
    if (du >= 0.0 && du < uDetailBounds.z && dv >= 0.0 && dv < uDetailBounds.w) {
      vec4 detailSample = texture2D(uDetailTex, vec2(du / uDetailBounds.z, dv / uDetailBounds.w));
      earthCol = mix(earthCol, detailSample.rgb, step(0.95, detailSample.a));
    }
  }

  float sun = clamp(x1 * 0.85 - y1 * 0.24 + z1 * 0.26, 0.0, 1.0);
  float shade = uAmbientFloor + uLightGain * sun;
  vec3 col = earthCol * shade;

  if (uShowClouds > 0.5 && uCloudOpacity > 0.005) {
    float cu = fract((lon - uCloudDriftRad + PI) * INV_TWO_PI);
    float cv = 0.5 - lat * INV_PI;
    float cDens = texture2D(uCloudTex, vec2(cu, cv)).r;
    float cAlpha = cDens * uCloudOpacity;
    float cLit = 0.97 * (0.72 + 0.30 * sun);
    vec3 cloudCol = vec3(cLit, min(1.0, cLit * 1.01), min(1.0, cLit * 1.03));
    col = mix(col, cloudCol, cAlpha);
  }

  if (rDist > 0.78) {
    float rim = (rDist - 0.78) / 0.22;
    float scatter = rim * rim * uRimStrength;
    col = mix(col, vec3(0.22, 0.70, 0.97), scatter);
  }

  float edgePx = (1.0 - rDist) * R;
  float alpha = clamp(edgePx / 1.35, 0.0, 1.0);
  gl_FragColor = vec4(col * alpha, alpha);
}
`;

interface GlState {
  gl: WebGLRenderingContext;
  program: WebGLProgram;
  baseTex: WebGLTexture;
  detailTex: WebGLTexture;
  cloudTex: WebGLTexture;
  patchCanvas: HTMLCanvasElement;
  patchCtx: CanvasRenderingContext2D;
  uploadedMosaicLevel: number;
  uploadedPatchKey: string;
  uniforms: Record<string, WebGLUniformLocation | null>;
}

function compileShader(gl: WebGLRenderingContext, type: number, src: string): WebGLShader | null {
  const s = gl.createShader(type);
  if (!s) return null;
  gl.shaderSource(s, src);
  gl.compileShader(s);
  if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) {
    gl.deleteShader(s);
    return null;
  }
  return s;
}

function createLinearTexture(
  gl: WebGLRenderingContext,
  wrapS: number,
  wrapT: number
): WebGLTexture | null {
  const tex = gl.createTexture();
  if (!tex) return null;
  gl.bindTexture(gl.TEXTURE_2D, tex);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, wrapS);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, wrapT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
  return tex;
}

export const GlobeSatelliteCanvas: React.FC<GlobeSatelliteCanvasProps> = ({
  rotation,
  zoom,
  baseRadiusSvg,
  svgWidth,
  svgHeight,
  stageWidth,
  stageHeight,
  darkMode,
  isInteracting = false,
  showClouds = false,
  cloudDriftDeg = 0,
  cloudOpacity = 0.72,
  onTextureReady,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const glStateRef = useRef<GlState | null>(null);
  const cpuFallbackRef = useRef<boolean>(false);
  const cpuBufferRef = useRef<{ w: number; h: number; img: ImageData } | null>(null);
  const cpuMosaicDataRef = useRef<{ level: number; data: Uint8ClampedArray; w: number; h: number } | null>(null);

  const [mosaic, setMosaic] = useState<MosaicCanvasData | null>(cachedMosaic);
  const [hdRevision, setHdRevision] = useState(0);

  const dpr =
    typeof window !== 'undefined' ? Math.min(2, window.devicePixelRatio || 1) : 1;
  const fullTargetW = Math.min(
    1680,
    Math.max(1024, Math.round(Math.max(stageWidth, 512) * dpr))
  );

  // Full HiDPI resolution in WebGL; lightweight downscale only if falling back to CPU 2D
  const effectiveScale = cpuFallbackRef.current && isInteracting ? 0.45 : 1;
  const renderW = Math.max(480, Math.round(fullTargetW * effectiveScale));
  const renderH = Math.max(
    1,
    Math.round(renderW * (svgHeight / svgWidth))
  );

  useEffect(() => {
    if (cachedMosaic) {
      setMosaic(cachedMosaic);
      onTextureReady?.(true);
    }
    const handleMosaic = (m: MosaicCanvasData) => {
      setMosaic(m);
      onTextureReady?.(true);
    };
    const handleHd = () => {
      setHdRevision((r) => r + 1);
    };
    mosaicListeners.add(handleMosaic);
    hdTileListeners.add(handleHd);
    ensureMosaicLoaded(true);
    return () => {
      mosaicListeners.delete(handleMosaic);
      hdTileListeners.delete(handleHd);
    };
  }, [onTextureReady]);

  // Fetch on-demand z=5/z=6 regional HD tiles when zoomed in
  useEffect(() => {
    if (zoom < 1.75) return;
    const delay = isInteracting ? 120 : 15;
    const timer = window.setTimeout(() => {
      requestDetailPatchTiles(rotation, zoom);
    }, delay);
    return () => window.clearTimeout(timer);
  }, [rotation, zoom, isInteracting]);

  // Render via GPU WebGL (or automatic CPU 2D fallback if WebGL unavailable)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !mosaic) return;

    if (canvas.width !== renderW || canvas.height !== renderH) {
      canvas.width = renderW;
      canvas.height = renderH;
    }

    // Initialize WebGL once
    if (!glStateRef.current && !cpuFallbackRef.current) {
      const gl = canvas.getContext('webgl', {
        alpha: true,
        antialias: true,
        depth: false,
        stencil: false,
        powerPreference: 'high-performance',
      });

      if (gl) {
        const vs = compileShader(gl, gl.VERTEX_SHADER, VERT_SHADER_SRC);
        const fs = compileShader(gl, gl.FRAGMENT_SHADER, FRAG_SHADER_SRC);
        const prog = vs && fs ? gl.createProgram() : null;
        if (vs && fs && prog) {
          gl.attachShader(prog, vs);
          gl.attachShader(prog, fs);
          gl.linkProgram(prog);
          if (gl.getProgramParameter(prog, gl.LINK_STATUS)) {
            const vbo = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, vbo);
            gl.bufferData(
              gl.ARRAY_BUFFER,
              new Float32Array([-1, -1, 1, -1, -1, 1, 1, 1]),
              gl.STATIC_DRAW
            );
            const aPos = gl.getAttribLocation(prog, 'aPos');
            gl.enableVertexAttribArray(aPos);
            gl.vertexAttribPointer(aPos, 2, gl.FLOAT, false, 0, 0);

            const baseTex = createLinearTexture(gl, gl.REPEAT, gl.CLAMP_TO_EDGE);
            const detailTex = createLinearTexture(gl, gl.CLAMP_TO_EDGE, gl.CLAMP_TO_EDGE);
            const cloudTex = createLinearTexture(gl, gl.REPEAT, gl.CLAMP_TO_EDGE);
            const patchCanvas = document.createElement('canvas');
            patchCanvas.width = TILE_PX * 4;
            patchCanvas.height = TILE_PX * 4;
            const patchCtx = patchCanvas.getContext('2d');

            if (baseTex && detailTex && cloudTex && patchCtx) {
              gl.bindTexture(gl.TEXTURE_2D, cloudTex);
              gl.texImage2D(
                gl.TEXTURE_2D,
                0,
                gl.RGBA,
                CLOUD_W,
                CLOUD_H,
                0,
                gl.RGBA,
                gl.UNSIGNED_BYTE,
                getGlobalCloudRgba()
              );

              gl.bindTexture(gl.TEXTURE_2D, detailTex);
              gl.texImage2D(
                gl.TEXTURE_2D,
                0,
                gl.RGBA,
                1,
                1,
                0,
                gl.RGBA,
                gl.UNSIGNED_BYTE,
                new Uint8Array([0, 0, 0, 0])
              );

              const uniformNames = [
                'uBaseTex',
                'uDetailTex',
                'uCloudTex',
                'uCanvasSize',
                'uSvgSize',
                'uBaseRadiusSvg',
                'uZoom',
                'uLambdaRad',
                'uCosPhi',
                'uSinPhi',
                'uHasDetail',
                'uDetailBounds',
                'uShowClouds',
                'uCloudDriftRad',
                'uCloudOpacity',
                'uAmbientFloor',
                'uLightGain',
                'uRimStrength',
              ];
              const uniforms: Record<string, WebGLUniformLocation | null> = {};
              for (const name of uniformNames) {
                uniforms[name] = gl.getUniformLocation(prog, name);
              }

              glStateRef.current = {
                gl,
                program: prog,
                baseTex,
                detailTex,
                cloudTex,
                patchCanvas,
                patchCtx,
                uploadedMosaicLevel: -1,
                uploadedPatchKey: '',
                uniforms,
              };
            }
          }
        }
      }

      if (!glStateRef.current) {
        cpuFallbackRef.current = true;
      }
    }

    const glState = glStateRef.current;
    if (glState) {
      const { gl, program, baseTex, detailTex, cloudTex, patchCanvas, patchCtx, uniforms } =
        glState;

      // Upload global satellite mosaic when a sharper level finishes loading
      if (glState.uploadedMosaicLevel < mosaic.level) {
        const maxTexSize = gl.getParameter(gl.MAX_TEXTURE_SIZE) as number;
        if (mosaic.canvas.width <= maxTexSize) {
          gl.bindTexture(gl.TEXTURE_2D, baseTex);
          gl.texImage2D(
            gl.TEXTURE_2D,
            0,
            gl.RGBA,
            gl.RGBA,
            gl.UNSIGNED_BYTE,
            mosaic.canvas
          );
          glState.uploadedMosaicLevel = mosaic.level;
        }
      }

      // Compose & upload 4x4 regional HD patch only when zoomed in and patch changes
      const patch = getPatchBounds(rotation, zoom);
      let hasDetail = 0;
      let detailBounds: [number, number, number, number] = [0, 0, 1, 1];
      if (patch && hdImageCache.size > 0) {
        const patchKey = `${patch.z}:${patch.startTx}:${patch.startTy}:${hdRevision}`;
        if (glState.uploadedPatchKey !== patchKey) {
          patchCtx.clearRect(0, 0, patchCanvas.width, patchCanvas.height);
          let drawn = 0;
          for (let dy = 0; dy < 4; dy++) {
            const ty = patch.startTy + dy;
            for (let dx = 0; dx < 4; dx++) {
              const tx = (patch.startTx + dx) % patch.n;
              const img = hdImageCache.get(`${patch.z}/${tx}/${ty}`);
              if (img) {
                patchCtx.drawImage(img, dx * TILE_PX, dy * TILE_PX, TILE_PX, TILE_PX);
                drawn++;
              }
            }
          }
          if (drawn > 0) {
            gl.bindTexture(gl.TEXTURE_2D, detailTex);
            gl.texImage2D(
              gl.TEXTURE_2D,
              0,
              gl.RGBA,
              gl.RGBA,
              gl.UNSIGNED_BYTE,
              patchCanvas
            );
            glState.uploadedPatchKey = patchKey;
          }
        }
        if (glState.uploadedPatchKey.startsWith(`${patch.z}:${patch.startTx}:${patch.startTy}:`)) {
          hasDetail = 1;
          detailBounds = [
            patch.startTx / patch.n,
            patch.startTy / patch.n,
            4 / patch.n,
            4 / patch.n,
          ];
        }
      }

      gl.viewport(0, 0, renderW, renderH);
      gl.clearColor(0, 0, 0, 0);
      gl.clear(gl.COLOR_BUFFER_BIT);
      gl.useProgram(program);

      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, baseTex);
      gl.uniform1i(uniforms.uBaseTex, 0);

      gl.activeTexture(gl.TEXTURE1);
      gl.bindTexture(gl.TEXTURE_2D, detailTex);
      gl.uniform1i(uniforms.uDetailTex, 1);

      gl.activeTexture(gl.TEXTURE2);
      gl.bindTexture(gl.TEXTURE_2D, cloudTex);
      gl.uniform1i(uniforms.uCloudTex, 2);

      const lambdaRad = rotation[0] * DEG_TO_RAD;
      const phiRad = rotation[1] * DEG_TO_RAD;

      gl.uniform2f(uniforms.uCanvasSize, renderW, renderH);
      gl.uniform2f(uniforms.uSvgSize, svgWidth, svgHeight);
      gl.uniform1f(uniforms.uBaseRadiusSvg, baseRadiusSvg);
      gl.uniform1f(uniforms.uZoom, zoom);
      gl.uniform1f(uniforms.uLambdaRad, lambdaRad);
      gl.uniform1f(uniforms.uCosPhi, Math.cos(phiRad));
      gl.uniform1f(uniforms.uSinPhi, Math.sin(phiRad));
      gl.uniform1f(uniforms.uHasDetail, hasDetail);
      gl.uniform4f(
        uniforms.uDetailBounds,
        detailBounds[0],
        detailBounds[1],
        detailBounds[2],
        detailBounds[3]
      );
      gl.uniform1f(uniforms.uShowClouds, showClouds ? 1 : 0);
      gl.uniform1f(uniforms.uCloudDriftRad, cloudDriftDeg * DEG_TO_RAD);
      gl.uniform1f(uniforms.uCloudOpacity, Math.max(0, Math.min(1, cloudOpacity)));
      gl.uniform1f(uniforms.uAmbientFloor, darkMode ? 0.68 : 0.80);
      gl.uniform1f(uniforms.uLightGain, darkMode ? 0.34 : 0.24);
      gl.uniform1f(uniforms.uRimStrength, darkMode ? 0.34 : 0.22);

      gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
      return;
    }

    // CPU 2D Canvas Fallback (only if WebGL context could not be initialized)
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    if (
      !cpuMosaicDataRef.current ||
      cpuMosaicDataRef.current.level !== mosaic.level
    ) {
      const mCtx = mosaic.canvas.getContext('2d', { willReadFrequently: true });
      if (!mCtx) return;
      const imgData = mCtx.getImageData(
        0,
        0,
        mosaic.canvas.width,
        mosaic.canvas.height
      );
      cpuMosaicDataRef.current = {
        level: mosaic.level,
        data: imgData.data,
        w: mosaic.canvas.width,
        h: mosaic.canvas.height,
      };
    }

    const srcInfo = cpuMosaicDataRef.current;
    if (
      !cpuBufferRef.current ||
      cpuBufferRef.current.w !== renderW ||
      cpuBufferRef.current.h !== renderH
    ) {
      cpuBufferRef.current = {
        w: renderW,
        h: renderH,
        img: ctx.createImageData(renderW, renderH),
      };
    }

    const outImg = cpuBufferRef.current.img;
    const dst = outImg.data;
    dst.fill(0);

    const src = srcInfo.data;
    const srcW = srcInfo.w;
    const srcH = srcInfo.h;
    const scaleToCanvas = renderW / svgWidth;
    const cx = renderW / 2;
    const cy = (svgHeight / 2) * scaleToCanvas;
    const R = baseRadiusSvg * zoom * scaleToCanvas;
    const invR = 1 / R;

    const lambdaRad = rotation[0] * DEG_TO_RAD;
    const phiRad = rotation[1] * DEG_TO_RAD;
    const cosPhi = Math.cos(phiRad);
    const sinPhi = Math.sin(phiRad);
    const minY = Math.max(0, Math.floor(cy - R));
    const maxY = Math.min(renderH - 1, Math.ceil(cy + R));
    const ambientFloor = darkMode ? 0.68 : 0.80;
    const lightGain = darkMode ? 0.34 : 0.24;
    const cloudRgba = showClouds ? getGlobalCloudRgba() : null;
    const cloudDriftRad = cloudDriftDeg * DEG_TO_RAD;

    for (let py = minY; py <= maxY; py++) {
      const z1 = -(py - cy) * invR;
      const z1Sq = z1 * z1;
      if (z1Sq > 1) continue;
      const maxXSpan = Math.sqrt(1 - z1Sq) * R;
      const minX = Math.max(0, Math.floor(cx - maxXSpan));
      const maxX = Math.min(renderW - 1, Math.ceil(cx + maxXSpan));

      for (let px = minX; px <= maxX; px++) {
        const y1 = (px - cx) * invR;
        const r2 = y1 * y1 + z1Sq;
        if (r2 > 1) continue;
        const x1 = Math.sqrt(1 - r2);
        const x0 = x1 * cosPhi + z1 * sinPhi;
        const z0 = z1 * cosPhi - x1 * sinPhi;
        const lat = Math.asin(z0 > 1 ? 1 : z0 < -1 ? -1 : z0);
        const lon = Math.atan2(y1, x0) - lambdaRad;
        let u = (lon + Math.PI) * INV_TWO_PI;
        u -= Math.floor(u);
        const latClamped =
          lat > MAX_MERC_LAT ? MAX_MERC_LAT : lat < -MAX_MERC_LAT ? -MAX_MERC_LAT : lat;
        const v = 0.5 - Math.log(Math.tan(QUARTER_PI + latClamped * 0.5)) * INV_TWO_PI;
        const sx = Math.min(srcW - 1, Math.max(0, (u * srcW) | 0));
        const sy = Math.min(srcH - 1, Math.max(0, (v * srcH) | 0));
        const sIdx = (sy * srcW + sx) * 4;
        const sun = x1 * 0.85 - y1 * 0.24 + z1 * 0.26;
        const shade = ambientFloor + lightGain * (sun < 0 ? 0 : sun > 1 ? 1 : sun);
        let rOut = src[sIdx] * shade;
        let gOut = src[sIdx + 1] * shade;
        let bOut = src[sIdx + 2] * shade;

        if (cloudRgba) {
          let cu = (lon - cloudDriftRad + Math.PI) * INV_TWO_PI;
          cu -= Math.floor(cu);
          const cv = 0.5 - lat * INV_PI;
          const cxPix = Math.min(CLOUD_W - 1, Math.max(0, (cu * CLOUD_W) | 0));
          const cyPix = Math.min(CLOUD_H - 1, Math.max(0, (cv * CLOUD_H) | 0));
          const cAlpha = (cloudRgba[(cyPix * CLOUD_W + cxPix) * 4] / 255) * cloudOpacity;
          if (cAlpha > 0.01) {
            const cLit = 248 * (0.72 + 0.3 * (sun < 0 ? 0 : sun > 1 ? 1 : sun));
            rOut = rOut * (1 - cAlpha) + cLit * cAlpha;
            gOut = gOut * (1 - cAlpha) + cLit * cAlpha;
            bOut = bOut * (1 - cAlpha) + cLit * cAlpha;
          }
        }

        const dIdx = (py * renderW + px) * 4;
        dst[dIdx] = rOut > 255 ? 255 : rOut | 0;
        dst[dIdx + 1] = gOut > 255 ? 255 : gOut | 0;
        dst[dIdx + 2] = bOut > 255 ? 255 : bOut | 0;
        dst[dIdx + 3] = r2 > 0.988 ? ((1 - r2) / 0.012) * 255 : 255;
      }
    }
    ctx.putImageData(outImg, 0, 0);
  }, [
    mosaic,
    hdRevision,
    rotation,
    zoom,
    baseRadiusSvg,
    svgWidth,
    svgHeight,
    renderW,
    renderH,
    darkMode,
    showClouds,
    cloudDriftDeg,
    cloudOpacity,
  ]);

  if (!mosaic) return null;

  return (
    <canvas
      ref={canvasRef}
      width={renderW}
      height={renderH}
      className="absolute inset-0 w-full h-full pointer-events-none"
    />
  );
};
