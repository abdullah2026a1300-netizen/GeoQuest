import React, { useState } from 'react';
import {
  X,
  Play,
  Globe,
  Compass,
  MapPin,
  Shield,
  Timer,
  Infinity as InfinityIcon,
  Zap,
  Award,
  Landmark,
  Layers,
} from 'lucide-react';
import {
  ContinentId,
  DifficultySetting,
  GameMode,
  GameSettings,
  PlayerProfile,
  QuestionCategoryId,
} from '../types/game';
import {
  CONTINENT_LABELS,
  DIFFICULTY_LABELS,
  MODE_INFO,
  UI_TEXT,
  t,
} from '../data/i18n';
import { MILLION_CATEGORIES } from '../data/millionCategories';

interface ChallengesModalProps {
  settings: GameSettings;
  profile: PlayerProfile;
  onClose: () => void;
  onStartMode: (
    mode: GameMode,
    continent: ContinentId,
    difficulty: DifficultySetting,
    category?: QuestionCategoryId
  ) => void;
}

const MODE_ORDER: GameMode[] = [
  'quick_play',
  'world_challenge',
  'country_hunt',
  'capital_hunt',
  'landmark_hunt',
  'neighbor_challenge',
  'continents',
  'time_attack',
  'endless',
];

const CONTINENTS_LIST: Exclude<ContinentId, 'all'>[] = [
  'asia',
  'africa',
  'europe',
  'north_america',
  'south_america',
  'oceania',
];

const DIFFICULTIES: DifficultySetting[] = ['mixed', 'easy', 'medium', 'hard'];

export const ChallengesModal: React.FC<ChallengesModalProps> = ({
  settings,
  profile,
  onClose,
  onStartMode,
}) => {
  const lang = settings.language;
  const dark = settings.darkMode;

  const [tab, setTab] = useState<'modes' | 'categories'>('modes');
  const [selectedMode, setSelectedMode] = useState<GameMode>('quick_play');
  const [selectedCategory, setSelectedCategory] =
    useState<QuestionCategoryId>('cat_capitals');
  const [selectedContinent, setSelectedContinent] = useState<ContinentId>('all');
  const [selectedDifficulty, setSelectedDifficulty] = useState<DifficultySetting>(
    settings.difficulty
  );

  const getModeIcon = (mode: GameMode) => {
    switch (mode) {
      case 'quick_play':
        return <Zap className="w-4 h-4 text-amber-500" />;
      case 'world_challenge':
        return <Award className="w-4 h-4 text-amber-400" />;
      case 'country_hunt':
        return <Compass className="w-4 h-4 text-sky-400" />;
      case 'capital_hunt':
        return <MapPin className="w-4 h-4 text-emerald-400" />;
      case 'landmark_hunt':
        return <Landmark className="w-4 h-4 text-amber-400" />;
      case 'neighbor_challenge':
        return <Shield className="w-4 h-4 text-indigo-400" />;
      case 'continents':
        return <Globe className="w-4 h-4 text-teal-400" />;
      case 'time_attack':
        return <Timer className="w-4 h-4 text-rose-400" />;
      case 'endless':
        return <InfinityIcon className="w-4 h-4 text-amber-500" />;
    }
  };

  const effectiveContinent =
    tab === 'modes' && selectedMode === 'continents' && selectedContinent === 'all'
      ? 'asia'
      : selectedContinent;

  const handleLaunch = () => {
    if (tab === 'categories') {
      onStartMode('quick_play', effectiveContinent, selectedDifficulty, selectedCategory);
    } else {
      onStartMode(selectedMode, effectiveContinent, selectedDifficulty);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div
        className={`w-full max-w-4xl max-h-[90vh] rounded-2xl border shadow-2xl flex flex-col overflow-hidden ${
          dark
            ? 'bg-slate-900 border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header with Mode vs 1M Categories Switcher */}
        <div
          className={`flex flex-wrap items-center justify-between gap-3 px-6 py-4 border-b ${
            dark ? 'border-slate-800' : 'border-slate-200'
          }`}
        >
          <div className="flex flex-wrap items-center gap-3">
            <h2 className="font-display text-xl font-bold">
              {t(UI_TEXT.selectMode, lang)}
            </h2>
            <div
              className={`flex items-center gap-1 p-1 rounded-xl border ${
                dark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
              }`}
            >
              <button
                type="button"
                onClick={() => setTab('modes')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                  tab === 'modes'
                    ? 'bg-amber-500 text-slate-950'
                    : dark
                    ? 'text-slate-300 hover:text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t(UI_TEXT.gameModesTab, lang)}
              </button>
              <button
                type="button"
                onClick={() => setTab('categories')}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                  tab === 'categories'
                    ? 'bg-amber-500 text-slate-950'
                    : dark
                    ? 'text-slate-300 hover:text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{t(UI_TEXT.millionBankTitle, lang)}</span>
              </button>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            aria-label={t(UI_TEXT.close, lang)}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
              dark ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-100 text-slate-500'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {tab === 'modes' ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {MODE_ORDER.map((mode) => {
                const info = MODE_INFO[mode];
                const isSelected = selectedMode === mode;
                const best = profile.modeBestScores[mode];
                return (
                  <button
                    key={mode}
                    type="button"
                    onClick={() => {
                      setSelectedMode(mode);
                      if (mode === 'continents' && selectedContinent === 'all') {
                        setSelectedContinent('asia');
                      }
                    }}
                    className={`text-start p-4 rounded-xl border transition-colors cursor-pointer ${
                      isSelected
                        ? dark
                          ? 'bg-amber-500/10 border-amber-500 text-white'
                          : 'bg-amber-50 border-amber-500 text-slate-900'
                        : dark
                        ? 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                        : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 mb-1.5">
                      <div className="flex items-center gap-2 font-bold text-sm">
                        {getModeIcon(mode)}
                        <span>{t(info.title, lang)}</span>
                      </div>
                      <span
                        className={`text-xs font-mono-tabular ${
                          dark ? 'text-slate-400' : 'text-slate-500'
                        }`}
                      >
                        {t(info.badge, lang)}
                      </span>
                    </div>
                    <p
                      className={`text-xs leading-relaxed ${
                        dark ? 'text-slate-400' : 'text-slate-600'
                      }`}
                    >
                      {t(info.desc, lang)}
                    </p>
                    {best !== undefined && best > 0 && (
                      <div className="mt-2 text-[11px] font-mono-tabular text-amber-500">
                        {t(UI_TEXT.bestScore, lang)}: {best.toLocaleString()}
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                <span className={dark ? 'text-slate-400' : 'text-slate-600'}>
                  {lang === 'ar'
                    ? 'اختر أي قسم من الأقسام العشرة لبدء جولة مباشرة على الخريطة:'
                    : lang === 'tr'
                    ? 'Harita üzerinde canlı bir tur başlatmak için 10 kategoriden birini seçin:'
                    : 'Choose any of the 10 structured categories to launch a live map round:'}
                </span>
                <span className="font-mono-tabular font-bold text-amber-500">
                  {t(UI_TEXT.totalQuestionsQuota, lang)}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {MILLION_CATEGORIES.map((cat) => {
                  const isSelected = selectedCategory === cat.id;
                  return (
                    <button
                      key={cat.id}
                      type="button"
                      onClick={() => setSelectedCategory(cat.id)}
                      className={`text-start p-4 rounded-xl border transition-colors cursor-pointer ${
                        isSelected
                          ? dark
                            ? 'bg-amber-500/10 border-amber-500 text-white'
                            : 'bg-amber-50 border-amber-500 text-slate-900'
                          : dark
                          ? 'bg-slate-950/50 border-slate-800 hover:border-slate-700'
                          : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <div className="font-bold text-sm">
                          <span className="font-mono-tabular text-amber-500 me-1.5">
                            {String(cat.index).padStart(2, '0')}.
                          </span>
                          <span>{t(cat.title, lang)}</span>
                        </div>
                        <span
                          className={`font-mono-tabular text-xs font-semibold shrink-0 ${
                            dark ? 'text-sky-400' : 'text-sky-600'
                          }`}
                        >
                          {cat.questionQuota.toLocaleString()}
                        </span>
                      </div>
                      <p
                        className={`text-xs leading-relaxed ${
                          dark ? 'text-slate-400' : 'text-slate-600'
                        }`}
                      >
                        {t(cat.description, lang)}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Continent Selector */}
          <div className="space-y-2.5">
            <div className="text-sm font-semibold">
              {t(UI_TEXT.selectContinent, lang)}
            </div>
            <div className="flex flex-wrap gap-2">
              {(tab === 'categories' || selectedMode !== 'continents') && (
                <button
                  type="button"
                  onClick={() => setSelectedContinent('all')}
                  className={`h-10 px-3.5 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    effectiveContinent === 'all'
                      ? 'bg-amber-500 border-amber-500 text-slate-950'
                      : dark
                      ? 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-600'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {t(CONTINENT_LABELS.all, lang)}
                </button>
              )}
              {CONTINENTS_LIST.map((cont) => (
                <button
                  key={cont}
                  type="button"
                  onClick={() => setSelectedContinent(cont)}
                  className={`h-10 px-3.5 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    effectiveContinent === cont
                      ? 'bg-amber-500 border-amber-500 text-slate-950'
                      : dark
                      ? 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-600'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {t(CONTINENT_LABELS[cont], lang)}
                </button>
              ))}
            </div>
          </div>

          {/* Difficulty Selector */}
          <div className="space-y-2.5">
            <div className="text-sm font-semibold">
              {t(UI_TEXT.selectDifficulty, lang)}
            </div>
            <div className="flex flex-wrap gap-2">
              {DIFFICULTIES.map((diff) => (
                <button
                  key={diff}
                  type="button"
                  onClick={() => setSelectedDifficulty(diff)}
                  className={`h-10 px-4 rounded-xl border text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                    selectedDifficulty === diff
                      ? 'bg-sky-500 border-sky-500 text-slate-950'
                      : dark
                      ? 'bg-slate-950/60 border-slate-800 text-slate-300 hover:border-slate-600'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {t(DIFFICULTY_LABELS[diff], lang)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Launch CTA */}
        <div
          className={`px-6 py-4 border-t flex items-center justify-end gap-3 ${
            dark ? 'border-slate-800 bg-slate-950/40' : 'border-slate-200 bg-slate-50'
          }`}
        >
          <button
            type="button"
            onClick={onClose}
            className={`h-11 px-4 rounded-xl text-sm font-medium transition-colors cursor-pointer ${
              dark ? 'text-slate-300 hover:bg-slate-800' : 'text-slate-600 hover:bg-slate-200'
            }`}
          >
            {t(UI_TEXT.close, lang)}
          </button>
          <button
            type="button"
            onClick={handleLaunch}
            className="h-11 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm inline-flex items-center gap-2 transition-colors whitespace-nowrap cursor-pointer"
          >
            <Play className="w-4 h-4" />
            <span>{t(UI_TEXT.launchChallenge, lang)}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
