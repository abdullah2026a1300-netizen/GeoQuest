import React from 'react';

interface GeoQuestLogoProps {
  size?: 'sm' | 'lg';
  darkMode?: boolean;
}

export const GeoQuestLogo: React.FC<GeoQuestLogoProps> = ({
  size = 'lg',
  darkMode = true,
}) => {
  const iconSize = size === 'lg' ? 52 : 34;

  return (
    <div className="inline-flex items-center gap-3.5 select-none">
      <svg
        width={iconSize}
        height={iconSize}
        viewBox="0 0 64 64"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="shrink-0"
      >
        {/* Outer compass ring */}
        <circle
          cx="32"
          cy="32"
          r="28"
          stroke="#F59E0B"
          strokeWidth="2.5"
          strokeOpacity="0.9"
        />
        <circle
          cx="32"
          cy="32"
          r="21"
          fill={darkMode ? '#0F223D' : '#E2E8F0'}
          stroke={darkMode ? '#38BDF8' : '#0284C7'}
          strokeWidth="1.5"
          strokeOpacity="0.55"
        />
        {/* Meridians & Equator */}
        <ellipse
          cx="32"
          cy="32"
          rx="10"
          ry="21"
          stroke={darkMode ? '#60A5FA' : '#0369A1'}
          strokeWidth="1.3"
          strokeOpacity="0.5"
        />
        <path
          d="M11 32H53"
          stroke={darkMode ? '#60A5FA' : '#0369A1'}
          strokeWidth="1.3"
          strokeOpacity="0.5"
        />
        {/* Compass Needle */}
        <path d="M32 13L38 32L32 28.5L26 32L32 13Z" fill="#F59E0B" />
        <path
          d="M32 51L26 32L32 35.5L38 32L32 51Z"
          fill={darkMode ? '#94A3B8' : '#475569'}
        />
        <circle cx="32" cy="32" r="3" fill="#FFFFFF" />
      </svg>
      <div className="flex flex-col leading-none">
        <span
          className={`font-display font-extrabold tracking-tight ${
            size === 'lg' ? 'text-3xl sm:text-4xl' : 'text-xl'
          } ${darkMode ? 'text-white' : 'text-slate-900'}`}
        >
          Geo<span className="text-amber-500">Quest</span>
        </span>
      </div>
    </div>
  );
};
