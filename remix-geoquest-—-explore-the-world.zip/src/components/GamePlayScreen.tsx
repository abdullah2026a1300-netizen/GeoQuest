import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Clock,
  Heart,
  Lightbulb,
  SkipForward,
  Pause,
  Play,
  Home,
  ChevronRight,
  ChevronLeft,
  PanelRightOpen,
  PanelRightClose,
  CheckCircle2,
  AlertCircle,
  Navigation,
} from 'lucide-react';
import {
  ContinentId,
  DifficultySetting,
  GameMode,
  GameSettings,
  GeoQuestion,
  MapArc,
  MapMarker,
  QuestionCategoryId,
  RoundResult,
} from '../types/game';
import { CATEGORY_BY_ID } from '../data/millionCategories';
import {
  DIFFICULTY_LABELS,
  MODE_INFO,
  QUESTION_TYPE_LABELS,
  UI_TEXT,
  locCountryName,
  t,
} from '../data/i18n';
import { generateQuestionPool } from '../data/questionGenerator';
import { COUNTRY_BY_ID } from '../data/countriesData';
import {
  CONTINENT_VIEWPORTS,
  getBearingDirection,
  haversineDistanceKm,
} from '../utils/geoMath';
import { soundEngine } from '../utils/sound';
import { CountryFlagBadge } from './CountryFlagBadge';
import { MapClickPayload, WorldMap } from './map/WorldMap';

const MAX_ATTEMPTS_PER_QUESTION = 3;
const MICROSTATE_IDS = new Set([
  '048',
  '702',
  '470',
  '462',
  '634',
  '275',
  '422',
  '442',
]);

interface GamePlayScreenProps {
  settings: GameSettings;
  mode: GameMode;
  continent: ContinentId;
  difficulty: DifficultySetting;
  category?: QuestionCategoryId;
  onFinishGame: (params: {
    score: number;
    runBestStreak: number;
    results: RoundResult[];
  }) => void;
  onExitToMenu: () => void;
}

export const GamePlayScreen: React.FC<GamePlayScreenProps> = ({
  settings,
  mode,
  continent,
  difficulty,
  category,
  onFinishGame,
  onExitToMenu,
}) => {
  const lang = settings.language;
  const dark = settings.darkMode;

  const isTimeAttack = mode === 'time_attack';
  const isEndless = mode === 'endless';

  const targetCount = useMemo(() => {
    if (mode === 'quick_play') return 10;
    if (mode === 'world_challenge') return 50;
    if (isTimeAttack || isEndless) return 80;
    return settings.questionCount;
  }, [mode, isTimeAttack, isEndless, settings.questionCount]);

  const perQuestionSeconds = useMemo(() => {
    if (settings.gameSpeed === 'relaxed') return 45;
    if (settings.gameSpeed === 'fast') return 18;
    return 30;
  }, [settings.gameSpeed]);

  const [questions, setQuestions] = useState<GeoQuestion[]>(() =>
    generateQuestionPool({
      mode,
      continent,
      difficulty,
      count: targetCount,
      category,
    })
  );

  const [currentIdx, setCurrentIdx] = useState(0);
  const [score, setScore] = useState(0);
  const [streak, setStreak] = useState(0);
  const [runBestStreak, setRunBestStreak] = useState(0);
  const [lives, setLives] = useState(3);
  const [attemptsLeft, setAttemptsLeft] = useState(MAX_ATTEMPTS_PER_QUESTION);
  const [hintsRevealed, setHintsRevealed] = useState(0);

  const [timeLeft, setTimeLeft] = useState(
    isTimeAttack ? 90 : perQuestionSeconds
  );
  const [paused, setPaused] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(() =>
    typeof window !== 'undefined' ? window.innerWidth >= 1024 : true
  );

  // Round status
  const [roundResolved, setRoundResolved] = useState<
    null | 'correct' | 'failed' | 'timeout' | 'skipped'
  >(null);
  const [lastFeedback, setLastFeedback] = useState<{
    message: string;
    distanceKm?: number;
    direction?: string;
    guessedCountryName?: string;
    pointsBreakdown?: {
      base: number;
      speed: number;
      streak: number;
      hintPenalty: number;
      total: number;
    };
  } | null>(null);

  const [markers, setMarkers] = useState<MapMarker[]>([]);
  const [wrongCountryIds, setWrongCountryIds] = useState<string[]>([]);
  const [highlightedCountryIds, setHighlightedCountryIds] = useState<string[]>(
    []
  );
  const [arc, setArc] = useState<MapArc | null>(null);
  const [focusTarget, setFocusTarget] = useState<{
    center: [number, number];
    zoom: number;
    key: number;
  } | null>(() => {
    if (continent !== 'all') {
      const vp = CONTINENT_VIEWPORTS[continent];
      return { center: vp.center, zoom: vp.zoom, key: 1 };
    }
    return null;
  });

  const [results, setResults] = useState<RoundResult[]>([]);
  const roundStartRef = useRef<number>(Date.now());
  const finishedRef = useRef(false);

  const currentQuestion = questions[currentIdx];

  // Top up endless mode pool if player goes beyond 70 questions
  useEffect(() => {
    if (isEndless && currentIdx >= questions.length - 5) {
      const extra = generateQuestionPool({
        mode: 'endless',
        continent,
        difficulty,
        count: 30,
      });
      setQuestions((prev) => [...prev, ...extra]);
    }
  }, [isEndless, currentIdx, questions.length, continent, difficulty]);

  const finishExpedition = useCallback(
    (finalResults: RoundResult[], finalScore: number, finalBestStreak: number) => {
      if (finishedRef.current) return;
      finishedRef.current = true;
      soundEngine.playVictory();
      onFinishGame({
        score: finalScore,
        runBestStreak: finalBestStreak,
        results: finalResults,
      });
    },
    [onFinishGame]
  );

  const advanceToNext = useCallback(
    (
      overrideResults?: RoundResult[],
      overrideScore?: number,
      overrideBestStreak?: number,
      overrideLives?: number
    ) => {
      const activeResults = overrideResults ?? results;
      const activeScore = overrideScore ?? score;
      const activeBestStreak = overrideBestStreak ?? runBestStreak;
      const activeLives = overrideLives ?? lives;

      if (isEndless && activeLives <= 0) {
        finishExpedition(activeResults, activeScore, activeBestStreak);
        return;
      }

      if (!isTimeAttack && !isEndless && currentIdx + 1 >= questions.length) {
        finishExpedition(activeResults, activeScore, activeBestStreak);
        return;
      }

      // Reset round state
      setCurrentIdx((idx) => idx + 1);
      setAttemptsLeft(MAX_ATTEMPTS_PER_QUESTION);
      setHintsRevealed(0);
      setRoundResolved(null);
      setLastFeedback(null);
      setMarkers([]);
      setWrongCountryIds([]);
      setHighlightedCountryIds([]);
      setArc(null);
      roundStartRef.current = Date.now();
      if (!isTimeAttack) {
        setTimeLeft(perQuestionSeconds);
      }
      if (continent !== 'all') {
        const vp = CONTINENT_VIEWPORTS[continent];
        setFocusTarget({ center: vp.center, zoom: vp.zoom, key: Date.now() });
      }
    },
    [
      continent,
      currentIdx,
      finishExpedition,
      isEndless,
      isTimeAttack,
      lives,
      perQuestionSeconds,
      questions.length,
      results,
      runBestStreak,
      score,
    ]
  );

  // Countdown Timer Effect
  useEffect(() => {
    if (paused || finishedRef.current) return;
    if (!isTimeAttack && roundResolved !== null) return;

    const timer = window.setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => window.clearInterval(timer);
  }, [paused, isTimeAttack, roundResolved]);

  // Handle Time Reaching Zero
  useEffect(() => {
    if (timeLeft > 0 || finishedRef.current) return;

    if (isTimeAttack) {
      soundEngine.playTimeUp();
      finishExpedition(results, score, runBestStreak);
      return;
    }

    if (roundResolved === null && currentQuestion) {
      soundEngine.playTimeUp();
      setRoundResolved('timeout');
      setStreak(0);
      const nextLives = isEndless ? lives - 1 : lives;
      if (isEndless) setLives(nextLives);

      if (currentQuestion.targetCountryId) {
        setHighlightedCountryIds([currentQuestion.targetCountryId]);
      }
      setMarkers((prev) => [
        ...prev,
        {
          id: 'target-reveal',
          coordinates: currentQuestion.coordinates,
          kind: 'target',
        },
      ]);
      setFocusTarget({
        center: currentQuestion.coordinates,
        zoom: 3.0,
        key: Date.now(),
      });
      setLastFeedback({
        message: t(UI_TEXT.timeUpFeedback, lang),
      });

      const entry: RoundResult = {
        question: currentQuestion,
        solved: false,
        skipped: false,
        timedOut: true,
        attemptsUsed: MAX_ATTEMPTS_PER_QUESTION - attemptsLeft,
        hintsUsed: hintsRevealed,
        pointsEarned: 0,
        timeSpentSec: perQuestionSeconds,
      };
      setResults((prev) => [...prev, entry]);
    }
  }, [
    timeLeft,
    isTimeAttack,
    roundResolved,
    currentQuestion,
    results,
    score,
    runBestStreak,
    finishExpedition,
    isEndless,
    lives,
    lang,
    attemptsLeft,
    hintsRevealed,
    perQuestionSeconds,
  ]);

  // Keyboard shortcuts (Esc to pause, Enter/Space to advance)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        setPaused((p) => !p);
      } else if (
        (e.key === 'Enter' || e.key === ' ') &&
        roundResolved !== null &&
        !paused
      ) {
        e.preventDefault();
        advanceToNext();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [advanceToNext, paused, roundResolved]);

  // Reveal target helper
  const revealCorrectTarget = useCallback(
    (q: GeoQuestion, fromCoords?: [number, number]) => {
      if (q.validCountryIds && q.validCountryIds.length > 0) {
        setHighlightedCountryIds(q.validCountryIds.slice(0, 1));
      } else if (q.targetCountryId) {
        setHighlightedCountryIds([q.targetCountryId]);
      }
      setMarkers((prev) => [
        ...prev,
        {
          id: `target-${q.id}`,
          coordinates: q.coordinates,
          kind: 'target',
        },
      ]);
      if (fromCoords) {
        setArc({ from: fromCoords, to: q.coordinates });
      }
    },
    []
  );

  // Handle Map Click Answer
  const handleMapClick = useCallback(
    (payload: MapClickPayload) => {
      if (paused || roundResolved !== null || !currentQuestion) return;

      const { coordinates, countryId, countryNameRaw } = payload;
      const distKm = haversineDistanceKm(coordinates, currentQuestion.coordinates);

      let isCorrect = false;
      if (currentQuestion.targetKind === 'country') {
        const validIds = currentQuestion.validCountryIds ?? [];
        if (countryId && validIds.includes(countryId)) {
          isCorrect = true;
        } else if (
          validIds.some((id) => MICROSTATE_IDS.has(id)) &&
          distKm <= 135
        ) {
          isCorrect = true;
        }
      } else {
        if (distKm <= currentQuestion.toleranceKm) {
          isCorrect = true;
        } else if (
          currentQuestion.type === 'capital_locate' &&
          countryId &&
          currentQuestion.targetCountryId === countryId &&
          distKm <= currentQuestion.toleranceKm * 1.35
        ) {
          isCorrect = true;
        }
      }

      if (isCorrect) {
        soundEngine.playCorrect();
        const elapsedSec = Math.max(
          1,
          Math.round((Date.now() - roundStartRef.current) / 1000)
        );
        const speedBonus = isTimeAttack
          ? 35
          : Math.round((timeLeft / perQuestionSeconds) * 60);
        const nextStreak = streak + 1;
        const streakBonus = Math.min(120, nextStreak * 15);
        const hintPenalty = hintsRevealed * 25;
        const earned = Math.max(
          25,
          currentQuestion.points + speedBonus + streakBonus - hintPenalty
        );

        const nextScore = score + earned;
        const nextBestStreak = Math.max(runBestStreak, nextStreak);
        setScore(nextScore);
        setStreak(nextStreak);
        setRunBestStreak(nextBestStreak);
        setRoundResolved('correct');

        if (countryId && currentQuestion.targetKind === 'country') {
          setHighlightedCountryIds([countryId]);
        } else if (currentQuestion.targetCountryId) {
          setHighlightedCountryIds([currentQuestion.targetCountryId]);
        }
        setMarkers((prev) => [
          ...prev,
          {
            id: `correct-${Date.now()}`,
            coordinates:
              currentQuestion.targetKind === 'coordinate'
                ? currentQuestion.coordinates
                : coordinates,
            kind: 'guess-correct',
          },
        ]);

        setLastFeedback({
          message: t(UI_TEXT.correctFeedback, lang),
          distanceKm:
            currentQuestion.targetKind === 'coordinate' ? distKm : undefined,
          pointsBreakdown: {
            base: currentQuestion.points,
            speed: speedBonus,
            streak: streakBonus,
            hintPenalty,
            total: earned,
          },
        });

        const entry: RoundResult = {
          question: currentQuestion,
          solved: true,
          skipped: false,
          timedOut: false,
          attemptsUsed: MAX_ATTEMPTS_PER_QUESTION - attemptsLeft + 1,
          hintsUsed: hintsRevealed,
          pointsEarned: earned,
          timeSpentSec: elapsedSec,
          lastDistanceKm: distKm,
          clickedCoords: coordinates,
        };
        const nextResults = [...results, entry];
        setResults(nextResults);

        if (isTimeAttack) {
          window.setTimeout(() => {
            if (!finishedRef.current) {
              advanceToNext(nextResults, nextScore, nextBestStreak);
            }
          }, 850);
        }
      } else {
        // Wrong answer: keep game going, provide distance + direction feedback!
        soundEngine.playWrong();
        const nextAttempts = attemptsLeft - 1;
        setAttemptsLeft(nextAttempts);

        const dir = getBearingDirection(
          coordinates,
          currentQuestion.coordinates,
          lang
        );
        const guessedMeta = countryId ? COUNTRY_BY_ID[countryId] : null;
        const guessedName = guessedMeta
          ? locCountryName(guessedMeta, lang)
          : countryNameRaw || undefined;

        if (countryId) {
          setWrongCountryIds((prev) =>
            prev.includes(countryId) ? prev : [...prev, countryId]
          );
        }
        setMarkers((prev) => [
          ...prev,
          {
            id: `wrong-${Date.now()}`,
            coordinates,
            kind: 'guess-wrong',
          },
        ]);

        if (nextAttempts <= 0) {
          // Attempts exhausted: reveal target location cleanly
          setRoundResolved('failed');
          setStreak(0);
          const nextLives = isEndless ? lives - 1 : lives;
          if (isEndless) setLives(nextLives);

          revealCorrectTarget(currentQuestion, coordinates);
          setFocusTarget({
            center: currentQuestion.coordinates,
            zoom: 2.8,
            key: Date.now(),
          });
          setLastFeedback({
            message: t(UI_TEXT.outOfAttempts, lang),
            distanceKm: distKm,
            direction: dir,
            guessedCountryName: guessedName,
          });

          const entry: RoundResult = {
            question: currentQuestion,
            solved: false,
            skipped: false,
            timedOut: false,
            attemptsUsed: MAX_ATTEMPTS_PER_QUESTION,
            hintsUsed: hintsRevealed,
            pointsEarned: 0,
            timeSpentSec: Math.round(
              (Date.now() - roundStartRef.current) / 1000
            ),
            lastDistanceKm: distKm,
            clickedCoords: coordinates,
          };
          const nextResults = [...results, entry];
          setResults(nextResults);

          if (isTimeAttack) {
            window.setTimeout(() => {
              if (!finishedRef.current) {
                advanceToNext(nextResults, score, runBestStreak, nextLives);
              }
            }, 1100);
          }
        } else {
          setLastFeedback({
            message: t(UI_TEXT.wrongFeedback, lang),
            distanceKm: distKm,
            direction: dir,
            guessedCountryName: guessedName,
          });
        }
      }
    },
    [
      advanceToNext,
      attemptsLeft,
      currentQuestion,
      hintsRevealed,
      isEndless,
      isTimeAttack,
      lang,
      lives,
      paused,
      perQuestionSeconds,
      results,
      revealCorrectTarget,
      roundResolved,
      runBestStreak,
      score,
      streak,
      timeLeft,
    ]
  );

  // Use Hint (progressive 4 tiers, deducts 25 pts from round potential)
  const handleHint = () => {
    if (
      paused ||
      roundResolved !== null ||
      !currentQuestion ||
      hintsRevealed >= currentQuestion.hints.length
    ) {
      return;
    }
    soundEngine.playHint();
    const nextHintCount = hintsRevealed + 1;
    setHintsRevealed(nextHintCount);
    if (!drawerOpen) setDrawerOpen(true);

    // Final hint zooms the map cleanly near the target region without spoiling exact click before player clicks
    if (nextHintCount === currentQuestion.hints.length) {
      setFocusTarget({
        center: currentQuestion.coordinates,
        zoom: 3.2,
        key: Date.now(),
      });
    }
  };

  // Skip Question
  const handleSkip = () => {
    if (paused || roundResolved !== null || !currentQuestion) return;
    soundEngine.playWrong();
    setStreak(0);
    setRoundResolved('skipped');
    const nextLives = isEndless ? lives - 1 : lives;
    if (isEndless) setLives(nextLives);

    revealCorrectTarget(currentQuestion);
    setFocusTarget({
      center: currentQuestion.coordinates,
      zoom: 2.8,
      key: Date.now(),
    });
    setLastFeedback({
      message: t(UI_TEXT.skippedFeedback, lang),
    });

    const entry: RoundResult = {
      question: currentQuestion,
      solved: false,
      skipped: true,
      timedOut: false,
      attemptsUsed: MAX_ATTEMPTS_PER_QUESTION - attemptsLeft,
      hintsUsed: hintsRevealed,
      pointsEarned: 0,
      timeSpentSec: Math.round((Date.now() - roundStartRef.current) / 1000),
    };
    const nextResults = [...results, entry];
    setResults(nextResults);

    if (isTimeAttack) {
      window.setTimeout(() => {
        if (!finishedRef.current) {
          advanceToNext(nextResults, score, runBestStreak, nextLives);
        }
      }, 950);
    }
  };

  if (!currentQuestion) return null;

  const isLastStandardQuestion =
    !isTimeAttack && !isEndless && currentIdx + 1 >= questions.length;
  const isOutOfLives = isEndless && lives <= 0;

  const progressPct = isTimeAttack
    ? Math.round((timeLeft / 90) * 100)
    : isEndless
    ? 100
    : Math.round(((currentIdx + (roundResolved ? 1 : 0)) / questions.length) * 100);

  return (
    <div
      className={`relative w-full h-screen flex flex-col overflow-hidden ${
        dark ? 'bg-[#060E1A] text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      {/* Top Question & Metrics HUD */}
      <header
        className={`relative z-30 border-b ${
          dark
            ? 'bg-slate-950/92 border-slate-800/90 backdrop-blur-md'
            : 'bg-white/95 border-slate-200 backdrop-blur-md'
        }`}
      >
        <div className="px-3 sm:px-4 py-1 flex flex-wrap items-center justify-between gap-2">
          {/* Left: Pause + Question Prompt */}
          <div className="flex items-center gap-2 min-w-0 flex-1">
            <button
              type="button"
              onClick={() => setPaused(true)}
              aria-label={t(UI_TEXT.pause, lang)}
              className={`w-8 h-8 rounded-lg border flex items-center justify-center shrink-0 transition-colors cursor-pointer ${
                dark
                  ? 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
                  : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Pause className="w-3.5 h-3.5" />
            </button>

            <div className="min-w-0 flex-1">
              <div
                className={`text-[9px] font-medium flex items-center gap-1 ${
                  dark ? 'text-slate-400' : 'text-slate-500'
                }`}
              >
                <span>
                  {category
                    ? t(CATEGORY_BY_ID[category].title, lang)
                    : t(MODE_INFO[mode].title, lang)}
                </span>
                <span aria-hidden="true">·</span>
                <span>{t(QUESTION_TYPE_LABELS[currentQuestion.type], lang)}</span>
                <span aria-hidden="true">·</span>
                <span className="text-amber-500">
                  {t(DIFFICULTY_LABELS[currentQuestion.difficulty], lang)}
                </span>
              </div>
              <div className="flex items-center gap-2 min-w-0 mt-0.5">
                {currentQuestion.flagCountryId && (
                  <CountryFlagBadge
                    countryId={currentQuestion.flagCountryId}
                    size="md"
                    className="shrink-0"
                  />
                )}
                <h1 className="font-display text-[11px] sm:text-xs font-semibold leading-tight line-clamp-2 min-w-0">
                  {t(currentQuestion.question, lang)}
                </h1>
              </div>
            </div>
          </div>

          {/* Right: Numeric HUD Counters */}
          <div className="flex items-center gap-2 sm:gap-3 shrink-0">
            {/* Progress Counter */}
            <div className="hidden sm:block text-center">
              <div
                className={`text-[9px] ${
                  dark ? 'text-slate-400' : 'text-slate-500'
                }`}
              >
                {isEndless ? '#' : t(UI_TEXT.roundInfo, lang)}
              </div>
              <div className="font-mono-tabular text-[11px] font-bold">
                {isEndless
                  ? currentIdx + 1
                  : `${currentIdx + 1}/${questions.length}`}
              </div>
            </div>

            {/* Timer */}
            <div
              className={`flex items-center gap-1 px-2 py-0.5 rounded-lg border font-mono-tabular text-[11px] sm:text-xs font-bold ${
                timeLeft <= 8
                  ? 'bg-red-500/15 border-red-500/50 text-red-400'
                  : dark
                  ? 'bg-slate-900 border-slate-800 text-slate-100'
                  : 'bg-slate-50 border-slate-200 text-slate-800'
              }`}
            >
              <Clock className="w-3 h-3 text-amber-500" />
              <span>{timeLeft}s</span>
            </div>

            {/* Score */}
            <div className="text-end">
              <div
                className={`text-[9px] ${
                  dark ? 'text-slate-400' : 'text-slate-500'
                }`}
              >
                {t(UI_TEXT.score, lang)}
              </div>
              <div className="font-mono-tabular text-xs sm:text-sm font-extrabold text-amber-500">
                {score.toLocaleString()}
              </div>
            </div>

            {/* Attempts or Endless Lives */}
            <div className="flex items-center gap-0.5" title={t(isEndless ? UI_TEXT.lives : UI_TEXT.attempts, lang)}>
              {Array.from({ length: MAX_ATTEMPTS_PER_QUESTION }).map((_, i) => {
                const active = i < (isEndless ? lives : attemptsLeft);
                return (
                  <Heart
                    key={i}
                    className={`w-3.5 h-3.5 transition-transform ${
                      active
                        ? 'text-rose-500 fill-rose-500'
                        : dark
                        ? 'text-slate-700'
                        : 'text-slate-300'
                    }`}
                  />
                );
              })}
            </div>

            {/* Drawer Toggle */}
            <button
              type="button"
              onClick={() => setDrawerOpen((o) => !o)}
              aria-label={t(UI_TEXT.roundInfo, lang)}
              className={`w-8 h-8 rounded-lg border flex items-center justify-center transition-colors cursor-pointer ${
                dark
                  ? 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
                  : 'bg-slate-50 border-slate-300 text-slate-700 hover:bg-slate-100'
              }`}
            >
              {drawerOpen ? (
                <PanelRightClose className="w-3.5 h-3.5" />
              ) : (
                <PanelRightOpen className="w-3.5 h-3.5" />
              )}
            </button>
          </div>
        </div>

        {/* Question Progress Bar */}
        <div
          className={`w-full h-1 ${
            dark ? 'bg-slate-900' : 'bg-slate-200'
          }`}
        >
          <div
            className="h-full bg-amber-500 transition-all duration-300"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </header>

      {/* Main Playfield: Interactive Map + Collapsible Side Info Drawer */}
      <div className="relative flex-1 flex overflow-hidden">
        {/* Map Container (>80% unobstructed) */}
        <div className="relative flex-1 h-full overflow-hidden">
          <WorldMap
            language={lang}
            darkMode={dark}
            interactive={true}
            showCountryNames={roundResolved !== null}
            showCountryNamesOnHover={false}
            showContinentBar={true}
            showCityPins={false}
            showCityNames={false}
            focusTarget={focusTarget}
            highlightedCountryIds={highlightedCountryIds}
            wrongCountryIds={wrongCountryIds}
            markers={markers}
            arc={arc}
            onMapClick={handleMapClick}
          />

          {/* Compact Feedback & Next Banner Overlay (non-blocking until resolved) */}
          {lastFeedback && (
            <div className="pointer-events-none absolute top-3 left-1/2 -translate-x-1/2 z-30 w-[90%] max-w-md">
              <div
                className={`pointer-events-auto rounded-2xl border p-3 shadow-2xl backdrop-blur-md space-y-2 ${
                  roundResolved === 'correct'
                    ? dark
                      ? 'bg-emerald-950/90 border-emerald-500/60 text-emerald-50'
                      : 'bg-emerald-50/95 border-emerald-400 text-emerald-950'
                    : roundResolved !== null
                    ? dark
                      ? 'bg-slate-900/95 border-amber-500/60 text-slate-100'
                      : 'bg-white/95 border-amber-400 text-slate-900'
                    : dark
                    ? 'bg-rose-950/90 border-rose-500/60 text-rose-50'
                    : 'bg-rose-50/95 border-rose-300 text-rose-950'
                }`}
              >
                <div className="flex items-start justify-between gap-2.5">
                  <div className="flex items-start gap-2">
                    {roundResolved === 'correct' ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                    )}
                    <div className="space-y-0.5">
                      <div className="font-bold text-xs sm:text-sm">
                        {lastFeedback.message}
                      </div>
                      {roundResolved !== null && (
                        <div className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                          <CountryFlagBadge
                            countryId={currentQuestion.targetCountryId}
                            size="sm"
                          />
                          <span>{t(currentQuestion.correctAnswer, lang)}</span>
                        </div>
                      )}
                      {lastFeedback.distanceKm !== undefined &&
                        roundResolved !== 'correct' && (
                          <div className="text-xs flex flex-wrap items-center gap-1.5 opacity-90">
                            <Navigation className="w-3.5 h-3.5 shrink-0" />
                            {lastFeedback.guessedCountryName && (
                              <span>({lastFeedback.guessedCountryName}) ·</span>
                            )}
                            <span className="font-mono-tabular">
                              {lastFeedback.distanceKm.toLocaleString()}{' '}
                              {t(UI_TEXT.km, lang)}
                            </span>
                            {lastFeedback.direction && (
                              <span>
                                · {t(UI_TEXT.towards, lang)}{' '}
                                {lastFeedback.direction}
                              </span>
                            )}
                          </div>
                        )}
                    </div>
                  </div>

                  {lastFeedback.pointsBreakdown && (
                    <div className="font-mono-tabular text-base font-extrabold text-emerald-400 shrink-0">
                      +{lastFeedback.pointsBreakdown.total}
                    </div>
                  )}
                </div>

                {roundResolved !== null && (
                  <>
                    <p className="text-xs leading-relaxed opacity-90">
                      {t(currentQuestion.fact, lang)}
                    </p>
                    {!isTimeAttack && (
                      <div className="flex justify-end pt-1">
                        <button
                          type="button"
                          onClick={() => advanceToNext()}
                          className="h-10 px-5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer"
                        >
                          <span>
                            {isLastStandardQuestion || isOutOfLives
                              ? t(UI_TEXT.finishRun, lang)
                              : t(UI_TEXT.nextQuestion, lang)}
                          </span>
                          {lang === 'ar' ? (
                            <ChevronLeft className="w-4 h-4" />
                          ) : (
                            <ChevronRight className="w-4 h-4" />
                          )}
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Collapsible Round Info & Hints Side Drawer */}
        {drawerOpen && (
          <aside
            className={`absolute sm:relative inset-y-0 ${
              lang === 'ar' ? 'left-0' : 'right-0'
            } z-20 w-72 sm:w-80 border-s flex flex-col justify-between shadow-2xl sm:shadow-none ${
              dark
                ? 'bg-slate-950/95 border-slate-800 text-slate-100'
                : 'bg-white/95 border-slate-200 text-slate-900'
            }`}
          >
            <div className="p-5 space-y-5 overflow-y-auto flex-1">
              <div className="flex items-center justify-between">
                <h2 className="font-display font-bold text-sm">
                  {t(UI_TEXT.roundInfo, lang)}
                </h2>
                <span className="font-mono-tabular text-xs text-amber-500 font-bold">
                  {t(UI_TEXT.streak, lang)}: {streak}
                </span>
              </div>

              {/* Progressive Hints List */}
              <div className="space-y-2.5">
                <div className="flex items-center justify-between text-xs">
                  <span
                    className={`font-semibold ${
                      dark ? 'text-slate-300' : 'text-slate-700'
                    }`}
                  >
                    {t(UI_TEXT.hintsUsedLabel, lang)} ({hintsRevealed}/
                    {currentQuestion.hints.length})
                  </span>
                  <span
                    className={`${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.hintCostNote, lang)}
                  </span>
                </div>

                {hintsRevealed === 0 ? (
                  <div
                    className={`rounded-xl border p-3.5 text-xs ${
                      dark
                        ? 'bg-slate-900/60 border-slate-800 text-slate-400'
                        : 'bg-slate-50 border-slate-200 text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.clickToExplore, lang)}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {currentQuestion.hints
                      .slice(0, hintsRevealed)
                      .map((hintObj, idx) => (
                        <div
                          key={idx}
                          className={`rounded-xl border p-3 text-xs leading-relaxed ${
                            dark
                              ? 'bg-amber-500/10 border-amber-500/30 text-amber-100'
                              : 'bg-amber-50 border-amber-200 text-amber-950'
                          }`}
                        >
                          <span className="font-mono-tabular font-bold text-amber-500 me-1.5">
                            {idx + 1}.
                          </span>
                          <span>{t(hintObj, lang)}</span>
                        </div>
                      ))}
                  </div>
                )}
              </div>

              {/* Score Breakdown on Solve */}
              {lastFeedback?.pointsBreakdown && (
                <div
                  className={`rounded-xl border p-3.5 space-y-1.5 text-xs ${
                    dark
                      ? 'bg-slate-900/70 border-slate-800'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex justify-between">
                    <span>{t(UI_TEXT.basePoints, lang)}</span>
                    <span className="font-mono-tabular">
                      +{lastFeedback.pointsBreakdown.base}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>{t(UI_TEXT.speedBonus, lang)}</span>
                    <span className="font-mono-tabular text-sky-400">
                      +{lastFeedback.pointsBreakdown.speed}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span>{t(UI_TEXT.streakBonus, lang)}</span>
                    <span className="font-mono-tabular text-emerald-400">
                      +{lastFeedback.pointsBreakdown.streak}
                    </span>
                  </div>
                  {lastFeedback.pointsBreakdown.hintPenalty > 0 && (
                    <div className="flex justify-between text-rose-400">
                      <span>{t(UI_TEXT.hintPenalty, lang)}</span>
                      <span className="font-mono-tabular">
                        -{lastFeedback.pointsBreakdown.hintPenalty}
                      </span>
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Bottom Controls inside Drawer on Desktop */}
            <div
              className={`p-4 border-t space-y-2 ${
                dark ? 'border-slate-800' : 'border-slate-200'
              }`}
            >
              <button
                type="button"
                disabled={
                  roundResolved !== null ||
                  hintsRevealed >= currentQuestion.hints.length
                }
                onClick={handleHint}
                className={`w-full h-11 px-4 rounded-xl border font-semibold text-xs inline-flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed ${
                  dark
                    ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25'
                    : 'bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100'
                }`}
              >
                <Lightbulb className="w-4 h-4" />
                <span>
                  {hintsRevealed >= currentQuestion.hints.length
                    ? t(UI_TEXT.allHintsUsed, lang)
                    : `${t(UI_TEXT.hint, lang)} (${hintsRevealed}/${
                        currentQuestion.hints.length
                      })`}
                </span>
              </button>

              <button
                type="button"
                disabled={roundResolved !== null}
                onClick={handleSkip}
                className={`w-full h-10 px-4 rounded-xl border font-medium text-xs inline-flex items-center justify-center gap-2 transition-colors cursor-pointer disabled:opacity-45 disabled:cursor-not-allowed ${
                  dark
                    ? 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                <SkipForward className="w-4 h-4" />
                <span>{t(UI_TEXT.skip, lang)}</span>
              </button>
            </div>
          </aside>
        )}
      </div>

      {/* Bottom Floating Hint & Skip Bar (Always visible when drawer is closed on Mobile/Desktop!) */}
      {!drawerOpen && (
        <div
          className={`relative z-30 border-t px-4 py-2.5 flex items-center justify-between gap-3 ${
            dark
              ? 'bg-slate-950/92 border-slate-800'
              : 'bg-white/95 border-slate-200'
          }`}
        >
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={
                roundResolved !== null ||
                hintsRevealed >= currentQuestion.hints.length
              }
              onClick={handleHint}
              className={`h-10 px-4 rounded-xl border font-semibold text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-45 ${
                dark
                  ? 'bg-amber-500/15 border-amber-500/40 text-amber-300 hover:bg-amber-500/25'
                  : 'bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100'
              }`}
            >
              <Lightbulb className="w-4 h-4" />
              <span>
                {t(UI_TEXT.hint, lang)} ({hintsRevealed}/
                {currentQuestion.hints.length})
              </span>
            </button>

            <button
              type="button"
              disabled={roundResolved !== null}
              onClick={handleSkip}
              className={`h-10 px-4 rounded-xl border font-medium text-xs inline-flex items-center gap-1.5 transition-colors cursor-pointer disabled:opacity-45 ${
                dark
                  ? 'bg-slate-900 border-slate-700 text-slate-300 hover:bg-slate-800'
                  : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
              }`}
            >
              <SkipForward className="w-4 h-4" />
              <span>{t(UI_TEXT.skip, lang)}</span>
            </button>
          </div>

          <div className="font-mono-tabular text-xs font-semibold text-amber-500">
            {t(UI_TEXT.streak, lang)}: {streak}
          </div>
        </div>
      )}

      {/* Pause Modal */}
      {paused && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm">
          <div
            className={`w-full max-w-sm rounded-2xl border p-6 space-y-5 shadow-2xl text-center ${
              dark
                ? 'bg-slate-900 border-slate-800 text-slate-100'
                : 'bg-white border-slate-200 text-slate-900'
            }`}
          >
            <h2 className="font-display text-2xl font-bold">
              {t(UI_TEXT.pause, lang)}
            </h2>
            <div className="space-y-2.5">
              <button
                type="button"
                onClick={() => setPaused(false)}
                className="w-full h-11 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm inline-flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <Play className="w-4 h-4" />
                <span>{t(UI_TEXT.resume, lang)}</span>
              </button>
              <button
                type="button"
                onClick={onExitToMenu}
                className={`w-full h-11 rounded-xl border font-semibold text-sm inline-flex items-center justify-center gap-2 transition-colors cursor-pointer ${
                  dark
                    ? 'bg-slate-950 border-slate-700 text-slate-200 hover:bg-slate-800'
                    : 'bg-slate-50 border-slate-300 text-slate-800 hover:bg-slate-100'
                }`}
              >
                <Home className="w-4 h-4" />
                <span>{t(UI_TEXT.backHome, lang)}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
