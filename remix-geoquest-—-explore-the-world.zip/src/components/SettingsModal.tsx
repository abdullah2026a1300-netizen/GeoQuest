import React from 'react';
import { X, Volume2, Sun, Moon, Languages, Youtube, ExternalLink } from 'lucide-react';
import { DifficultySetting, GameSettings, GameSpeed } from '../types/game';
import {
  DIFFICULTY_LABELS,
  SPEED_LABELS,
  UI_TEXT,
  t,
} from '../data/i18n';
import { OFFICIAL_YOUTUBE_URL } from '../utils/storage';

interface SettingsModalProps {
  settings: GameSettings;
  onUpdateSettings: (next: GameSettings) => void;
  onClose: () => void;
}

const QUESTION_COUNTS = [5, 10, 20, 50];
const SPEEDS: GameSpeed[] = ['relaxed', 'normal', 'fast'];
const DIFFICULTIES: DifficultySetting[] = ['mixed', 'easy', 'medium', 'hard'];

export const SettingsModal: React.FC<SettingsModalProps> = ({
  settings,
  onUpdateSettings,
  onClose,
}) => {
  const lang = settings.language;
  const dark = settings.darkMode;

  const update = (patch: Partial<GameSettings>) => {
    onUpdateSettings({ ...settings, ...patch });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div
        className={`w-full max-w-lg max-h-[90vh] rounded-2xl border shadow-2xl flex flex-col overflow-hidden ${
          dark
            ? 'bg-slate-900 border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            dark ? 'border-slate-800' : 'border-slate-200'
          }`}
        >
          <h2 className="font-display text-xl font-bold">
            {t(UI_TEXT.settings, lang)}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t(UI_TEXT.close, lang)}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
              dark ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-100 text-slate-500'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Language */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 text-sm font-semibold">
              <Languages className="w-4 h-4 text-amber-500" />
              <span>{t(UI_TEXT.languageSetting, lang)}</span>
            </div>
            <div
              className={`flex p-1 rounded-xl border ${
                dark ? 'bg-slate-950 border-slate-800' : 'bg-slate-100 border-slate-200'
              }`}
            >
              <button
                type="button"
                onClick={() => update({ language: 'ar' })}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  lang === 'ar'
                    ? 'bg-amber-500 text-slate-950'
                    : dark
                    ? 'text-slate-300'
                    : 'text-slate-600'
                }`}
              >
                العربية
              </button>
              <button
                type="button"
                onClick={() => update({ language: 'en' })}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  lang === 'en'
                    ? 'bg-amber-500 text-slate-950'
                    : dark
                    ? 'text-slate-300'
                    : 'text-slate-600'
                }`}
              >
                English
              </button>
              <button
                type="button"
                onClick={() => update({ language: 'tr' })}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
                  lang === 'tr'
                    ? 'bg-amber-500 text-slate-950'
                    : dark
                    ? 'text-slate-300'
                    : 'text-slate-600'
                }`}
              >
                Türkçe
              </button>
            </div>
          </div>

          {/* Dark Mode */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 text-sm font-semibold">
              {dark ? (
                <Moon className="w-4 h-4 text-sky-400" />
              ) : (
                <Sun className="w-4 h-4 text-amber-500" />
              )}
              <span>{t(UI_TEXT.themeSetting, lang)}</span>
            </div>
            <button
              type="button"
              onClick={() => update({ darkMode: !dark })}
              className={`h-9 w-16 rounded-full p-1 transition-colors cursor-pointer ${
                dark ? 'bg-amber-500' : 'bg-slate-300'
              }`}
              aria-pressed={dark}
            >
              <div
                className={`w-7 h-7 rounded-full bg-white shadow transition-transform ${
                  dark
                    ? lang === 'ar'
                      ? '-translate-x-7'
                      : 'translate-x-7'
                    : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Sound Effects Toggle */}
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 text-sm font-semibold">
              <Volume2 className="w-4 h-4 text-emerald-400" />
              <span>{t(UI_TEXT.soundSetting, lang)}</span>
            </div>
            <button
              type="button"
              onClick={() => update({ soundEnabled: !settings.soundEnabled })}
              className={`h-9 w-16 rounded-full p-1 transition-colors cursor-pointer ${
                settings.soundEnabled ? 'bg-emerald-500' : 'bg-slate-600'
              }`}
              aria-pressed={settings.soundEnabled}
            >
              <div
                className={`w-7 h-7 rounded-full bg-white shadow transition-transform ${
                  settings.soundEnabled
                    ? lang === 'ar'
                      ? '-translate-x-7'
                      : 'translate-x-7'
                    : 'translate-x-0'
                }`}
              />
            </button>
          </div>

          {/* Volume Slider */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-sm">
              <span className="font-semibold">{t(UI_TEXT.volumeSetting, lang)}</span>
              <span className="font-mono-tabular text-xs text-amber-500">
                {Math.round(settings.volume * 100)}%
              </span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(settings.volume * 100)}
              disabled={!settings.soundEnabled}
              onChange={(e) => update({ volume: Number(e.target.value) / 100 })}
              className="w-full accent-amber-500 cursor-pointer disabled:opacity-40"
            />
          </div>

          {/* Game Speed */}
          <div className="space-y-2.5">
            <div className="text-sm font-semibold">{t(UI_TEXT.speedSetting, lang)}</div>
            <div className="grid grid-cols-3 gap-2">
              {SPEEDS.map((sp) => (
                <button
                  key={sp}
                  type="button"
                  onClick={() => update({ gameSpeed: sp })}
                  className={`h-10 px-2 rounded-xl border text-xs font-semibold transition-colors cursor-pointer ${
                    settings.gameSpeed === sp
                      ? 'bg-amber-500 border-amber-500 text-slate-950'
                      : dark
                      ? 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-600'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {t(SPEED_LABELS[sp], lang)}
                </button>
              ))}
            </div>
          </div>

          {/* Question Count */}
          <div className="space-y-2.5">
            <div className="text-sm font-semibold">
              {t(UI_TEXT.questionCountSetting, lang)}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {QUESTION_COUNTS.map((cnt) => (
                <button
                  key={cnt}
                  type="button"
                  onClick={() => update({ questionCount: cnt })}
                  className={`h-10 rounded-xl border font-mono-tabular text-sm font-bold transition-colors cursor-pointer ${
                    settings.questionCount === cnt
                      ? 'bg-amber-500 border-amber-500 text-slate-950'
                      : dark
                      ? 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-600'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {cnt}
                </button>
              ))}
            </div>
          </div>

          {/* Default Difficulty */}
          <div className="space-y-2.5">
            <div className="text-sm font-semibold">
              {t(UI_TEXT.difficultySetting, lang)}
            </div>
            <div className="grid grid-cols-4 gap-2">
              {DIFFICULTIES.map((diff) => (
                <button
                  key={diff}
                  type="button"
                  onClick={() => update({ difficulty: diff })}
                  className={`h-10 rounded-xl border text-xs font-semibold transition-colors cursor-pointer ${
                    settings.difficulty === diff
                      ? 'bg-sky-500 border-sky-500 text-slate-950'
                      : dark
                      ? 'bg-slate-950 border-slate-800 text-slate-300 hover:border-slate-600'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {t(DIFFICULTY_LABELS[diff], lang)}
                </button>
              ))}
            </div>
          </div>

          {/* YouTube Channel Callout */}
          <a
            href={OFFICIAL_YOUTUBE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className={`flex items-center justify-between gap-3 px-4 py-3 rounded-xl border transition-colors ${
              dark
                ? 'bg-red-950/30 border-red-500/35 text-red-100 hover:bg-red-500/15 hover:border-red-400/60'
                : 'bg-red-50 border-red-200 text-red-800 hover:bg-red-100'
            }`}
          >
            <span className="flex items-center gap-2.5 text-sm font-semibold">
              <Youtube className="w-5 h-5 text-red-500 shrink-0" />
              <span>{t(UI_TEXT.visitYoutubeChannel, lang)}</span>
            </span>
            <ExternalLink className="w-4 h-4 opacity-70 shrink-0" />
          </a>
        </div>

        <div
          className={`px-6 py-4 border-t flex justify-end ${
            dark ? 'border-slate-800 bg-slate-950/40' : 'border-slate-200 bg-slate-50'
          }`}
        >
          <button
            type="button"
            onClick={onClose}
            className="h-10 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer"
          >
            {t(UI_TEXT.close, lang)}
          </button>
        </div>
      </div>
    </div>
  );
};
