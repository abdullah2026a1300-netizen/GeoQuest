import React, { useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  Building2,
  Globe,
  Globe2,
  Map as MapIcon,
  MapPin,
  Navigation,
  Search,
} from 'lucide-react';
import { CityPoint, CountryMeta, GameSettings } from '../types/game';
import { COUNTRY_BY_ID } from '../data/countriesData';
import { getCitiesByCountryId, getCountryAreaKm2 } from '../data/countryGeoStats';
import { getAllCityPoints } from '../data/questionGenerator';
import {
  CONTINENT_LABELS,
  UI_TEXT,
  locCityCountryName,
  locCityName,
  locCountryCapital,
  locCountryName,
  locMapCountryName,
  t,
} from '../data/i18n';
import { formatCoords } from '../utils/geoMath';
import { MapClickPayload, MapProjectionMode, WorldMap } from './map/WorldMap';
import { CountryFlagBadge } from './CountryFlagBadge';
import { soundEngine } from '../utils/sound';
import {
  getCombinedNeighbors,
  NEIGHBOR_COLOR_PALETTE,
  RAW_COUNTRY_NAME_BY_ID,
} from '../utils/worldTopology';

export type AtlasLayerMode = 'countries' | 'cities' | 'both';

interface AtlasExploreScreenProps {
  settings: GameSettings;
  initialLayer?: AtlasLayerMode;
  initialProjection?: MapProjectionMode;
  onBack: () => void;
}

export const AtlasExploreScreen: React.FC<AtlasExploreScreenProps> = ({
  settings,
  initialLayer = 'both',
  initialProjection = 'mercator',
  onBack,
}) => {
  const lang = settings.language;
  const dark = settings.darkMode;

  const [layerMode, setLayerMode] = useState<AtlasLayerMode>(initialLayer);
  const [projectionMode, setProjectionMode] =
    useState<MapProjectionMode>(initialProjection);
  const [cityQuery, setCityQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<CountryMeta | null>(null);
  const [selectedCity, setSelectedCity] = useState<CityPoint | null>(null);
  const [selectedRaw, setSelectedRaw] = useState<{
    id?: string;
    name: string;
    coords: [number, number];
  } | null>(null);
  const [focusTarget, setFocusTarget] = useState<{
    center: [number, number];
    zoom: number;
    key: number;
  } | null>(null);

  const allCities = useMemo(() => getAllCityPoints(), []);

  const matchingCities = useMemo(() => {
    const q = cityQuery.trim().toLowerCase();
    if (!q) return [];
    return allCities
      .filter(
        (c) =>
          c.name.ar.toLowerCase().includes(q) ||
          c.name.en.toLowerCase().includes(q) ||
          locCityName(c, 'tr').toLowerCase().includes(q) ||
          c.countryName.ar.toLowerCase().includes(q) ||
          c.countryName.en.toLowerCase().includes(q) ||
          locCityCountryName(c, 'tr').toLowerCase().includes(q)
      )
      .slice(0, 12);
  }, [allCities, cityQuery]);

  const handleCitySelect = (city: CityPoint) => {
    soundEngine.playClick();
    setSelectedCity(city);
    setSelectedCountry(null);
    setSelectedRaw(null);
    setCityQuery('');
    setFocusTarget({ center: city.coordinates, zoom: 5.0, key: Date.now() });
  };

  const handleMapClick = (payload: MapClickPayload) => {
    soundEngine.playClick();
    setSelectedCity(null);
    if (payload.countryId && COUNTRY_BY_ID[payload.countryId]) {
      const meta = COUNTRY_BY_ID[payload.countryId];
      setSelectedCountry(meta);
      setSelectedRaw(null);
      setFocusTarget({ center: meta.center, zoom: 3.4, key: Date.now() });
    } else if (payload.countryId || payload.countryNameRaw) {
      const raw =
        (payload.countryId && RAW_COUNTRY_NAME_BY_ID[payload.countryId]) ||
        payload.countryNameRaw ||
        formatCoords(payload.coordinates);
      const displayName = payload.countryId
        ? locMapCountryName(payload.countryId, raw, lang)
        : raw;
      setSelectedCountry(null);
      setSelectedRaw({
        id: payload.countryId || undefined,
        name: displayName,
        coords: payload.coordinates,
      });
      if (payload.countryId) {
        setFocusTarget({ center: payload.coordinates, zoom: 3.4, key: Date.now() });
      }
    } else {
      setSelectedCountry(null);
      setSelectedRaw({
        name: formatCoords(payload.coordinates),
        coords: payload.coordinates,
      });
    }
  };

  const activeCountryId = selectedCountry?.id ?? selectedRaw?.id ?? null;

  const selectedCountryCities = useMemo(
    () => (activeCountryId ? getCitiesByCountryId(activeCountryId) : []),
    [activeCountryId]
  );

  const selectedCountryArea = useMemo(
    () => (selectedCountry ? getCountryAreaKm2(selectedCountry.id) : 0),
    [selectedCountry]
  );

  const combinedNeighborIds = useMemo(
    () =>
      activeCountryId
        ? getCombinedNeighbors(activeCountryId, selectedCountry?.neighbors ?? [])
        : [],
    [activeCountryId, selectedCountry]
  );

  const neighborEntries = useMemo(
    () =>
      combinedNeighborIds.map((nid, idx) => {
        const meta = COUNTRY_BY_ID[nid] || null;
        const label = locMapCountryName(
          nid,
          RAW_COUNTRY_NAME_BY_ID[nid] || nid,
          lang
        );
        const swatch =
          NEIGHBOR_COLOR_PALETTE[idx % NEIGHBOR_COLOR_PALETTE.length].swatch;
        return { id: nid, meta, label, swatch };
      }),
    [combinedNeighborIds, lang]
  );

  const showCities = layerMode === 'cities' || layerMode === 'both';

  return (
    <div
      className={`relative w-full h-screen flex flex-col overflow-hidden ${
        dark ? 'bg-[#060E1A] text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      {/* Top Bar */}
      <header
        className={`relative z-30 flex flex-wrap items-center justify-between gap-3 px-4 sm:px-6 py-3 border-b ${
          dark
            ? 'bg-slate-950/90 border-slate-800'
            : 'bg-white/95 border-slate-200'
        }`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <button
            type="button"
            onClick={onBack}
            className={`h-10 px-3 rounded-xl border inline-flex items-center gap-2 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
              dark
                ? 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
                : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
            }`}
          >
            {lang === 'ar' ? (
              <ArrowRight className="w-4 h-4" />
            ) : (
              <ArrowLeft className="w-4 h-4" />
            )}
            <span>{t(UI_TEXT.backHome, lang)}</span>
          </button>
          <div className="min-w-0">
            <h1 className="font-display font-bold text-base sm:text-lg truncate flex items-center gap-2">
              {projectionMode === 'globe' ? (
                <Globe className="w-4 h-4 text-sky-400 shrink-0" />
              ) : layerMode === 'cities' ? (
                <Building2 className="w-4 h-4 text-amber-500 shrink-0" />
              ) : (
                <Globe2 className="w-4 h-4 text-sky-400 shrink-0" />
              )}
              <span>
                {projectionMode === 'globe'
                  ? t(UI_TEXT.sphericalEarth, lang)
                  : layerMode === 'cities'
                  ? t(UI_TEXT.citiesMap, lang)
                  : t(UI_TEXT.atlasTitle, lang)}
              </span>
            </h1>
          </div>
        </div>

        {/* Projection Switcher + Layer Switcher + City Search */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* City Search Box */}
          {showCities && (
            <div className="relative">
              <div className="relative flex items-center">
                <Search className="w-3.5 h-3.5 text-slate-400 absolute start-3 pointer-events-none" />
                <input
                  type="text"
                  value={cityQuery}
                  onChange={(e) => setCityQuery(e.target.value)}
                  placeholder={
                    lang === 'ar'
                      ? 'ابحث عن مدينة...'
                      : lang === 'tr'
                      ? 'Şehir ara...'
                      : 'Search a city...'
                  }
                  className={`h-9 w-44 sm:w-56 ps-8 pe-3 rounded-xl border text-xs focus:outline-none focus:ring-2 focus:ring-amber-500 ${
                    dark
                      ? 'bg-slate-900 border-slate-700 text-slate-100 placeholder:text-slate-500'
                      : 'bg-slate-50 border-slate-300 text-slate-900 placeholder:text-slate-400'
                  }`}
                />
              </div>
              {matchingCities.length > 0 && (
                <div
                  className={`absolute top-11 start-0 w-64 rounded-xl border shadow-2xl overflow-hidden z-40 ${
                    dark
                      ? 'bg-slate-900 border-slate-700 text-slate-100'
                      : 'bg-white border-slate-200 text-slate-900'
                  }`}
                >
                  {matchingCities.map((c) => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => handleCitySelect(c)}
                      className={`w-full text-start px-3.5 py-2.5 text-xs flex items-center justify-between gap-2 transition-colors cursor-pointer ${
                        dark ? 'hover:bg-slate-800' : 'hover:bg-slate-100'
                      }`}
                    >
                      <span className="font-semibold">{locCityName(c, lang)}</span>
                      <span
                        className={`text-[11px] ${
                          dark ? 'text-slate-400' : 'text-slate-500'
                        }`}
                      >
                        {locCityCountryName(c, lang)}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          )}

          {/* Flat vs Spherical Earth Segmented Control */}
          <div
            className={`flex items-center gap-1 p-1 rounded-xl border ${
              dark ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'
            }`}
          >
            <button
              type="button"
              onClick={() => setProjectionMode('mercator')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                projectionMode === 'mercator'
                  ? 'bg-sky-500 text-slate-950'
                  : dark
                  ? 'text-slate-300 hover:text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5" />
              <span>{t(UI_TEXT.flatMap, lang)}</span>
            </button>
            <button
              type="button"
              onClick={() => setProjectionMode('globe')}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold inline-flex items-center gap-1.5 transition-colors whitespace-nowrap cursor-pointer ${
                projectionMode === 'globe'
                  ? 'bg-sky-500 text-slate-950'
                  : dark
                  ? 'text-slate-300 hover:text-white'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Globe className="w-3.5 h-3.5" />
              <span>{t(UI_TEXT.sphericalEarth, lang)}</span>
            </button>
          </div>

          {/* Layer Segmented Control */}
          <div
            className={`flex items-center gap-1 p-1 rounded-xl border ${
              dark ? 'bg-slate-900 border-slate-800' : 'bg-slate-100 border-slate-200'
            }`}
          >
            {(
              [
                ['countries', UI_TEXT.countriesLayer],
                ['cities', UI_TEXT.citiesLayer],
                ['both', UI_TEXT.bothLayers],
              ] as const
            ).map(([modeId, label]) => (
              <button
                key={modeId}
                type="button"
                onClick={() => setLayerMode(modeId)}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                  layerMode === modeId
                    ? 'bg-amber-500 text-slate-950'
                    : dark
                    ? 'text-slate-300 hover:text-white'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {t(label, lang)}
              </button>
            ))}
          </div>
        </div>
      </header>

      {/* Map + Inspector Container */}
      <div className="relative flex-1 overflow-hidden">
        <WorldMap
          language={lang}
          darkMode={dark}
          interactive={true}
          projectionMode={projectionMode}
          onProjectionModeChange={setProjectionMode}
          showCountryNames={true}
          showCountryNamesToggle={true}
          showCountryNamesOnHover={true}
          showContinentBar={true}
          showCityPins={showCities}
          showCityNames={showCities}
          defaultShowCityBoundaries={layerMode === 'cities'}
          selectedCityForBoundaries={selectedCity}
          highlightedCityCountryId={activeCountryId}
          cityPoints={allCities}
          selectedCityId={selectedCity?.id ?? null}
          focusTarget={focusTarget}
          highlightedCountryIds={activeCountryId ? [activeCountryId] : []}
          secondaryHighlightIds={combinedNeighborIds}
          markers={
            selectedCountry
              ? [
                  {
                    id: 'explore-cap',
                    coordinates: selectedCountry.capitalCoords,
                    kind: 'explore',
                  },
                ]
              : selectedRaw
              ? [
                  {
                    id: 'explore-raw',
                    coordinates: selectedRaw.coords,
                    kind: 'explore',
                  },
                ]
              : []
          }
          onMapClick={handleMapClick}
          onCityClick={handleCitySelect}
        />

        {/* Selected City / Country Detail Panel */}
        {(selectedCity || selectedCountry || selectedRaw) && (
          <aside
            className={`absolute top-4 ${
              lang === 'ar' ? 'right-4' : 'left-4'
            } z-20 w-[calc(100%-2rem)] sm:w-88 max-h-[calc(100%-6rem)] overflow-y-auto rounded-2xl border p-5 shadow-2xl space-y-4 ${
              dark
                ? 'bg-slate-900/95 border-slate-800 text-slate-100 backdrop-blur-md'
                : 'bg-white/95 border-slate-200 text-slate-900 backdrop-blur-md'
            }`}
          >
            {selectedCity ? (
              <>
                <div className="space-y-1">
                  <div className="text-xs font-semibold text-amber-500">
                    {selectedCity.isCapital
                      ? t(UI_TEXT.capitalBadge, lang)
                      : t(UI_TEXT.majorCityBadge, lang)}{' '}
                    · {t(CONTINENT_LABELS[selectedCity.continent], lang)}
                  </div>
                  <h2 className="font-display text-xl font-bold flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-amber-500 shrink-0" />
                    <span>{locCityName(selectedCity, lang)}</span>
                  </h2>
                  <div
                    className={`text-xs flex items-center gap-2 ${
                      dark ? 'text-slate-400' : 'text-slate-600'
                    }`}
                  >
                    <CountryFlagBadge countryId={selectedCity.countryId} size="sm" />
                    <span>{locCityCountryName(selectedCity, lang)}</span>
                  </div>
                </div>

                <div>
                  <div
                    className={`text-xs mb-0.5 ${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.coordsLabel, lang)}
                  </div>
                  <div dir="ltr" className="font-mono-tabular text-xs font-semibold">
                    {formatCoords(selectedCity.coordinates)}
                  </div>
                </div>

                <p
                  className={`text-xs leading-relaxed ${
                    dark ? 'text-slate-300' : 'text-slate-600'
                  }`}
                >
                  {t(selectedCity.fact, lang)}
                </p>

                {selectedCity.countryId && COUNTRY_BY_ID[selectedCity.countryId] && (
                  <button
                    type="button"
                    onClick={() => {
                      const parent = COUNTRY_BY_ID[selectedCity.countryId!];
                      if (parent) {
                        setSelectedCity(null);
                        setSelectedCountry(parent);
                        setFocusTarget({
                          center: parent.center,
                          zoom: 3.4,
                          key: Date.now(),
                        });
                      }
                    }}
                    className={`w-full h-9 rounded-xl border text-xs font-semibold transition-colors cursor-pointer ${
                      dark
                        ? 'bg-slate-800 border-slate-700 text-amber-400 hover:bg-slate-700'
                        : 'bg-slate-100 border-slate-200 text-amber-700 hover:bg-slate-200'
                    }`}
                  >
                    {t(UI_TEXT.backToCountry, lang)} ({locCityCountryName(selectedCity, lang)})
                  </button>
                )}
              </>
            ) : selectedCountry ? (
              <>
                <div className="space-y-1">
                  <div
                    className={`text-xs ${
                      dark ? 'text-amber-400' : 'text-amber-600'
                    } font-semibold`}
                  >
                    {t(CONTINENT_LABELS[selectedCountry.continent], lang)}
                  </div>
                  <h2 className="font-display text-xl font-bold flex items-center gap-2.5">
                    <CountryFlagBadge countryId={selectedCountry.id} size="md" />
                    <span>{locCountryName(selectedCountry, lang)}</span>
                  </h2>
                </div>

                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div>
                    <div
                      className={`mb-0.5 ${
                        dark ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      {t(UI_TEXT.capitalLabel, lang)}
                    </div>
                    <div className="font-semibold flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                      <span>{locCountryCapital(selectedCountry, lang)}</span>
                    </div>
                  </div>
                  <div>
                    <div
                      className={`mb-0.5 ${
                        dark ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      {t(UI_TEXT.coordsLabel, lang)}
                    </div>
                    <div dir="ltr" className="font-mono-tabular font-semibold">
                      {formatCoords(selectedCountry.center)}
                    </div>
                  </div>
                  <div>
                    <div
                      className={`mb-0.5 ${
                        dark ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      {t(UI_TEXT.areaLabel, lang)}
                    </div>
                    <div className="font-mono-tabular font-bold text-sky-400">
                      {selectedCountryArea.toLocaleString()}{' '}
                      <span className="font-normal text-[11px]">
                        {t(UI_TEXT.km2Unit, lang)}
                      </span>
                    </div>
                  </div>
                  <div>
                    <div
                      className={`mb-0.5 ${
                        dark ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      {t(UI_TEXT.cityCountLabel, lang)}
                    </div>
                    <div className="font-mono-tabular font-bold text-emerald-400">
                      {selectedCountryCities.length}
                    </div>
                  </div>
                </div>

                {/* City Names of this Country */}
                <div className="space-y-1.5">
                  <div
                    className={`text-xs font-semibold ${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.countryCitiesLabel, lang)} ({selectedCountryCities.length})
                  </div>
                  <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto">
                    {selectedCountryCities.map((city) => (
                      <button
                        key={city.id}
                        type="button"
                        onClick={() => handleCitySelect(city)}
                        className={`px-2.5 py-1 rounded-lg border text-xs font-medium inline-flex items-center gap-1 transition-colors cursor-pointer ${
                          city.isCapital
                            ? dark
                              ? 'bg-amber-500/15 border-amber-500/50 text-amber-300 hover:bg-amber-500/25'
                              : 'bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100'
                            : dark
                            ? 'bg-slate-800 border-slate-700 hover:border-emerald-500 text-slate-200'
                            : 'bg-slate-100 border-slate-200 hover:border-emerald-500 text-slate-800'
                        }`}
                      >
                        <span>{locCityName(city, lang)}</span>
                        {city.isCapital && (
                          <span className="text-[10px] opacity-80">★</span>
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                <p
                  className={`text-xs leading-relaxed ${
                    dark ? 'text-slate-300' : 'text-slate-600'
                  }`}
                >
                  {t(selectedCountry.fact, lang)}
                </p>

                <div className="space-y-1.5">
                  <div
                    className={`text-xs font-semibold ${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.neighborsLabel, lang)}
                  </div>
                  {neighborEntries.length > 0 ? (
                    <div className="flex flex-wrap gap-1.5">
                      {neighborEntries.map((nb) => (
                        <button
                          key={nb.id}
                          type="button"
                          onClick={() => {
                            soundEngine.playClick();
                            if (nb.meta) {
                              setSelectedCountry(nb.meta);
                              setSelectedRaw(null);
                              setFocusTarget({
                                center: nb.meta.center,
                                zoom: 3.4,
                                key: Date.now(),
                              });
                            } else {
                              setSelectedCountry(null);
                              setSelectedRaw({
                                id: nb.id,
                                name: nb.label,
                                coords: selectedCountry.center,
                              });
                            }
                          }}
                          className={`px-2.5 py-1 rounded-lg border text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                            dark
                              ? 'bg-slate-800 border-slate-700 hover:border-sky-500 text-slate-200'
                              : 'bg-slate-100 border-slate-200 hover:border-sky-500 text-slate-800'
                          }`}
                        >
                          <span
                            className="w-2.5 h-2.5 rounded-sm shrink-0"
                            style={{ backgroundColor: nb.swatch }}
                          />
                          <span>{nb.label}</span>
                        </button>
                      ))}
                    </div>
                  ) : (
                    <div
                      className={`text-xs ${
                        dark ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      {t(UI_TEXT.islandNoBorders, lang)}
                    </div>
                  )}
                </div>
              </>
            ) : selectedRaw ? (
              <div className="space-y-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 font-bold text-base">
                    {selectedRaw.id ? (
                      <CountryFlagBadge countryId={selectedRaw.id} size="md" />
                    ) : (
                      <Navigation className="w-4 h-4 text-emerald-400 shrink-0" />
                    )}
                    <span>{selectedRaw.name}</span>
                  </div>
                  <div
                    dir="ltr"
                    className={`font-mono-tabular text-xs ${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {formatCoords(selectedRaw.coords)}
                  </div>
                </div>

                {selectedRaw.id && selectedCountryCities.length > 0 && (
                  <div className="space-y-1.5">
                    <div
                      className={`text-xs font-semibold ${
                        dark ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      {t(UI_TEXT.countryCitiesLabel, lang)} ({selectedCountryCities.length})
                    </div>
                    <div className="flex flex-wrap gap-1.5 max-h-48 overflow-y-auto">
                      {selectedCountryCities.map((city) => (
                        <button
                          key={city.id}
                          type="button"
                          onClick={() => handleCitySelect(city)}
                          className={`px-2.5 py-1 rounded-lg border text-xs font-medium inline-flex items-center gap-1 transition-colors cursor-pointer ${
                            city.isCapital
                              ? dark
                                ? 'bg-amber-500/15 border-amber-500/50 text-amber-300 hover:bg-amber-500/25'
                                : 'bg-amber-50 border-amber-300 text-amber-800 hover:bg-amber-100'
                              : dark
                              ? 'bg-slate-800 border-slate-700 hover:border-emerald-500 text-slate-200'
                              : 'bg-slate-100 border-slate-200 hover:border-emerald-500 text-slate-800'
                          }`}
                        >
                          <span>{locCityName(city, lang)}</span>
                          {city.isCapital && (
                            <span className="text-[10px] opacity-80">★</span>
                          )}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                {selectedRaw.id && (
                  <div className="space-y-1.5">
                    <div
                      className={`text-xs font-semibold ${
                        dark ? 'text-slate-400' : 'text-slate-500'
                      }`}
                    >
                      {t(UI_TEXT.neighborsLabel, lang)}
                    </div>
                    {neighborEntries.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5">
                        {neighborEntries.map((nb) => (
                          <button
                            key={nb.id}
                            type="button"
                            onClick={() => {
                              soundEngine.playClick();
                              if (nb.meta) {
                                setSelectedCountry(nb.meta);
                                setSelectedRaw(null);
                                setFocusTarget({
                                  center: nb.meta.center,
                                  zoom: 3.4,
                                  key: Date.now(),
                                });
                              } else {
                                setSelectedRaw({
                                  id: nb.id,
                                  name: nb.label,
                                  coords: selectedRaw.coords,
                                });
                              }
                            }}
                            className={`px-2.5 py-1 rounded-lg border text-xs font-medium inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
                              dark
                                ? 'bg-slate-800 border-slate-700 hover:border-sky-500 text-slate-200'
                                : 'bg-slate-100 border-slate-200 hover:border-sky-500 text-slate-800'
                            }`}
                          >
                            <span
                              className="w-2.5 h-2.5 rounded-sm shrink-0"
                              style={{ backgroundColor: nb.swatch }}
                            />
                            <span>{nb.label}</span>
                          </button>
                        ))}
                      </div>
                    ) : (
                      <div
                        className={`text-xs ${
                          dark ? 'text-slate-400' : 'text-slate-500'
                        }`}
                      >
                        {t(UI_TEXT.islandNoBorders, lang)}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : null}
          </aside>
        )}
      </div>
    </div>
  );
};
