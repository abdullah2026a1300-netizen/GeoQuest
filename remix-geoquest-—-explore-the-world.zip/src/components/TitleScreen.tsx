import React, { useEffect } from 'react';
import {
  Compass,
  Zap,
  Globe2,
  Trophy,
  BarChart3,
  Settings,
  Volume2,
  VolumeX,
  Languages,
  Youtube,
  Building2,
  Globe,
} from 'lucide-react';
import { GameSettings, Language, PlayerProfile } from '../types/game';
import { UI_TEXT, t } from '../data/i18n';
import { ACHIEVEMENTS, OFFICIAL_YOUTUBE_URL, getRankInfo } from '../utils/storage';
import { WorldMap } from './map/WorldMap';
import { GeoQuestLogo } from './GeoQuestLogo';

interface TitleScreenProps {
  settings: GameSettings;
  profile: PlayerProfile;
  onStartAdventure: () => void;
  onQuickPlay: () => void;
  onOpenWorldMap: () => void;
  onOpenCitiesMap: () => void;
  onOpenSphericalEarth: () => void;
  onOpenChallenges: () => void;
  onOpenStats: () => void;
  onOpenSettings: () => void;
  onToggleLanguage: () => void;
  onSelectLanguage?: (lang: Language) => void;
  onToggleSound: () => void;
}

export const TitleScreen: React.FC<TitleScreenProps> = ({
  settings,
  profile,
  onStartAdventure,
  onQuickPlay,
  onOpenWorldMap,
  onOpenCitiesMap,
  onOpenSphericalEarth,
  onOpenChallenges,
  onOpenStats,
  onOpenSettings,
  onToggleLanguage,
  onSelectLanguage,
  onToggleSound,
}) => {
  const lang = settings.language;
  const dark = settings.darkMode;
  const rank = getRankInfo(profile.xp);

  const latestAchievementId =
    profile.unlockedAchievements[profile.unlockedAchievements.length - 1];
  const latestAchievement = ACHIEVEMENTS.find((a) => a.id === latestAchievementId);

  // Enter / Space starts adventure on Title Screen (per game craft guidelines)
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        onStartAdventure();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [onStartAdventure]);

  return (
    <div
      className={`relative w-full min-h-screen overflow-hidden flex flex-col justify-between ${
        dark ? 'bg-[#060E1A] text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      {/* Live-World Rotating Cloudy Spherical Earth Backdrop */}
      <div className="absolute inset-0 z-0 opacity-95">
        <WorldMap
          language={lang}
          darkMode={dark}
          interactive={false}
          ambientMode={true}
          defaultProjectionMode="globe"
          showClouds={true}
        />
      </div>

      {/* Measured Contrast Scrim keeping calm negative space for title & controls */}
      <div
        className={`pointer-events-none absolute inset-0 z-10 ${
          dark
            ? 'bg-gradient-to-b from-[#060E1A]/65 via-[#060E1A]/35 to-[#060E1A]/85'
            : 'bg-gradient-to-b from-white/65 via-white/35 to-slate-100/85'
        }`}
      />

      {/* Minimal Top Utility Strip (Language & Mute only) */}
      <div className="relative z-20 flex items-center justify-between px-5 sm:px-10 pt-5">
        <div
          className={`text-xs font-mono-tabular tracking-wide ${
            dark ? 'text-slate-400' : 'text-slate-600'
          }`}
        >
          {t(UI_TEXT.appName, lang)} · {t(UI_TEXT.appSubtitle, lang)}
        </div>
        <div className="flex items-center gap-2">
          <div
            className={`h-10 p-1 rounded-xl border inline-flex items-center gap-0.5 shrink-0 ${
              dark
                ? 'bg-slate-900/80 border-slate-700/80'
                : 'bg-white/90 border-slate-300'
            }`}
          >
            <Languages className="w-3.5 h-3.5 text-amber-500 mx-1.5 shrink-0" />
            {(
              [
                ['ar', 'العربية'],
                ['en', 'EN'],
                ['tr', 'Türkçe'],
              ] as const
            ).map(([code, label]) => (
              <button
                key={code}
                type="button"
                onClick={() =>
                  onSelectLanguage ? onSelectLanguage(code) : onToggleLanguage()
                }
                className={`px-2 py-1 rounded-lg text-[11px] font-semibold transition-colors whitespace-nowrap cursor-pointer ${
                  lang === code
                    ? 'bg-amber-500 text-slate-950'
                    : dark
                    ? 'text-slate-300 hover:text-white hover:bg-slate-800'
                    : 'text-slate-700 hover:bg-slate-100'
                }`}
              >
                {label}
              </button>
            ))}
          </div>
          <button
            type="button"
            onClick={onToggleSound}
            aria-label={t(UI_TEXT.soundSetting, lang)}
            className={`w-10 h-10 rounded-xl border inline-flex items-center justify-center transition-colors shrink-0 cursor-pointer ${
              dark
                ? 'bg-slate-900/80 border-slate-700/80 text-slate-200 hover:bg-slate-800'
                : 'bg-white/90 border-slate-300 text-slate-800 hover:bg-white'
            }`}
          >
            {settings.soundEnabled ? (
              <Volume2 className="w-4 h-4 text-amber-500" />
            ) : (
              <VolumeX className="w-4 h-4 text-slate-400" />
            )}
          </button>
        </div>
      </div>

      {/* Main Centered Hero Lockup & Game Actions */}
      <main className="relative z-20 flex-1 flex items-center justify-center px-5 sm:px-10 py-8">
        <div className="w-full max-w-4xl grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Primary Title & Action Column */}
          <div className="lg:col-span-7 flex flex-col items-start gap-6">
            <GeoQuestLogo size="lg" darkMode={dark} />

            <div className="space-y-3 max-w-xl">
              <h1
                className={`font-display text-3xl sm:text-5xl font-extrabold leading-tight ${
                  dark ? 'text-white' : 'text-slate-900'
                }`}
                style={{ textWrap: 'balance' }}
              >
                {t(UI_TEXT.appSubtitle, lang)}
              </h1>
              <p
                className={`text-base sm:text-lg leading-relaxed ${
                  dark ? 'text-slate-300' : 'text-slate-700'
                }`}
              >
                {t(UI_TEXT.heroLead, lang)}
              </p>
            </div>

            {/* Primary & Secondary Launch Actions */}
            <div className="flex flex-wrap items-center gap-3 w-full">
              <button
                type="button"
                onClick={onStartAdventure}
                className="h-12 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-base inline-flex items-center gap-2.5 shadow-lg shadow-amber-500/20 transition-transform active:scale-[0.98] whitespace-nowrap shrink-0 cursor-pointer"
              >
                <Compass className="w-5 h-5" />
                <span>{t(UI_TEXT.startAdventure, lang)}</span>
              </button>

              <button
                type="button"
                onClick={onQuickPlay}
                className={`h-12 px-5 rounded-xl border font-semibold text-sm inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  dark
                    ? 'bg-slate-900/85 border-slate-700 text-slate-100 hover:bg-slate-800'
                    : 'bg-white/95 border-slate-300 text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Zap className="w-4 h-4 text-amber-500" />
                <span>{t(UI_TEXT.quickPlay, lang)}</span>
              </button>

              <button
                type="button"
                onClick={onOpenWorldMap}
                className={`h-12 px-5 rounded-xl border font-semibold text-sm inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  dark
                    ? 'bg-slate-900/85 border-slate-700 text-slate-100 hover:bg-slate-800'
                    : 'bg-white/95 border-slate-300 text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Globe2 className="w-4 h-4 text-sky-400" />
                <span>{t(UI_TEXT.worldMap, lang)}</span>
              </button>

              <button
                type="button"
                onClick={onOpenCitiesMap}
                className={`h-12 px-5 rounded-xl border font-semibold text-sm inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  dark
                    ? 'bg-slate-900/85 border-slate-700 text-slate-100 hover:bg-slate-800'
                    : 'bg-white/95 border-slate-300 text-slate-900 hover:bg-slate-50'
                }`}
              >
                <Building2 className="w-4 h-4 text-emerald-400" />
                <span>{t(UI_TEXT.citiesMap, lang)}</span>
              </button>

              <button
                type="button"
                onClick={onOpenSphericalEarth}
                className={`h-12 px-5 rounded-xl border font-semibold text-sm inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  dark
                    ? 'bg-slate-900/85 border-sky-500/40 text-sky-300 hover:bg-sky-500/15 hover:border-sky-400'
                    : 'bg-white/95 border-sky-300 text-sky-800 hover:bg-sky-50'
                }`}
              >
                <Globe className="w-4 h-4 text-sky-400" />
                <span>{t(UI_TEXT.sphericalEarth, lang)}</span>
              </button>
            </div>

            {/* Tertiary Menu Buttons */}
            <div className="flex flex-wrap items-center gap-2.5">
              <button
                type="button"
                onClick={onOpenChallenges}
                className={`h-11 px-4 rounded-xl border text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  dark
                    ? 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-slate-600 hover:bg-slate-800/80'
                    : 'bg-white/85 border-slate-200 text-slate-800 hover:bg-white'
                }`}
              >
                <Trophy className="w-4 h-4 text-amber-500" />
                <span>{t(UI_TEXT.challenges, lang)}</span>
              </button>

              <button
                type="button"
                onClick={onOpenStats}
                className={`h-11 px-4 rounded-xl border text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  dark
                    ? 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-slate-600 hover:bg-slate-800/80'
                    : 'bg-white/85 border-slate-200 text-slate-800 hover:bg-white'
                }`}
              >
                <BarChart3 className="w-4 h-4 text-emerald-400" />
                <span>{t(UI_TEXT.statistics, lang)}</span>
              </button>

              <button
                type="button"
                onClick={onOpenSettings}
                className={`h-11 px-4 rounded-xl border text-sm font-medium inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 cursor-pointer ${
                  dark
                    ? 'bg-slate-900/70 border-slate-800 text-slate-200 hover:border-slate-600 hover:bg-slate-800/80'
                    : 'bg-white/85 border-slate-200 text-slate-800 hover:bg-white'
                }`}
              >
                <Settings className="w-4 h-4 text-slate-400" />
                <span>{t(UI_TEXT.settings, lang)}</span>
              </button>

              <a
                href={OFFICIAL_YOUTUBE_URL}
                target="_blank"
                rel="noopener noreferrer"
                className={`h-11 px-4 rounded-xl border text-sm font-semibold inline-flex items-center gap-2 transition-colors whitespace-nowrap shrink-0 ${
                  dark
                    ? 'bg-red-950/50 border-red-500/40 text-red-100 hover:border-red-400 hover:bg-red-500/20'
                    : 'bg-red-50 border-red-200 text-red-700 hover:border-red-400 hover:bg-red-100'
                }`}
              >
                <Youtube className="w-4 h-4 text-red-500 shrink-0" />
                <span>{t(UI_TEXT.visitYoutubeChannel, lang)}</span>
              </a>
            </div>
          </div>

          {/* Explorer Dossier Card (Level, Best Score, Latest Achievement) */}
          <div className="lg:col-span-5">
            <div
              className={`rounded-2xl border p-6 space-y-5 shadow-xl ${
                dark
                  ? 'bg-slate-900/85 border-slate-800/90 backdrop-blur-md'
                  : 'bg-white/90 border-slate-200 backdrop-blur-md'
              }`}
            >
              {/* Rank & Level */}
              <div className="space-y-2.5">
                <div className="flex items-baseline justify-between gap-2">
                  <span
                    className={`text-xs font-medium ${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.playerLevel, lang)} {rank.level}
                  </span>
                  <span className="font-mono-tabular text-xs text-amber-500 font-semibold">
                    {profile.xp} XP
                  </span>
                </div>
                <div
                  className={`text-lg font-bold ${
                    dark ? 'text-white' : 'text-slate-900'
                  }`}
                >
                  {t(rank.title, lang)}
                </div>
                <div
                  className={`w-full h-2 rounded-full overflow-hidden ${
                    dark ? 'bg-slate-800' : 'bg-slate-200'
                  }`}
                >
                  <div
                    className="h-full bg-amber-500 transition-all duration-300"
                    style={{ width: `${rank.progressPercent}%` }}
                  />
                </div>
              </div>

              <div
                className={`h-px w-full ${
                  dark ? 'bg-slate-800' : 'bg-slate-200'
                }`}
              />

              {/* Best Score & Streak */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div
                    className={`text-xs mb-1 ${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.bestScore, lang)}
                  </div>
                  <div
                    className={`font-mono-tabular text-2xl font-bold ${
                      dark ? 'text-white' : 'text-slate-900'
                    }`}
                  >
                    {profile.bestScore.toLocaleString()}
                  </div>
                </div>
                <div>
                  <div
                    className={`text-xs mb-1 ${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.bestStreak, lang)}
                  </div>
                  <div
                    className={`font-mono-tabular text-2xl font-bold ${
                      dark ? 'text-emerald-400' : 'text-emerald-600'
                    }`}
                  >
                    {profile.bestStreak}
                  </div>
                </div>
              </div>

              <div
                className={`h-px w-full ${
                  dark ? 'bg-slate-800' : 'bg-slate-200'
                }`}
              />

              {/* Latest Achievement */}
              <div>
                <div
                  className={`text-xs mb-1.5 ${
                    dark ? 'text-slate-400' : 'text-slate-500'
                  }`}
                >
                  {t(UI_TEXT.latestAchievement, lang)}
                </div>
                {latestAchievement ? (
                  <div className="flex items-start gap-2.5">
                    <Trophy className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
                    <div>
                      <div
                        className={`text-sm font-semibold ${
                          dark ? 'text-slate-100' : 'text-slate-900'
                        }`}
                      >
                        {t(latestAchievement.title, lang)}
                      </div>
                      <div
                        className={`text-xs ${
                          dark ? 'text-slate-400' : 'text-slate-600'
                        }`}
                      >
                        {t(latestAchievement.description, lang)}
                      </div>
                    </div>
                  </div>
                ) : (
                  <div
                    className={`text-sm ${
                      dark ? 'text-slate-400' : 'text-slate-500'
                    }`}
                  >
                    {t(UI_TEXT.noAchievementsYet, lang)}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Single flat control-hint line */}
      <div className="relative z-20 pb-5 px-5 text-center">
        <p
          className={`text-xs ${
            dark ? 'text-slate-400' : 'text-slate-600'
          }`}
        >
          {t(UI_TEXT.controlHint, lang)}
        </p>
      </div>
    </div>
  );
};
