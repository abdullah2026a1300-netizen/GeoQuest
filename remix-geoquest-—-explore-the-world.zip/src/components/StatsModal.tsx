import React, { useState } from 'react';
import { X, Trophy, CheckCircle2, Lock, Trash2 } from 'lucide-react';
import { GameSettings, PlayerProfile } from '../types/game';
import { MODE_INFO, UI_TEXT, t } from '../data/i18n';
import { ACHIEVEMENTS, getRankInfo } from '../utils/storage';

interface StatsModalProps {
  settings: GameSettings;
  profile: PlayerProfile;
  onResetProfile: () => void;
  onClose: () => void;
}

export const StatsModal: React.FC<StatsModalProps> = ({
  settings,
  profile,
  onResetProfile,
  onClose,
}) => {
  const lang = settings.language;
  const dark = settings.darkMode;
  const rank = getRankInfo(profile.xp);
  const [confirmReset, setConfirmReset] = useState(false);

  const accuracy =
    profile.totalAnswered > 0
      ? Math.round((profile.totalCorrect / profile.totalAnswered) * 100)
      : 0;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div
        className={`w-full max-w-3xl max-h-[90vh] rounded-2xl border shadow-2xl flex flex-col overflow-hidden ${
          dark
            ? 'bg-slate-900 border-slate-800 text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div
          className={`flex items-center justify-between px-6 py-4 border-b ${
            dark ? 'border-slate-800' : 'border-slate-200'
          }`}
        >
          <h2 className="font-display text-xl font-bold">
            {t(UI_TEXT.statistics, lang)}
          </h2>
          <button
            type="button"
            onClick={onClose}
            aria-label={t(UI_TEXT.close, lang)}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors cursor-pointer ${
              dark ? 'hover:bg-slate-800 text-slate-400' : 'hover:bg-slate-100 text-slate-500'
            }`}
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Rank Banner */}
          <div
            className={`rounded-xl border p-5 space-y-3 ${
              dark ? 'bg-slate-950/60 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <div
                  className={`text-xs ${
                    dark ? 'text-slate-400' : 'text-slate-500'
                  }`}
                >
                  {t(UI_TEXT.playerLevel, lang)} {rank.level}
                </div>
                <div className="text-xl font-bold">{t(rank.title, lang)}</div>
              </div>
              <div className="font-mono-tabular text-sm font-bold text-amber-500">
                {profile.xp.toLocaleString()} XP
              </div>
            </div>
            <div
              className={`w-full h-2.5 rounded-full overflow-hidden ${
                dark ? 'bg-slate-800' : 'bg-slate-200'
              }`}
            >
              <div
                className="h-full bg-amber-500"
                style={{ width: `${rank.progressPercent}%` }}
              />
            </div>
          </div>

          {/* Core Metrics */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              {
                label: t(UI_TEXT.bestScore, lang),
                value: profile.bestScore.toLocaleString(),
              },
              {
                label: t(UI_TEXT.gamesPlayed, lang),
                value: String(profile.gamesPlayed),
              },
              {
                label: t(UI_TEXT.accuracy, lang),
                value: `${accuracy}%`,
              },
              {
                label: t(UI_TEXT.bestStreak, lang),
                value: String(profile.bestStreak),
              },
            ].map((stat, idx) => (
              <div
                key={idx}
                className={`rounded-xl border p-4 ${
                  dark
                    ? 'bg-slate-950/40 border-slate-800'
                    : 'bg-slate-50 border-slate-200'
                }`}
              >
                <div
                  className={`text-xs mb-1 ${
                    dark ? 'text-slate-400' : 'text-slate-500'
                  }`}
                >
                  {stat.label}
                </div>
                <div className="font-mono-tabular text-2xl font-bold">
                  {stat.value}
                </div>
              </div>
            ))}
          </div>

          {/* Achievements */}
          <div className="space-y-3">
            <h3 className="font-display text-base font-bold flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-500" />
              <span>
                {t(UI_TEXT.achievementsTitle, lang)} (
                {profile.unlockedAchievements.length}/{ACHIEVEMENTS.length})
              </span>
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {ACHIEVEMENTS.map((ach) => {
                const unlocked = profile.unlockedAchievements.includes(ach.id);
                return (
                  <div
                    key={ach.id}
                    className={`rounded-xl border p-3.5 flex items-start gap-3 ${
                      unlocked
                        ? dark
                          ? 'bg-emerald-500/10 border-emerald-500/40'
                          : 'bg-emerald-50 border-emerald-200'
                        : dark
                        ? 'bg-slate-950/40 border-slate-800 opacity-65'
                        : 'bg-slate-50 border-slate-200 opacity-70'
                    }`}
                  >
                    {unlocked ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <Lock className="w-5 h-5 text-slate-500 shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-sm font-bold truncate">
                          {t(ach.title, lang)}
                        </span>
                        <span className="font-mono-tabular text-[11px] text-amber-500 shrink-0">
                          +{ach.xpReward} XP
                        </span>
                      </div>
                      <p
                        className={`text-xs mt-0.5 ${
                          dark ? 'text-slate-400' : 'text-slate-600'
                        }`}
                      >
                        {t(ach.description, lang)}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Runs */}
          {profile.history.length > 0 && (
            <div className="space-y-3">
              <h3 className="font-display text-base font-bold">
                {t(UI_TEXT.recentRuns, lang)}
              </h3>
              <div className="space-y-2">
                {profile.history.slice(0, 6).map((run) => (
                  <div
                    key={run.id}
                    className={`rounded-xl border px-4 py-3 flex flex-wrap items-center justify-between gap-2 text-sm ${
                      dark
                        ? 'bg-slate-950/40 border-slate-800'
                        : 'bg-slate-50 border-slate-200'
                    }`}
                  >
                    <div className="font-semibold">
                      {t(MODE_INFO[run.mode].title, lang)}
                    </div>
                    <div
                      className={`flex items-center gap-3 text-xs font-mono-tabular ${
                        dark ? 'text-slate-400' : 'text-slate-600'
                      }`}
                    >
                      <span>
                        {run.correctCount}/{run.totalQuestions}
                      </span>
                      <span aria-hidden="true">·</span>
                      <span className="text-amber-500 font-bold">
                        {run.score.toLocaleString()} pts
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div
          className={`px-6 py-4 border-t flex items-center justify-between gap-3 ${
            dark ? 'border-slate-800 bg-slate-950/40' : 'border-slate-200 bg-slate-50'
          }`}
        >
          {confirmReset ? (
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => {
                  onResetProfile();
                  setConfirmReset(false);
                }}
                className="h-10 px-4 rounded-xl bg-red-600 hover:bg-red-500 text-white text-xs font-bold cursor-pointer"
              >
                {t(UI_TEXT.resetStats, lang)}
              </button>
              <button
                type="button"
                onClick={() => setConfirmReset(false)}
                className={`h-10 px-3 rounded-xl text-xs cursor-pointer ${
                  dark ? 'text-slate-300' : 'text-slate-600'
                }`}
              >
                {t(UI_TEXT.close, lang)}
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmReset(true)}
              className="h-10 px-3 rounded-xl text-xs font-medium text-red-400 hover:bg-red-500/10 inline-flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t(UI_TEXT.resetStats, lang)}</span>
            </button>
          )}
          <button
            type="button"
            onClick={onClose}
            className="h-10 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition-colors cursor-pointer"
          >
            {t(UI_TEXT.close, lang)}
          </button>
        </div>
      </div>
    </div>
  );
};
