import React from 'react';
import { Trophy, RotateCcw, Home, CheckCircle2, XCircle, Award, Youtube } from 'lucide-react';
import {
  AchievementDef,
  GameMode,
  GameSettings,
  PlayerProfile,
  RoundResult,
} from '../types/game';
import { MODE_INFO, UI_TEXT, t } from '../data/i18n';
import { OFFICIAL_YOUTUBE_URL, getRankInfo } from '../utils/storage';
import { CountryFlagBadge } from './CountryFlagBadge';

interface ResultsScreenProps {
  settings: GameSettings;
  profile: PlayerProfile;
  mode: GameMode;
  score: number;
  runBestStreak: number;
  results: RoundResult[];
  xpEarned: number;
  newlyUnlocked: AchievementDef[];
  onPlayAgain: () => void;
  onBackHome: () => void;
}

export const ResultsScreen: React.FC<ResultsScreenProps> = ({
  settings,
  profile,
  mode,
  score,
  runBestStreak,
  results,
  xpEarned,
  newlyUnlocked,
  onPlayAgain,
  onBackHome,
}) => {
  const lang = settings.language;
  const dark = settings.darkMode;
  const rank = getRankInfo(profile.xp);

  const correctCount = results.filter((r) => r.solved).length;
  const totalCount = results.length;
  const accuracy =
    totalCount > 0 ? Math.round((correctCount / totalCount) * 100) : 0;

  return (
    <div
      className={`min-h-screen w-full flex items-center justify-center p-4 sm:p-8 ${
        dark ? 'bg-[#060E1A] text-slate-100' : 'bg-slate-100 text-slate-900'
      }`}
    >
      <div
        className={`w-full max-w-3xl rounded-2xl border shadow-2xl overflow-hidden ${
          dark
            ? 'bg-slate-900 border-slate-800'
            : 'bg-white border-slate-200'
        }`}
      >
        {/* Summary Header */}
        <div
          className={`px-6 sm:px-8 py-6 border-b flex flex-wrap items-center justify-between gap-4 ${
            dark ? 'border-slate-800 bg-slate-950/50' : 'border-slate-200 bg-slate-50'
          }`}
        >
          <div className="space-y-1">
            <div className="text-xs font-semibold text-amber-500">
              {t(MODE_INFO[mode].title, lang)}
            </div>
            <h1 className="font-display text-2xl sm:text-3xl font-extrabold">
              {t(UI_TEXT.resultsTitle, lang)}
            </h1>
          </div>
          <div className="text-end">
            <div
              className={`text-xs ${
                dark ? 'text-slate-400' : 'text-slate-500'
              }`}
            >
              {t(UI_TEXT.score, lang)}
            </div>
            <div className="font-mono-tabular text-3xl sm:text-4xl font-extrabold text-amber-500">
              {score.toLocaleString()}
            </div>
          </div>
        </div>

        <div className="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
          {/* KPI Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div
              className={`rounded-xl border p-4 ${
                dark ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className={`text-xs ${dark ? 'text-slate-400' : 'text-slate-500'}`}>
                {t(UI_TEXT.totalCorrect, lang)}
              </div>
              <div className="font-mono-tabular text-2xl font-bold mt-1">
                {correctCount}/{totalCount}
              </div>
            </div>
            <div
              className={`rounded-xl border p-4 ${
                dark ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className={`text-xs ${dark ? 'text-slate-400' : 'text-slate-500'}`}>
                {t(UI_TEXT.accuracy, lang)}
              </div>
              <div className="font-mono-tabular text-2xl font-bold mt-1 text-emerald-400">
                {accuracy}%
              </div>
            </div>
            <div
              className={`rounded-xl border p-4 ${
                dark ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className={`text-xs ${dark ? 'text-slate-400' : 'text-slate-500'}`}>
                {t(UI_TEXT.bestStreak, lang)}
              </div>
              <div className="font-mono-tabular text-2xl font-bold mt-1">
                {runBestStreak}
              </div>
            </div>
            <div
              className={`rounded-xl border p-4 ${
                dark ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
              }`}
            >
              <div className={`text-xs ${dark ? 'text-slate-400' : 'text-slate-500'}`}>
                {t(UI_TEXT.xpEarned, lang)}
              </div>
              <div className="font-mono-tabular text-2xl font-bold mt-1 text-amber-500">
                +{xpEarned}
              </div>
            </div>
          </div>

          {/* Rank Progress */}
          <div
            className={`rounded-xl border p-4 space-y-2 ${
              dark ? 'bg-slate-950/40 border-slate-800' : 'bg-slate-50 border-slate-200'
            }`}
          >
            <div className="flex items-center justify-between text-xs font-semibold">
              <span className="flex items-center gap-1.5">
                <Award className="w-4 h-4 text-amber-500" />
                <span>
                  {t(UI_TEXT.playerLevel, lang)} {rank.level} · {t(rank.title, lang)}
                </span>
              </span>
              <span className="font-mono-tabular text-amber-500">
                {rank.currentXpInLevel}/{rank.xpForNextLevel} XP
              </span>
            </div>
            <div
              className={`w-full h-2 rounded-full overflow-hidden ${
                dark ? 'bg-slate-800' : 'bg-slate-200'
              }`}
            >
              <div
                className="h-full bg-amber-500 transition-all duration-500"
                style={{ width: `${rank.progressPercent}%` }}
              />
            </div>
          </div>

          {/* Newly Unlocked Achievements */}
          {newlyUnlocked.length > 0 && (
            <div className="space-y-2.5">
              <h2 className="font-display text-sm font-bold flex items-center gap-2 text-amber-500">
                <Trophy className="w-4 h-4" />
                <span>{t(UI_TEXT.achievementsUnlocked, lang)}</span>
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {newlyUnlocked.map((ach) => (
                  <div
                    key={ach.id}
                    className={`rounded-xl border p-3.5 ${
                      dark
                        ? 'bg-amber-500/10 border-amber-500/40'
                        : 'bg-amber-50 border-amber-200'
                    }`}
                  >
                    <div className="font-bold text-sm">{t(ach.title, lang)}</div>
                    <div
                      className={`text-xs mt-0.5 ${
                        dark ? 'text-slate-300' : 'text-slate-600'
                      }`}
                    >
                      {t(ach.description, lang)}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Question-by-Question Review */}
          <div className="space-y-2.5">
            <h2 className="font-display text-sm font-bold">
              {t(UI_TEXT.questionReview, lang)}
            </h2>
            <div className="space-y-2">
              {results.map((r, idx) => (
                <div
                  key={`${r.question.id}-${idx}`}
                  className={`rounded-xl border px-4 py-3 flex items-center justify-between gap-3 text-sm ${
                    dark
                      ? 'bg-slate-950/40 border-slate-800'
                      : 'bg-slate-50 border-slate-200'
                  }`}
                >
                  <div className="flex items-start gap-2.5 min-w-0">
                    {r.solved ? (
                      <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
                    )}
                    <div className="min-w-0">
                      <div className="font-semibold truncate flex items-center gap-1.5">
                        <CountryFlagBadge
                          countryId={r.question.flagCountryId || r.question.targetCountryId}
                          size="sm"
                        />
                        <span className="truncate">{t(r.question.question, lang)}</span>
                      </div>
                      <div
                        className={`text-xs ${
                          dark ? 'text-slate-400' : 'text-slate-500'
                        }`}
                      >
                        {t(r.question.correctAnswer, lang)}
                      </div>
                    </div>
                  </div>
                  <div className="font-mono-tabular text-xs font-bold shrink-0 text-amber-500">
                    +{r.pointsEarned}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div
          className={`px-6 sm:px-8 py-4 border-t flex flex-wrap items-center justify-between gap-3 ${
            dark ? 'border-slate-800 bg-slate-950/50' : 'border-slate-200 bg-slate-50'
          }`}
        >
          <button
            type="button"
            onClick={onBackHome}
            className={`h-11 px-5 rounded-xl border text-sm font-semibold inline-flex items-center gap-2 transition-colors cursor-pointer ${
              dark
                ? 'bg-slate-900 border-slate-700 text-slate-200 hover:bg-slate-800'
                : 'bg-white border-slate-300 text-slate-800 hover:bg-slate-100'
            }`}
          >
            <Home className="w-4 h-4" />
            <span>{t(UI_TEXT.backHome, lang)}</span>
          </button>

          <a
            href={OFFICIAL_YOUTUBE_URL}
            target="_blank"
            rel="noopener noreferrer"
            className={`h-11 px-4 rounded-xl border text-xs sm:text-sm font-semibold inline-flex items-center gap-2 transition-colors ${
              dark
                ? 'bg-red-950/40 border-red-500/40 text-red-100 hover:bg-red-500/20'
                : 'bg-red-50 border-red-200 text-red-700 hover:bg-red-100'
            }`}
          >
            <Youtube className="w-4 h-4 text-red-500 shrink-0" />
            <span>{t(UI_TEXT.visitYoutubeChannel, lang)}</span>
          </a>

          <button
            type="button"
            onClick={onPlayAgain}
            className="h-11 px-6 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm inline-flex items-center gap-2 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>{t(UI_TEXT.playAgain, lang)}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
