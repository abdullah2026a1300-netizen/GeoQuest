import {
  CityPoint,
  ContinentId,
  CountryMeta,
  Difficulty,
  DifficultySetting,
  GameMode,
  GeoQuestion,
  LandmarkMeta,
  LocalizedText,
  QuestionCategoryId,
} from '../types/game';
import { COUNTRIES_DATA, COUNTRY_BY_ID } from './countriesData';
import { getAllWorldCities } from './countryGeoStats';
import { CONTINENT_LABELS, locCityCountryName, locCityName, locCountryCapital, locCountryName } from './i18n';
import { LANDMARKS_DATA } from './landmarksData';
import { COUNTRY_META_EXTRA } from './millionCategories';

const CONTINENT_NAMES: Record<ContinentId, LocalizedText> = CONTINENT_LABELS;

function shuffle<T>(arr: T[]): T[] {
  const copy = [...arr];
  for (let i = copy.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [copy[i], copy[j]] = [copy[j], copy[i]];
  }
  return copy;
}

function getBasePoints(diff: Difficulty): number {
  if (diff === 'easy') return 100;
  if (diff === 'medium') return 150;
  return 220;
}

function getHemisphereDirectionHint(center: [number, number]): LocalizedText {
  const [lon, lat] = center;
  const nsAr = lat >= 12 ? 'النصف الشمالي' : lat <= -12 ? 'النصف الجنوبي' : 'المنطقة الاستوائية';
  const nsEn = lat >= 12 ? 'northern latitudes' : lat <= -12 ? 'southern latitudes' : 'near the Equator';
  const nsTr = lat >= 12 ? 'kuzey enlemlerinde' : lat <= -12 ? 'güney enlemlerinde' : 'Ekvator yakınlarında';
  const ewAr = lon >= 15 ? 'الشرق' : lon <= -25 ? 'الغرب' : 'الوسط';
  const ewEn = lon >= 15 ? 'eastern hemisphere' : lon <= -25 ? 'western hemisphere' : 'central longitudes';
  const ewTr = lon >= 15 ? 'doğu yarımkürede' : lon <= -25 ? 'batı yarımkürede' : 'orta boylamlarda';
  return {
    ar: `الاتجاه العام: تقع في ${nsAr} باتجاه ${ewAr} من خريطة العالم.`,
    en: `General position: located in ${nsEn} toward the ${ewEn}.`,
    tr: `Genel konum: ${nsTr} ve ${ewTr} yer alır.`,
  };
}

function sanitizeAnswerFromText(text: string, answer: string, replacement: string): string {
  if (!answer) return text;
  return text.split(answer).join(replacement);
}

function buildCountryLocateQuestion(c: CountryMeta, variant: number): GeoQuestion {
  const contName = CONTINENT_NAMES[c.continent];
  const nameTr = locCountryName(c, 'tr');
  const capTr = locCountryCapital(c, 'tr');
  const neighborNames = c.neighbors
    .map((nid) => COUNTRY_BY_ID[nid])
    .filter(Boolean)
    .slice(0, 2);

  const neighborHint: LocalizedText =
    neighborNames.length > 0
      ? {
          ar: `دولة مجاورة: تشترك في الحدود مع ${neighborNames.map((n) => n.name.ar).join(' و')}.`,
          en: `Neighboring country: shares a border with ${neighborNames.map((n) => n.name.en).join(' and ')}.`,
          tr: `Komşu ülke: ${neighborNames.map((n) => locCountryName(n, 'tr')).join(' ve ')} ile sınırı vardır.`,
        }
      : {
          ar: `معلومة جغرافية: دولة جزرية تحيط بها المياه وعاصمتها ${c.capital.ar}.`,
          en: `Geographic clue: an island nation whose capital is ${c.capital.en}.`,
          tr: `Coğrafi ipucu: Başkenti ${capTr} olan bir ada ülkesidir.`,
        };

  const prompts: LocalizedText[] = [
    {
      ar: `أين تقع دولة ${c.name.ar}؟`,
      en: `Where is ${c.name.en} located?`,
      tr: `${nameTr} ülkesi haritada nerede yer alır?`,
    },
    {
      ar: `حدد دولة ${c.name.ar} على الخريطة.`,
      en: `Locate ${c.name.en} on the map.`,
      tr: `${nameTr} ülkesini haritada işaretleyin.`,
    },
  ];

  return {
    id: `country-${c.id}-${variant}`,
    question: prompts[variant % prompts.length],
    type: 'country_locate',
    targetKind: 'country',
    correctAnswer: { ...c.name, tr: nameTr },
    targetCountryId: c.id,
    flagCountryId: c.id,
    validCountryIds: [c.id],
    targetLocationName: { ...c.name, tr: nameTr },
    coordinates: c.center,
    toleranceKm: 400,
    continent: c.continent,
    difficulty: c.difficulty,
    hints: [
      {
        ar: `القارة: تقع في قارة ${contName.ar}.`,
        en: `Continent: located in ${contName.en}.`,
        tr: `Kıta: ${contName.tr ?? contName.en} kıtasında bulunur.`,
      },
      getHemisphereDirectionHint(c.center),
      neighborHint,
      {
        ar: `كشف الموقع: عاصمتها ${c.capital.ar} عند الإحداثيات (${c.center[1].toFixed(1)}°, ${c.center[0].toFixed(1)}°). تم تقريب الخريطة نحو المنطقة!`,
        en: `Final clue: its capital is ${c.capital.en} near (${c.center[1].toFixed(1)}°, ${c.center[0].toFixed(1)}°). Map zoomed toward the region!`,
        tr: `Son ipucu: Başkenti ${capTr}, yaklaşık (${c.center[1].toFixed(1)}°, ${c.center[0].toFixed(1)}°). Harita bölgeye yaklaştırıldı!`,
      },
    ],
    points: getBasePoints(c.difficulty),
    fact: c.fact,
  };
}

function buildDirectionalCountryQuestion(
  target: CountryMeta,
  refCountry: CountryMeta,
  relation: 'north' | 'south'
): GeoQuestion {
  const contName = CONTINENT_NAMES[target.continent];
  const targetNameTr = locCountryName(target, 'tr');
  const targetCapTr = locCountryCapital(target, 'tr');
  const refNameTr = locCountryName(refCountry, 'tr');

  const qText: LocalizedText =
    relation === 'north'
      ? {
          ar: `ما الدولة التي تقع شمال ${refCountry.name.ar} مباشرة؟`,
          en: `Which country lies directly north of ${refCountry.name.en}?`,
          tr: `${refNameTr} ülkesinin hemen kuzeyinde hangi ülke yer alır?`,
        }
      : {
          ar: `ما الدولة التي تقع جنوب ${refCountry.name.ar} مباشرة؟`,
          en: `Which country lies directly south of ${refCountry.name.en}?`,
          tr: `${refNameTr} ülkesinin hemen güneyinde hangi ülke yer alır?`,
        };

  return {
    id: `dir-${relation}-${target.id}-${refCountry.id}`,
    question: qText,
    type: relation === 'north' ? 'country_north_of' : 'country_south_of',
    targetKind: 'country',
    correctAnswer: { ...target.name, tr: targetNameTr },
    targetCountryId: target.id,
    flagCountryId: refCountry.id,
    validCountryIds: [target.id],
    targetLocationName: { ...target.name, tr: targetNameTr },
    coordinates: target.center,
    toleranceKm: 400,
    continent: target.continent,
    difficulty: target.difficulty === 'easy' ? 'medium' : target.difficulty,
    hints: [
      {
        ar: `القارة: تقع في قارة ${contName.ar}.`,
        en: `Continent: located in ${contName.en}.`,
        tr: `Kıta: ${contName.tr ?? contName.en} kıtasında bulunur.`,
      },
      {
        ar:
          relation === 'north'
            ? `الاتجاه: ابحث أعلى (${refCountry.name.ar}) على الخريطة مباشرة.`
            : `الاتجاه: ابحث أسفل (${refCountry.name.ar}) على الخريطة مباشرة.`,
        en:
          relation === 'north'
            ? `Direction: look directly above ${refCountry.name.en} on the map.`
            : `Direction: look directly below ${refCountry.name.en} on the map.`,
        tr:
          relation === 'north'
            ? `Yön: Haritada doğrudan ${refNameTr} yukarısına bakın.`
            : `Yön: Haritada doğrudan ${refNameTr} aşağısına bakın.`,
      },
      {
        ar: `معلومة جغرافية: عاصمة هذه الدولة هي ${target.capital.ar}.`,
        en: `Geographic clue: the capital of this country is ${target.capital.en}.`,
        tr: `Coğrafi ipucu: Bu ülkenin başkenti ${targetCapTr}.`,
      },
      {
        ar: `الإجابة هي ${target.name.ar} — تم تقريب الخريطة نحو موقعها.`,
        en: `Target country is ${target.name.en} — map focused near its position.`,
        tr: `Doğru ülke ${targetNameTr} — harita konumuna yaklaştırıldı.`,
      },
    ],
    points: getBasePoints('medium'),
    fact: target.fact,
  };
}

function buildCapitalQuestion(c: CountryMeta): GeoQuestion {
  const contName = CONTINENT_NAMES[c.continent];
  const nameTr = locCountryName(c, 'tr');
  const capTr = locCountryCapital(c, 'tr');

  return {
    id: `capital-${c.id}`,
    question: {
      ar: `أين تقع العاصمة ${c.capital.ar}؟`,
      en: `Locate the capital city ${c.capital.en} on the map.`,
      tr: `Başkent ${capTr} haritada nerede yer alır?`,
    },
    type: 'capital_locate',
    targetKind: 'coordinate',
    correctAnswer: {
      ar: `${c.capital.ar} (${c.name.ar})`,
      en: `${c.capital.en} (${c.name.en})`,
      tr: `${capTr} (${nameTr})`,
    },
    targetCountryId: c.id,
    flagCountryId: c.id,
    targetLocationName: { ...c.capital, tr: capTr },
    coordinates: c.capitalCoords,
    toleranceKm: c.difficulty === 'easy' ? 420 : c.difficulty === 'medium' ? 320 : 250,
    continent: c.continent,
    difficulty: c.difficulty === 'easy' ? 'medium' : c.difficulty,
    hints: [
      {
        ar: `القارة: تقع في قارة ${contName.ar}.`,
        en: `Continent: located in ${contName.en}.`,
        tr: `Kıta: ${contName.tr ?? contName.en} kıtasında bulunur.`,
      },
      getHemisphereDirectionHint(c.capitalCoords),
      {
        ar: `الدولة: هي عاصمة دولة ${c.name.ar}.`,
        en: `Country clue: it is the capital of ${c.name.en}.`,
        tr: `Ülke ipucu: ${nameTr} ülkesinin başkentidir.`,
      },
      {
        ar: `الإحداثيات التقريبية لمدينة ${c.capital.ar}: (${c.capitalCoords[1].toFixed(1)}°, ${c.capitalCoords[0].toFixed(1)}°). تم تقريب الخريطة!`,
        en: `Coordinates of ${c.capital.en}: (${c.capitalCoords[1].toFixed(1)}°, ${c.capitalCoords[0].toFixed(1)}°). Map zoomed in!`,
        tr: `${capTr} koordinatları: (${c.capitalCoords[1].toFixed(1)}°, ${c.capitalCoords[0].toFixed(1)}°). Harita yakınlaştırıldı!`,
      },
    ],
    points: getBasePoints(c.difficulty) + 20,
    fact: c.fact,
  };
}

function buildFlagRegionQuestion(c: CountryMeta): GeoQuestion {
  const contName = CONTINENT_NAMES[c.continent];
  const nameTr = locCountryName(c, 'tr');
  const capTr = locCountryCapital(c, 'tr');
  const extra = COUNTRY_META_EXTRA[c.id] ?? {
    flag: '🏳️',
    region: contName,
  };

  return {
    id: `flag-${c.id}`,
    question: {
      ar: `لمن يعود هذا العلم ${extra.flag} في إقليم ${extra.region.ar}؟ حدد الدولة على الخريطة.`,
      en: `Which country in ${extra.region.en} does this flag ${extra.flag} belong to? Locate it on the map.`,
      tr: `${extra.region.tr ?? extra.region.en} bölgesindeki bu bayrak ${extra.flag} hangi ülkeye aittir? Haritada bulun.`,
    },
    type: 'flag_region',
    targetKind: 'country',
    correctAnswer: {
      ar: `${extra.flag} ${c.name.ar}`,
      en: `${extra.flag} ${c.name.en}`,
      tr: `${extra.flag} ${nameTr}`,
    },
    targetCountryId: c.id,
    flagCountryId: c.id,
    validCountryIds: [c.id],
    targetLocationName: { ...c.name, tr: nameTr },
    coordinates: c.center,
    toleranceKm: 400,
    continent: c.continent,
    difficulty: c.difficulty,
    hints: [
      {
        ar: `القارة: تقع في قارة ${contName.ar}.`,
        en: `Continent: located in ${contName.en}.`,
        tr: `Kıta: ${contName.tr ?? contName.en} kıtasında bulunur.`,
      },
      getHemisphereDirectionHint(c.center),
      {
        ar: `العاصمة: عاصمة هذه الدولة هي ${c.capital.ar}.`,
        en: `Capital clue: its capital city is ${c.capital.en}.`,
        tr: `Başkent ipucu: Bu ülkenin başkenti ${capTr}.`,
      },
      {
        ar: `هذه الدولة هي ${c.name.ar} — تم تقريب الخريطة نحو موقعها.`,
        en: `This country is ${c.name.en} — map zoomed toward it.`,
        tr: `Bu ülke ${nameTr} — harita konumuna yaklaştırıldı.`,
      },
    ],
    points: getBasePoints(c.difficulty) + 25,
    fact: c.fact,
  };
}

function buildRiddleQuestion(c: CountryMeta): GeoQuestion {
  const contName = CONTINENT_NAMES[c.continent];
  const nameTr = locCountryName(c, 'tr');
  const capTr = locCountryCapital(c, 'tr');
  const extra = COUNTRY_META_EXTRA[c.id];
  const cleanFactAr = sanitizeAnswerFromText(
    sanitizeAnswerFromText(c.fact.ar, c.name.ar, 'هذه الدولة'),
    c.capital.ar,
    'عاصمتها'
  );
  const cleanFactEn = sanitizeAnswerFromText(
    sanitizeAnswerFromText(c.fact.en, c.name.en, 'this country'),
    c.capital.en,
    'its capital'
  );

  return {
    id: `riddle-${c.id}`,
    question: {
      ar: `لغز جغرافي: ${cleanFactAr} حدد هذه الدولة على الخريطة.`,
      en: `Geo Riddle: ${cleanFactEn} Locate it on the map.`,
      tr: `Coğrafi Bilmece: ${cleanFactEn} Haritada bu ülkeyi bulun.`,
    },
    type: 'riddle',
    targetKind: 'country',
    correctAnswer: { ...c.name, tr: nameTr },
    targetCountryId: c.id,
    validCountryIds: [c.id],
    targetLocationName: { ...c.name, tr: nameTr },
    coordinates: c.center,
    toleranceKm: 400,
    continent: c.continent,
    difficulty: 'hard',
    hints: [
      {
        ar: `القارة والإقليم: ${contName.ar}${extra ? ` (${extra.region.ar})` : ''}.`,
        en: `Region: ${contName.en}${extra ? ` (${extra.region.en})` : ''}.`,
        tr: `Bölge: ${contName.tr ?? contName.en}${extra ? ` (${extra.region.tr ?? extra.region.en})` : ''}.`,
      },
      getHemisphereDirectionHint(c.center),
      {
        ar: `العاصمة: عاصمة هذه الدولة هي ${c.capital.ar}.`,
        en: `Capital clue: its capital city is ${c.capital.en}.`,
        tr: `Başkent ipucu: Bu ülkenin başkenti ${capTr}.`,
      },
      {
        ar: `الحل هو ${c.name.ar} — تم تقريب الخريطة إلى المنطقة.`,
        en: `Solution: ${c.name.en} — map focused on the region.`,
        tr: `Çözüm: ${nameTr} — harita bölgeye odaklandı.`,
      },
    ],
    points: getBasePoints('hard') + 30,
    fact: c.fact,
  };
}

function buildNeighborBorderQuestion(c: CountryMeta): GeoQuestion | null {
  const validNeighbors = c.neighbors.filter((nid) => Boolean(COUNTRY_BY_ID[nid]));
  if (validNeighbors.length === 0) return null;

  const firstNeighbor = COUNTRY_BY_ID[validNeighbors[0]];
  const contName = CONTINENT_NAMES[c.continent];
  const anchorNameTr = locCountryName(c, 'tr');
  const firstNbNameTr = locCountryName(firstNeighbor, 'tr');
  const firstNbCapTr = locCountryCapital(firstNeighbor, 'tr');

  return {
    id: `neighbor-${c.id}`,
    question: {
      ar: `حدد دولة تشترك في الحدود البرية مع ${c.name.ar}.`,
      en: `Select a country that shares a land border with ${c.name.en}.`,
      tr: `${anchorNameTr} ile kara sınırı paylaşan bir ülke seçin.`,
    },
    type: 'neighbor_border',
    targetKind: 'country',
    correctAnswer: {
      ar: `إحدى دول جوار ${c.name.ar} (مثل ${firstNeighbor.name.ar})`,
      en: `A neighbor of ${c.name.en} (e.g. ${firstNeighbor.name.en})`,
      tr: `${anchorNameTr} komşularından biri (ör. ${firstNbNameTr})`,
    },
    targetCountryId: firstNeighbor.id,
    flagCountryId: c.id,
    validCountryIds: validNeighbors,
    targetLocationName: { ...firstNeighbor.name, tr: firstNbNameTr },
    coordinates: firstNeighbor.center,
    toleranceKm: 400,
    continent: c.continent,
    difficulty: validNeighbors.length >= 4 ? 'easy' : 'medium',
    hints: [
      {
        ar: `القارة: تقع في قارة ${contName.ar}.`,
        en: `Continent: look in ${contName.en}.`,
        tr: `Kıta: ${contName.tr ?? contName.en} kıtasına bakın.`,
      },
      {
        ar: `الاتجاه: حدد موقع ${c.name.ar} أولاً ثم اضغط على أي دولة ملاصقة لحدودها.`,
        en: `Strategy: find ${c.name.en} first, then click any adjacent country touching its border.`,
        tr: `İpucu: Önce ${anchorNameTr} ülkesini bulun, ardından sınırına bitişik bir ülkeye tıklayın.`,
      },
      {
        ar: `عدد الجيران: تشترك ${c.name.ar} في الحدود مع ${validNeighbors.length} دول، منها دولة عاصمتها ${firstNeighbor.capital.ar}.`,
        en: `Border count: ${c.name.en} borders ${validNeighbors.length} countries, including one whose capital is ${firstNeighbor.capital.en}.`,
        tr: `Sınır sayısı: ${anchorNameTr}, başkenti ${firstNbCapTr} olan ülke dahil ${validNeighbors.length} ülkeyle komşudur.`,
      },
      {
        ar: `أحد الجيران المباشرين هو ${firstNeighbor.name.ar} — تم تقريب الخريطة إلى المنطقة.`,
        en: `One direct neighbor is ${firstNeighbor.name.en} — map focused on the region.`,
        tr: `Doğrudan komşulardan biri ${firstNbNameTr} — harita bölgeye odaklandı.`,
      },
    ],
    points: getBasePoints('medium'),
    fact: c.fact,
  };
}

function buildBetweenQuestion(c: CountryMeta): GeoQuestion | null {
  if (!c.betweenPair) return null;
  const a = COUNTRY_BY_ID[c.betweenPair[0]];
  const b = COUNTRY_BY_ID[c.betweenPair[1]];
  if (!a || !b) return null;

  const contName = CONTINENT_NAMES[c.continent];
  const nameTr = locCountryName(c, 'tr');
  const capTr = locCountryCapital(c, 'tr');
  const aTr = locCountryName(a, 'tr');
  const bTr = locCountryName(b, 'tr');

  return {
    id: `between-${c.id}`,
    question: {
      ar: `ابحث عن الدولة التي تقع بين ${a.name.ar} و${b.name.ar}.`,
      en: `Find the country located between ${a.name.en} and ${b.name.en}.`,
      tr: `${aTr} ile ${bTr} arasında yer alan ülkeyi bulun.`,
    },
    type: 'neighbor_between',
    targetKind: 'country',
    correctAnswer: { ...c.name, tr: nameTr },
    targetCountryId: c.id,
    validCountryIds: [c.id],
    targetLocationName: { ...c.name, tr: nameTr },
    coordinates: c.center,
    toleranceKm: 400,
    continent: c.continent,
    difficulty: c.difficulty === 'easy' ? 'medium' : c.difficulty,
    hints: [
      {
        ar: `القارة: تقع في قارة ${contName.ar}.`,
        en: `Continent: located in ${contName.en}.`,
        tr: `Kıta: ${contName.tr ?? contName.en} kıtasında bulunur.`,
      },
      {
        ar: `الاتجاه: تقع على الخط الفاصل بين ${a.name.ar} و${b.name.ar}.`,
        en: `Position: situated directly between ${a.name.en} and ${b.name.en}.`,
        tr: `Konum: Doğrudan ${aTr} ile ${bTr} arasında yer alır.`,
      },
      {
        ar: `العاصمة: عاصمة هذه الدولة هي ${c.capital.ar}.`,
        en: `Capital clue: its capital city is ${c.capital.en}.`,
        tr: `Başkent ipucu: Bu ülkenin başkenti ${capTr}.`,
      },
      {
        ar: `الإجابة هي ${c.name.ar} — تم تقريب الخريطة إلى موقعها.`,
        en: `The answer is ${c.name.en} — map zoomed toward it.`,
        tr: `Cevap ${nameTr} — harita konumuna yaklaştırıldı.`,
      },
    ],
    points: getBasePoints('medium') + 20,
    fact: c.fact,
  };
}

function buildLandmarkQuestion(lm: LandmarkMeta): GeoQuestion {
  const contName = CONTINENT_NAMES[lm.continent];
  const lmNameTr = lm.name.tr ?? lm.name.en;
  const typePrefixes: Record<LandmarkMeta['type'], LocalizedText> = {
    sea: {
      ar: `حدد موقع ${lm.name.ar} على الخريطة.`,
      en: `Locate the ${lm.name.en} on the map.`,
      tr: `${lmNameTr} haritada nerede yer alır?`,
    },
    ocean: {
      ar: `حدد موقع ${lm.name.ar} على الخريطة.`,
      en: `Locate the ${lm.name.en} on the map.`,
      tr: `${lmNameTr} haritada nerede bulunur?`,
    },
    island: {
      ar: `أين تقع ${lm.name.ar}؟`,
      en: `Where is the island of ${lm.name.en}?`,
      tr: `${lmNameTr} adası nerede yer alır?`,
    },
    river: {
      ar: `حدد موقع ${lm.name.ar} على الخريطة.`,
      en: `Locate the ${lm.name.en} on the map.`,
      tr: `${lmNameTr} haritada nerede akar?`,
    },
    lake: {
      ar: `أين تقع ${lm.name.ar}؟`,
      en: `Where is ${lm.name.en} located?`,
      tr: `${lmNameTr} gölü nerede yer alır?`,
    },
    mountain: {
      ar: `أين تقع ${lm.name.ar}؟`,
      en: `Where are the ${lm.name.en} located?`,
      tr: `${lmNameTr} nerede yer alır?`,
    },
    desert: {
      ar: `حدد موقع ${lm.name.ar} على الخريطة.`,
      en: `Locate the ${lm.name.en} on the map.`,
      tr: `${lmNameTr} haritada nerededir?`,
    },
    strait: {
      ar: `أين يقع ${lm.name.ar}؟`,
      en: `Locate the ${lm.name.en} on the map.`,
      tr: `${lmNameTr} boğazı haritada nerede bulunur?`,
    },
    city: {
      ar: `أين تقع مدينة ${lm.name.ar}؟`,
      en: `Where is the city of ${lm.name.en} located?`,
      tr: `${lmNameTr} şehri nerede yer alır?`,
    },
    landmark: {
      ar: `أين يقع معلم ${lm.name.ar}؟`,
      en: `Where is ${lm.name.en} located?`,
      tr: `${lmNameTr} haritada nerede bulunur?`,
    },
    wonder: {
      ar: `أين تقع عجيبة ${lm.name.ar}؟`,
      en: `Where is the wonder ${lm.name.en} located?`,
      tr: `${lmNameTr} dünya harikası nerededir?`,
    },
  };

  const mappedType = lm.type === 'city' ? 'city_locate' : lm.type;

  return {
    id: `landmark-${lm.id}`,
    question: typePrefixes[lm.type],
    type: mappedType,
    targetKind: 'coordinate',
    correctAnswer: lm.name,
    targetLocationName: lm.name,
    coordinates: lm.coordinates,
    toleranceKm: lm.toleranceKm,
    continent: lm.continent,
    difficulty: lm.difficulty,
    hints: [
      {
        ar: `النطاق الجغرافي: ${contName.ar}.`,
        en: `Region: ${contName.en}.`,
        tr: `Bölge: ${contName.tr ?? contName.en}.`,
      },
      lm.directionHint,
      lm.countryHint ?? getHemisphereDirectionHint(lm.coordinates),
      {
        ar: `الموقع الدقيق لـ ${lm.name.ar} عند (${lm.coordinates[1].toFixed(1)}°, ${lm.coordinates[0].toFixed(1)}°). تم تقريب الخريطة!`,
        en: `Exact target for ${lm.name.en} is near (${lm.coordinates[1].toFixed(1)}°, ${lm.coordinates[0].toFixed(1)}°). Map zoomed in!`,
        tr: `${lmNameTr} için kesin konum (${lm.coordinates[1].toFixed(1)}°, ${lm.coordinates[0].toFixed(1)}°) yakınındadır. Harita yakınlaştırıldı!`,
      },
    ],
    points: getBasePoints(lm.difficulty) + 15,
    fact: lm.fact,
  };
}

function buildCityPointQuestion(city: CityPoint): GeoQuestion {
  const contName = CONTINENT_NAMES[city.continent];
  const cityNameTr = locCityName(city, 'tr');
  const cityCountryTr = locCityCountryName(city, 'tr');
  return {
    id: `citypt-${city.id}`,
    question: city.isCapital
      ? {
          ar: `أين تقع العاصمة ${city.name.ar}؟`,
          en: `Locate the capital city ${city.name.en} on the map.`,
          tr: `Başkent ${cityNameTr} haritada nerede yer alır?`,
        }
      : {
          ar: `أين تقع مدينة ${city.name.ar}؟`,
          en: `Where is the city of ${city.name.en} located?`,
          tr: `${cityNameTr} şehri haritada nerede yer alır?`,
        },
    type: city.isCapital ? 'capital_locate' : 'city_locate',
    targetKind: 'coordinate',
    correctAnswer: {
      ar: `${city.name.ar} (${city.countryName.ar})`,
      en: `${city.name.en} (${city.countryName.en})`,
      tr: `${cityNameTr} (${cityCountryTr})`,
    },
    targetCountryId: city.countryId,
    flagCountryId: city.countryId,
    targetLocationName: { ...city.name, tr: cityNameTr },
    coordinates: city.coordinates,
    toleranceKm: city.isCapital ? 300 : 250,
    continent: city.continent,
    difficulty: city.isCapital ? 'easy' : 'medium',
    hints: [
      {
        ar: `القارة: تقع في قارة ${contName.ar}.`,
        en: `Continent: located in ${contName.en}.`,
        tr: `Kıta: ${contName.tr ?? contName.en} kıtasında bulunur.`,
      },
      getHemisphereDirectionHint(city.coordinates),
      {
        ar: `الدولة: تقع هذه المدينة في ${city.countryName.ar}.`,
        en: `Country clue: located in ${city.countryName.en}.`,
        tr: `Ülke ipucu: Bu şehir ${cityCountryTr} ülkesindedir.`,
      },
      {
        ar: `الإحداثيات التقريبية لمدينة ${city.name.ar}: (${city.coordinates[1].toFixed(1)}°, ${city.coordinates[0].toFixed(1)}°). تم تقريب الخريطة!`,
        en: `Coordinates of ${city.name.en}: (${city.coordinates[1].toFixed(1)}°, ${city.coordinates[0].toFixed(1)}°). Map zoomed in!`,
        tr: `${cityNameTr} koordinatları: (${city.coordinates[1].toFixed(1)}°, ${city.coordinates[0].toFixed(1)}°). Harita yakınlaştırıldı!`,
      },
    ],
    points: city.isCapital ? 130 : 165,
    fact: city.fact,
  };
}

function matchesDifficulty(qDiff: Difficulty, setting: DifficultySetting): boolean {
  if (setting === 'mixed') return true;
  return qDiff === setting;
}

export function generateQuestionPool(params: {
  mode: GameMode;
  continent: ContinentId;
  difficulty: DifficultySetting;
  count: number;
  category?: QuestionCategoryId;
}): GeoQuestion[] {
  const { mode, continent, difficulty, count, category } = params;

  const filteredCountries =
    continent === 'all'
      ? COUNTRIES_DATA
      : COUNTRIES_DATA.filter((c) => c.continent === continent);

  const filteredLandmarks =
    continent === 'all'
      ? LANDMARKS_DATA
      : LANDMARKS_DATA.filter(
          (l) => l.continent === continent || l.continent === 'all'
        );

  const pool: GeoQuestion[] = [];

  if (category) {
    switch (category) {
      case 'cat_capitals':
        filteredCountries.forEach((c, idx) => {
          pool.push(buildCapitalQuestion(c));
          if (idx % 2 === 0) pool.push(buildCountryLocateQuestion(c, idx));
        });
        break;
      case 'cat_borders':
        filteredCountries.forEach((c) => {
          const nb = buildNeighborBorderQuestion(c);
          if (nb) pool.push(nb);
          const bw = buildBetweenQuestion(c);
          if (bw) pool.push(bw);
          if (c.northNeighbor && COUNTRY_BY_ID[c.northNeighbor]) {
            pool.push(buildDirectionalCountryQuestion(c, COUNTRY_BY_ID[c.northNeighbor], 'north'));
          }
          if (c.southNeighbor && COUNTRY_BY_ID[c.southNeighbor]) {
            pool.push(buildDirectionalCountryQuestion(c, COUNTRY_BY_ID[c.southNeighbor], 'south'));
          }
        });
        break;
      case 'cat_cities': {
        const continentCities =
          continent === 'all'
            ? getAllWorldCities()
            : getAllWorldCities().filter((c) => c.continent === continent);
        continentCities.forEach((city) => pool.push(buildCityPointQuestion(city)));
        break;
      }
      case 'cat_landmarks':
        filteredLandmarks
          .filter((l) => l.type === 'landmark' || l.type === 'wonder')
          .forEach((lm) => pool.push(buildLandmarkQuestion(lm)));
        break;
      case 'cat_mountains_rivers':
        filteredLandmarks
          .filter((l) => l.type === 'mountain' || l.type === 'river' || l.type === 'lake')
          .forEach((lm) => pool.push(buildLandmarkQuestion(lm)));
        break;
      case 'cat_seas_islands':
        filteredLandmarks
          .filter(
            (l) =>
              l.type === 'sea' ||
              l.type === 'ocean' ||
              l.type === 'island' ||
              l.type === 'strait'
          )
          .forEach((lm) => pool.push(buildLandmarkQuestion(lm)));
        break;
      case 'cat_map_locate':
        filteredCountries.forEach((c, idx) =>
          pool.push(buildCountryLocateQuestion(c, idx))
        );
        filteredLandmarks.forEach((lm) => pool.push(buildLandmarkQuestion(lm)));
        break;
      case 'cat_flags_regions':
        filteredCountries.forEach((c) => pool.push(buildFlagRegionQuestion(c)));
        break;
      case 'cat_wonders':
        filteredLandmarks
          .filter(
            (l) =>
              l.type === 'wonder' ||
              l.type === 'landmark' ||
              l.type === 'desert'
          )
          .forEach((lm) => pool.push(buildLandmarkQuestion(lm)));
        break;
      case 'cat_riddles':
        filteredCountries.forEach((c) => pool.push(buildRiddleQuestion(c)));
        break;
    }
  } else if (mode === 'country_hunt' || mode === 'continents') {
    filteredCountries.forEach((c, idx) => {
      pool.push(buildCountryLocateQuestion(c, idx));
    });
    if (mode === 'continents') {
      filteredCountries.forEach((c) => {
        pool.push(buildCapitalQuestion(c));
      });
      filteredLandmarks
        .filter((l) => l.continent === continent)
        .forEach((lm) => pool.push(buildLandmarkQuestion(lm)));
    }
  } else if (mode === 'capital_hunt') {
    const continentCities =
      continent === 'all'
        ? getAllWorldCities()
        : getAllWorldCities().filter((c) => c.continent === continent);
    continentCities.forEach((city) => pool.push(buildCityPointQuestion(city)));
  } else if (mode === 'landmark_hunt') {
    filteredLandmarks
      .filter((l) => l.type !== 'city')
      .forEach((lm) => pool.push(buildLandmarkQuestion(lm)));
  } else if (mode === 'neighbor_challenge') {
    filteredCountries.forEach((c) => {
      const nb = buildNeighborBorderQuestion(c);
      if (nb) pool.push(nb);
      const bw = buildBetweenQuestion(c);
      if (bw) pool.push(bw);
      if (c.northNeighbor && COUNTRY_BY_ID[c.northNeighbor]) {
        pool.push(buildDirectionalCountryQuestion(c, COUNTRY_BY_ID[c.northNeighbor], 'north'));
      }
      if (c.southNeighbor && COUNTRY_BY_ID[c.southNeighbor]) {
        pool.push(buildDirectionalCountryQuestion(c, COUNTRY_BY_ID[c.southNeighbor], 'south'));
      }
    });
  } else {
    // quick_play, world_challenge, time_attack, endless => balanced rich mix across all 10 categories
    filteredCountries.forEach((c, idx) => {
      pool.push(buildCountryLocateQuestion(c, idx));
      if (idx % 2 === 0) {
        pool.push(buildCapitalQuestion(c));
      }
      if (idx % 3 === 0) {
        pool.push(buildFlagRegionQuestion(c));
      }
      if (idx % 4 === 0) {
        const nb = buildNeighborBorderQuestion(c);
        if (nb) pool.push(nb);
      }
      if (idx % 5 === 0) {
        pool.push(buildRiddleQuestion(c));
      }
      if (c.betweenPair && idx % 3 === 0) {
        const bw = buildBetweenQuestion(c);
        if (bw) pool.push(bw);
      }
      if (c.northNeighbor && COUNTRY_BY_ID[c.northNeighbor] && idx % 5 === 0) {
        pool.push(buildDirectionalCountryQuestion(c, COUNTRY_BY_ID[c.northNeighbor], 'north'));
      }
    });
    filteredLandmarks.forEach((lm) => {
      pool.push(buildLandmarkQuestion(lm));
    });
  }

  // Apply difficulty filter (fallback to full pool if too narrow for a small continent or category)
  const diffFiltered = pool.filter((q) => matchesDifficulty(q.difficulty, difficulty));
  const finalCandidates = diffFiltered.length >= Math.min(5, count) ? diffFiltered : pool;

  const shuffled = shuffle(finalCandidates);

  const unique: GeoQuestion[] = [];
  const seenKeys = new Set<string>();
  for (const q of shuffled) {
    const key = `${q.type}-${q.targetLocationName.en}`;
    if (!seenKeys.has(key)) {
      seenKeys.add(key);
      unique.push(q);
    }
  }

  if (unique.length >= count) {
    return unique.slice(0, count);
  }

  const result = [...unique];
  let i = 0;
  while (result.length < count && shuffled.length > 0) {
    const next = shuffled[i % shuffled.length];
    result.push({ ...next, id: `${next.id}-loop-${i}` });
    i++;
  }
  return result;
}

export function getAllCityPoints(): CityPoint[] {
  return getAllWorldCities();
}
