import {
  CityPoint,
  ContinentId,
  CountryMeta,
  DifficultySetting,
  GameMode,
  GameSpeed,
  Language,
  LocalizedText,
  QuestionType,
} from '../types/game';
import { COUNTRY_BY_ID } from './countriesData';
import { TURKISH_CITY_EXONYMS, TURKISH_COUNTRY_NAMES } from './turkishNames';

export const UI_TEXT = {
  appName: { ar: 'GeoQuest', en: 'GeoQuest', tr: 'GeoQuest' },
  appSubtitle: {
    ar: 'استكشف العالم',
    en: 'Explore the World',
    tr: 'Dünyayı Keşfet',
  },
  heroLead: {
    ar: 'ابحث عن الدول والعواصم والمعالم الجغرافية مباشرة على خريطة عالم حقيقية تفاعلية.',
    en: 'Discover nations, capitals, borders, and natural wonders directly on a live interactive world map.',
    tr: 'Ülkeleri, başkentleri, sınırları ve doğa harikalarını etkileşimli gerçek dünya haritasında keşfedin.',
  },
  startAdventure: {
    ar: 'ابدأ المغامرة',
    en: 'Start Adventure',
    tr: 'Maceraya Başla',
  },
  quickPlay: { ar: 'لعب سريع', en: 'Quick Play', tr: 'Hızlı Oyun' },
  worldMap: { ar: 'خريطة العالم', en: 'World Map', tr: 'Dünya Haritası' },
  challenges: { ar: 'التحديات', en: 'Challenges', tr: 'Meydan Okumalar' },
  statistics: { ar: 'الإحصائيات', en: 'Statistics', tr: 'İstatistikler' },
  settings: { ar: 'الإعدادات', en: 'Settings', tr: 'Ayarlar' },
  playerLevel: { ar: 'المستوى', en: 'Level', tr: 'Seviye' },
  bestScore: { ar: 'أفضل نتيجة', en: 'Best Score', tr: 'En Yüksek Puan' },
  latestAchievement: {
    ar: 'آخر إنجاز',
    en: 'Latest Achievement',
    tr: 'Son Başarım',
  },
  noAchievementsYet: {
    ar: 'لم يُفتح أي إنجاز بعد',
    en: 'No achievements unlocked yet',
    tr: 'Henüz başarım kazanılmadı',
  },
  controlHint: {
    ar: 'اسحب لتحريك الخريطة · مرّر العجلة للتكبير · اضغط لتحديد الموقع',
    en: 'Drag to pan · Scroll to zoom · Click map to select location',
    tr: 'Kaydırmak için sürükleyin · Yakınlaştırmak için kaydırın · Seçmek için tıklayın',
  },
  score: { ar: 'النقاط', en: 'Score', tr: 'Puan' },
  time: { ar: 'الوقت', en: 'Time', tr: 'Süre' },
  streak: { ar: 'السلسلة', en: 'Streak', tr: 'Seri' },
  attempts: { ar: 'المحاولات', en: 'Attempts', tr: 'Hak' },
  lives: { ar: 'الأرواح', en: 'Lives', tr: 'Can' },
  hint: { ar: 'تلميح', en: 'Hint', tr: 'İpucu' },
  skip: { ar: 'تخطي', en: 'Skip', tr: 'Atla' },
  nextQuestion: {
    ar: 'السؤال التالي',
    en: 'Next Question',
    tr: 'Sonraki Soru',
  },
  finishRun: {
    ar: 'عرض النتائج',
    en: 'View Results',
    tr: 'Sonuçları Gör',
  },
  pause: { ar: 'إيقاف مؤقت', en: 'Pause', tr: 'Duraklat' },
  resume: { ar: 'متابعة', en: 'Resume', tr: 'Devam Et' },
  backHome: { ar: 'القائمة الرئيسية', en: 'Main Menu', tr: 'Ana Menü' },
  playAgain: { ar: 'العب مجدداً', en: 'Play Again', tr: 'Tekrar Oyna' },
  roundInfo: { ar: 'معلومات الجولة', en: 'Round Info', tr: 'Tur Bilgisi' },
  hintsUsedLabel: {
    ar: 'التلميحات المستخدمة',
    en: 'Hints Revealed',
    tr: 'Kullanılan İpuçları',
  },
  hintCostNote: {
    ar: 'خصم -25 نقطة لكل تلميح',
    en: '-25 pts per hint',
    tr: 'İpucu başına -25 puan',
  },
  allHintsUsed: {
    ar: 'تم كشف جميع التلميحات',
    en: 'All hints revealed',
    tr: 'Tüm ipuçları açıldı',
  },
  correctFeedback: {
    ar: 'إجابة صحيحة! أحسنت يا مستكشف.',
    en: 'Correct! Spot-on discovery.',
    tr: 'Doğru! Harika bir keşif.',
  },
  wrongFeedback: {
    ar: 'موقع غير دقيق، واصل البحث!',
    en: 'Not quite there — keep exploring!',
    tr: 'Tam isabet değil — keşfetmeye devam et!',
  },
  outOfAttempts: {
    ar: 'انتهت المحاولات — تم كشف الموقع الصحيح.',
    en: 'Out of attempts — target location revealed.',
    tr: 'Haklar bitti — doğru konum gösterildi.',
  },
  timeUpFeedback: {
    ar: 'انتهى الوقت! تم عرض الموقع الصحيح.',
    en: 'Time is up! Target location revealed.',
    tr: 'Süre doldu! Doğru konum gösterildi.',
  },
  skippedFeedback: {
    ar: 'تم تخطي السؤال — هذا هو الموقع الصحيح.',
    en: 'Question skipped — here is the correct location.',
    tr: 'Soru atlandı — doğru konum burası.',
  },
  distanceAway: {
    ar: 'المسافة عن الهدف:',
    en: 'Distance from target:',
    tr: 'Hedefe uzaklık:',
  },
  towards: { ar: 'اتجه نحو', en: 'Head', tr: 'Yön:' },
  km: { ar: 'كم', en: 'km', tr: 'km' },
  clickToExplore: {
    ar: 'اضغط على الخريطة لتحديد الإجابة',
    en: 'Click on the map to place your answer',
    tr: 'Cevabı işaretlemek için haritaya tıklayın',
  },
  zoomIn: { ar: 'تكبير', en: 'Zoom In', tr: 'Yakınlaştır' },
  zoomOut: { ar: 'تصغير', en: 'Zoom Out', tr: 'Uzaklaştır' },
  resetMap: {
    ar: 'إعادة ضبط العرض',
    en: 'Reset View',
    tr: 'Görünümü Sıfırla',
  },
  close: { ar: 'إغلاق', en: 'Close', tr: 'Kapat' },
  save: { ar: 'حفظ', en: 'Save', tr: 'Kaydet' },
  atlasTitle: {
    ar: 'أطلس العالم التفاعلي',
    en: 'Interactive World Atlas',
    tr: 'Etkileşimli Dünya Atlası',
  },
  atlasSubtitle: {
    ar: 'حرّك المؤشر فوق أي دولة لمعرفة اسمها، واضغط عليها لاستعراض عاصمتها وحدودها.',
    en: 'Hover over any country to inspect its name, and click to view its capital, coordinates, and borders.',
    tr: 'Adını görmek için herhangi bir ülkenin üzerine gelin; başkentini, koordinatlarını ve sınırlarını görmek için tıklayın.',
  },
  capitalLabel: { ar: 'العاصمة', en: 'Capital', tr: 'Başkent' },
  continentLabel: { ar: 'القارة', en: 'Continent', tr: 'Kıta' },
  coordsLabel: { ar: 'الإحداثيات', en: 'Coordinates', tr: 'Koordinatlar' },
  neighborsLabel: {
    ar: 'الدول المجاورة',
    en: 'Bordering Countries',
    tr: 'Komşu Ülkeler',
  },
  islandNoBorders: {
    ar: 'دولة جزرية بلا حدود برية',
    en: 'Island nation with no land borders',
    tr: 'Kara sınırı olmayan ada ülkesi',
  },
  resultsTitle: {
    ar: 'ملخص الرحلة الاستكشافية',
    en: 'Expedition Summary',
    tr: 'Keşif Özeti',
  },
  accuracy: { ar: 'الدقة', en: 'Accuracy', tr: 'İsabet' },
  xpEarned: { ar: 'الخبرة المكتسبة', en: 'XP Earned', tr: 'Kazanılan XP' },
  bestStreak: { ar: 'أفضل سلسلة', en: 'Best Streak', tr: 'En İyi Seri' },
  questionReview: {
    ar: 'مراجعة الأسئلة',
    en: 'Question Review',
    tr: 'Soru İncelemesi',
  },
  achievementsUnlocked: {
    ar: 'إنجازات مفتوحة حديثاً',
    en: 'Newly Unlocked Achievements',
    tr: 'Yeni Açılan Başarımlar',
  },
  selectMode: {
    ar: 'اختر وضع اللعب',
    en: 'Choose Game Mode',
    tr: 'Oyun Modunu Seç',
  },
  selectContinent: {
    ar: 'اختر القارة',
    en: 'Select Continent',
    tr: 'Kıta Seç',
  },
  selectDifficulty: {
    ar: 'مستوى الصعوبة',
    en: 'Difficulty Level',
    tr: 'Zorluk Seviyesi',
  },
  launchChallenge: {
    ar: 'بدء التحدي',
    en: 'Launch Challenge',
    tr: 'Meydan Okumayı Başlat',
  },
  gamesPlayed: {
    ar: 'الجولات المكتملة',
    en: 'Games Played',
    tr: 'Tamamlanan Turlar',
  },
  totalCorrect: {
    ar: 'الإجابات الصحيحة',
    en: 'Correct Answers',
    tr: 'Doğru Cevaplar',
  },
  achievementsTitle: { ar: 'الإنجازات', en: 'Achievements', tr: 'Başarımlar' },
  recentRuns: {
    ar: 'أحدث الجولات',
    en: 'Recent Expeditions',
    tr: 'Son Keşifler',
  },
  resetStats: {
    ar: 'تصفير التقدم',
    en: 'Reset Progress',
    tr: 'İlerlemeyi Sıfırla',
  },
  languageSetting: { ar: 'اللغة', en: 'Language', tr: 'Dil' },
  soundSetting: {
    ar: 'المؤثرات الصوتية',
    en: 'Sound Effects',
    tr: 'Ses Efektleri',
  },
  volumeSetting: { ar: 'مستوى الصوت', en: 'Volume', tr: 'Ses Düzeyi' },
  themeSetting: { ar: 'المظهر الداكن', en: 'Dark Mode', tr: 'Karanlık Mod' },
  speedSetting: { ar: 'سرعة اللعب', en: 'Game Speed', tr: 'Oyun Hızı' },
  questionCountSetting: {
    ar: 'عدد الأسئلة (للعب المخصص)',
    en: 'Question Count',
    tr: 'Soru Sayısı',
  },
  difficultySetting: {
    ar: 'مستوى الصعوبة الافتراضي',
    en: 'Default Difficulty',
    tr: 'Varsayılan Zorluk',
  },
  basePoints: { ar: 'النقاط الأساسية', en: 'Base Points', tr: 'Temel Puan' },
  speedBonus: { ar: 'مكافأة السرعة', en: 'Speed Bonus', tr: 'Hız Bonusu' },
  streakBonus: { ar: 'مكافأة السلسلة', en: 'Streak Bonus', tr: 'Seri Bonusu' },
  hintPenalty: { ar: 'خصم التلميحات', en: 'Hint Penalty', tr: 'İpucu Kesintisi' },
  youtubeChannel: {
    ar: 'قناة اليوتيوب',
    en: 'YouTube Channel',
    tr: 'YouTube Kanalı',
  },
  visitYoutubeChannel: {
    ar: 'قم بزيارة قناتنا على اليوتيوب',
    en: 'Visit our YouTube Channel',
    tr: 'YouTube Kanalımızı Ziyaret Edin',
  },
  youtubeUrlSetting: {
    ar: 'رابط قناة اليوتيوب',
    en: 'YouTube Channel URL',
    tr: 'YouTube Kanal Bağlantısı',
  },
  citiesMap: { ar: 'خريطة المدن', en: 'Cities Map', tr: 'Şehir Haritası' },
  countriesLayer: { ar: 'خريطة الدول', en: 'Countries', tr: 'Ülkeler' },
  citiesLayer: { ar: 'المدن فقط', en: 'Cities Only', tr: 'Sadece Şehirler' },
  bothLayers: {
    ar: 'الدول والمدن',
    en: 'Countries & Cities',
    tr: 'Ülkeler ve Şehirler',
  },
  capitalBadge: { ar: 'عاصمة', en: 'Capital', tr: 'Başkent' },
  majorCityBadge: {
    ar: 'مدينة كبرى',
    en: 'Major City',
    tr: 'Büyük Şehir',
  },
  millionBankTitle: {
    ar: 'تصنيف المليون سؤال (10 أقسام)',
    en: 'Million-Question Categories',
    tr: '1 Milyon Soruluk Kategoriler',
  },
  gameModesTab: { ar: 'أوضاع اللعب', en: 'Game Modes', tr: 'Oyun Modları' },
  totalQuestionsQuota: {
    ar: 'الإجمالي: 1,000,000 سؤال',
    en: 'Total: 1,000,000 Questions',
    tr: 'Toplam: 1.000.000 Soru',
  },
  areaLabel: { ar: 'المساحة', en: 'Area', tr: 'Yüzölçümü' },
  km2Unit: { ar: 'كم²', en: 'km²', tr: 'km²' },
  cityCountLabel: { ar: 'عدد المدن', en: 'Cities Count', tr: 'Şehir Sayısı' },
  countryCitiesLabel: { ar: 'أسماء المدن', en: 'Cities', tr: 'Şehirler' },
  backToCountry: {
    ar: 'العودة للدولة',
    en: 'Back to Country',
    tr: 'Ülkeye Dön',
  },
  sphericalEarth: {
    ar: 'الأرض الكروية',
    en: 'Spherical Earth',
    tr: 'Küre Dünya',
  },
  flatMap: { ar: 'خريطة مسطحة', en: 'Flat Map', tr: 'Düz Harita' },
  cityBoundaries: {
    ar: 'حدود المدن',
    en: 'City Borders',
    tr: 'Şehir Sınırları',
  },
  loadingBoundaries: {
    ar: 'جاري تحميل الحدود...',
    en: 'Loading borders...',
    tr: 'Sınırlar yükleniyor...',
  },
  countryNames: {
    ar: 'أسماء الدول',
    en: 'Country Names',
    tr: 'Ülke Adları',
  },
};

export const CONTINENT_LABELS: Record<ContinentId, LocalizedText> = {
  all: { ar: 'كل العالم', en: 'All World', tr: 'Tüm Dünya' },
  asia: { ar: 'آسيا', en: 'Asia', tr: 'Asya' },
  africa: { ar: 'أفريقيا', en: 'Africa', tr: 'Afrika' },
  europe: { ar: 'أوروبا', en: 'Europe', tr: 'Avrupa' },
  north_america: {
    ar: 'أمريكا الشمالية',
    en: 'North America',
    tr: 'Kuzey Amerika',
  },
  south_america: {
    ar: 'أمريكا الجنوبية',
    en: 'South America',
    tr: 'Güney Amerika',
  },
  oceania: { ar: 'أوقيانوسيا', en: 'Oceania', tr: 'Okyanusya' },
};

export const DIFFICULTY_LABELS: Record<DifficultySetting, LocalizedText> = {
  easy: { ar: 'سهل', en: 'Easy', tr: 'Kolay' },
  medium: { ar: 'متوسط', en: 'Medium', tr: 'Orta' },
  hard: { ar: 'صعب', en: 'Hard', tr: 'Zor' },
  mixed: { ar: 'متنوع', en: 'Mixed', tr: 'Karışık' },
};

export const SPEED_LABELS: Record<GameSpeed, LocalizedText> = {
  relaxed: { ar: 'هادئ (45 ثانية)', en: 'Relaxed (45s)', tr: 'Rahat (45 sn)' },
  normal: { ar: 'عادي (30 ثانية)', en: 'Normal (30s)', tr: 'Normal (30 sn)' },
  fast: { ar: 'سريع (18 ثانية)', en: 'Fast (18s)', tr: 'Hızlı (18 sn)' },
};

export const MODE_INFO: Record<
  GameMode,
  { title: LocalizedText; desc: LocalizedText; badge: LocalizedText }
> = {
  quick_play: {
    title: { ar: 'Quick Play — لعب سريع', en: 'Quick Play', tr: 'Hızlı Oyun' },
    desc: {
      ar: 'جولة متوازنة من 10 أسئلة متنوعة عبر قارات العالم.',
      en: 'A brisk 10-question expedition across countries, capitals, and landmarks.',
      tr: 'Ülkeler, başkentler ve simgelerle 10 soruluk dengeli bir dünya turu.',
    },
    badge: { ar: '10 أسئلة', en: '10 Questions', tr: '10 Soru' },
  },
  world_challenge: {
    title: {
      ar: 'World Challenge — تحدي العالم',
      en: 'World Challenge',
      tr: 'Dünya Meydan Okuması',
    },
    desc: {
      ar: 'اختبار شامل من 50 سؤالاً لاكتشاف كل ركن على الخريطة.',
      en: 'The grand 50-question global gauntlet testing complete world mastery.',
      tr: 'Haritanın her köşesini test eden 50 soruluk kapsamlı küresel sınav.',
    },
    badge: { ar: '50 سؤالاً', en: '50 Questions', tr: '50 Soru' },
  },
  country_hunt: {
    title: {
      ar: 'Country Hunt — صيد الدول',
      en: 'Country Hunt',
      tr: 'Ülke Avı',
    },
    desc: {
      ar: 'يظهر اسم الدولة وعليك تحديد موقعها وحدودها على الخريطة.',
      en: 'Spot countries directly by their borders and geography.',
      tr: 'Ülkeleri sınırlarına ve coğrafyasına göre haritada doğrudan bulun.',
    },
    badge: { ar: 'دول العالم', en: 'Countries', tr: 'Ülkeler' },
  },
  capital_hunt: {
    title: {
      ar: 'Capital Hunt — تحدي العواصم والمدن',
      en: 'Capitals & Cities',
      tr: 'Başkentler ve Şehirler',
    },
    desc: {
      ar: 'ابحث عن عواصم العالم والمدن الكبرى بدقة جغرافية عالية.',
      en: 'Pinpoint world capitals and major cities by exact coordinates.',
      tr: 'Dünya başkentlerini ve büyük şehirleri harita üzerinde tam olarak işaretleyin.',
    },
    badge: { ar: 'عواصم ومدن', en: 'Capitals & Cities', tr: 'Başkent & Şehir' },
  },
  landmark_hunt: {
    title: {
      ar: 'Landmark Hunt — تحدي المعالم',
      en: 'Landmark Hunt',
      tr: 'Anıt ve Doğa Harikaları',
    },
    desc: {
      ar: 'أين تقع أشهر المعالم التاريخية والطبيعية حول العالم؟',
      en: 'Locate iconic world landmarks, monuments, and natural wonders.',
      tr: 'Dünyaca ünlü tarihi yapıları, anıtları ve doğa harikalarını bulun.',
    },
    badge: { ar: 'معالم العالم', en: 'Landmarks', tr: 'Anıtlar' },
  },
  neighbor_challenge: {
    title: {
      ar: 'Neighbor Challenge — تحدي الحدود',
      en: 'Neighbor Challenge',
      tr: 'Sınır ve Komşular',
    },
    desc: {
      ar: 'اكتشف الدول المجاورة والدول الواقعة بين بلدين أو شمال وجنوب.',
      en: 'Identify bordering nations, sandwiched states, and cardinal neighbors.',
      tr: 'Komşu ülkeleri, iki ülke arasında kalan devletleri ve yön komşularını bulun.',
    },
    badge: { ar: 'الحدود والجوار', en: 'Borders', tr: 'Sınırlar' },
  },
  continents: {
    title: {
      ar: 'Continents — تحدي القارات',
      en: 'Continents Focus',
      tr: 'Kıta Odaklı',
    },
    desc: {
      ar: 'ركّز الخريطة والأسئلة على قارة واحدة تختارها بنفسك.',
      en: 'Zoom in and master a single continent of your choice.',
      tr: 'Seçtiğiniz tek bir kıtaya yakınlaşın ve o kıtada uzmanlaşın.',
    },
    badge: { ar: 'حسب القارة', en: 'Regional', tr: 'Bölgesel' },
  },
  time_attack: {
    title: {
      ar: 'Time Attack — سباق الزمن',
      en: 'Time Attack',
      tr: 'Zamana Karşı',
    },
    desc: {
      ar: 'أجب عن أكبر عدد ممكن من الأسئلة خلال 90 ثانية متواصلة!',
      en: 'Solve as many locations as possible before the 90-second clock expires.',
      tr: '90 saniye dolmadan mümkün olduğunca çok konumu doğru bulun!',
    },
    badge: { ar: '90 ثانية', en: '90s Blitz', tr: '90 sn' },
  },
  endless: {
    title: {
      ar: 'Endless Mode — الوضع اللانهائي',
      en: 'Endless Mode',
      tr: 'Sonsuz Mod',
    },
    desc: {
      ar: 'أسئلة لا تنتهي مع 3 أرواح فقط — إلى أي مدى ستصل؟',
      en: 'Continuous expedition with 3 lives — survive as long as you can.',
      tr: 'Sadece 3 can ile kesintisiz keşif — ne kadar ilerleyebilirsiniz?',
    },
    badge: { ar: '3 أرواح', en: '3 Lives', tr: '3 Can' },
  },
};

export const QUESTION_TYPE_LABELS: Record<QuestionType, LocalizedText> = {
  country_locate: { ar: 'تحديد دولة', en: 'Country', tr: 'Ülke Bulma' },
  country_north_of: { ar: 'اتجاه شمالي', en: 'North Border', tr: 'Kuzey Sınırı' },
  country_south_of: { ar: 'اتجاه جنوبي', en: 'South Border', tr: 'Güney Sınırı' },
  capital_locate: { ar: 'عاصمة', en: 'Capital', tr: 'Başkent' },
  city_locate: { ar: 'مدينة عالمية', en: 'City', tr: 'Şehir' },
  landmark: { ar: 'معلم شهير', en: 'Landmark', tr: 'Simge Yapı' },
  wonder: { ar: 'عجيبة عالمية', en: 'World Wonder', tr: 'Dünya Harikası' },
  flag_region: { ar: 'أعلام ومناطق', en: 'Flags & Regions', tr: 'Bayrak ve Bölge' },
  riddle: { ar: 'لغز جغرافي', en: 'Geo Riddle', tr: 'Coğrafi Bilmece' },
  neighbor_border: { ar: 'حدود مشتركة', en: 'Neighbor', tr: 'Komşu Ülke' },
  neighbor_between: { ar: 'بين دولتين', en: 'Between Nations', tr: 'İki Ülke Arası' },
  sea: { ar: 'بحر', en: 'Sea', tr: 'Deniz' },
  ocean: { ar: 'محيط', en: 'Ocean', tr: 'Okyanus' },
  island: { ar: 'جزيرة', en: 'Island', tr: 'Ada' },
  river: { ar: 'نهر', en: 'River', tr: 'Nehir' },
  lake: { ar: 'بحيرة', en: 'Lake', tr: 'Göl' },
  mountain: { ar: 'جبال', en: 'Mountains', tr: 'Dağlar' },
  desert: { ar: 'صحراء', en: 'Desert', tr: 'Çöl' },
  strait: { ar: 'مضيق', en: 'Strait', tr: 'Boğaz' },
};

export function t(text: LocalizedText, lang: Language): string {
  return text[lang] ?? text.en;
}

export function locCountryName(country: CountryMeta, lang: Language): string {
  if (lang === 'tr') {
    return TURKISH_COUNTRY_NAMES[country.id]?.name ?? country.name.tr ?? country.name.en;
  }
  return country.name[lang] ?? country.name.en;
}

export function locCountryCapital(country: CountryMeta, lang: Language): string {
  if (lang === 'tr') {
    return (
      TURKISH_COUNTRY_NAMES[country.id]?.capital ??
      country.capital.tr ??
      country.capital.en
    );
  }
  return country.capital[lang] ?? country.capital.en;
}

export function locCityName(city: CityPoint, lang: Language): string {
  if (lang === 'tr') {
    return city.name.tr ?? TURKISH_CITY_EXONYMS[city.name.en] ?? city.name.en;
  }
  return city.name[lang] ?? city.name.en;
}

export function locCityCountryName(city: CityPoint, lang: Language): string {
  if (lang === 'tr' && city.countryId && TURKISH_COUNTRY_NAMES[city.countryId]) {
    return TURKISH_COUNTRY_NAMES[city.countryId].name;
  }
  return city.countryName[lang] ?? city.countryName.en;
}

const EXTRA_MAP_COUNTRY_NAMES: Record<string, { ar: string; tr: string; en?: string }> = {
  '008': { ar: 'ألبانيا', tr: 'Arnavutluk', en: 'Albania' },
  '020': { ar: 'أندورا', tr: 'Andorra', en: 'Andorra' },
  '028': { ar: 'أنتيغوا وبربودا', tr: 'Antigua ve Barbuda', en: 'Antigua & Barbuda' },
  '031': { ar: 'أذربيجان', tr: 'Azerbaycan', en: 'Azerbaijan' },
  '044': { ar: 'باهاماس', tr: 'Bahamalar', en: 'Bahamas' },
  '051': { ar: 'أرمينيا', tr: 'Ermenistan', en: 'Armenia' },
  '052': { ar: 'بربادوس', tr: 'Barbados', en: 'Barbados' },
  '064': { ar: 'بوتان', tr: 'Butan', en: 'Bhutan' },
  '070': { ar: 'البوسنة والهرسك', tr: 'Bosna-Hersek', en: 'Bosnia & Herz.' },
  '084': { ar: 'بليز', tr: 'Belize', en: 'Belize' },
  '090': { ar: 'جزر سليمان', tr: 'Solomon Adaları', en: 'Solomon Is.' },
  '096': { ar: 'بروناي', tr: 'Brunei', en: 'Brunei' },
  '108': { ar: 'بوروندي', tr: 'Burundi', en: 'Burundi' },
  '112': { ar: 'بيلاروسيا', tr: 'Belarus', en: 'Belarus' },
  '116': { ar: 'كمبوديا', tr: 'Kamboçya', en: 'Cambodia' },
  '120': { ar: 'الكاميرون', tr: 'Kamerun', en: 'Cameroon' },
  '132': { ar: 'الرأس الأخضر', tr: 'Yeşil Burun Adaları', en: 'Cabo Verde' },
  '140': { ar: 'أفريقيا الوسطى', tr: 'Orta Afrika Cum.', en: 'Central African Rep.' },
  '158': { ar: 'تايوان', tr: 'Tayvan', en: 'Taiwan' },
  '174': { ar: 'جزر القمر', tr: 'Komorlar', en: 'Comoros' },
  '178': { ar: 'الكونغو', tr: 'Kongo', en: 'Congo' },
  '191': { ar: 'كرواتيا', tr: 'Hırvatistan', en: 'Croatia' },
  '204': { ar: 'بنين', tr: 'Benin', en: 'Benin' },
  '212': { ar: 'دومينيكا', tr: 'Dominika', en: 'Dominica' },
  '222': { ar: 'السلفادور', tr: 'El Salvador', en: 'El Salvador' },
  '226': { ar: 'غينيا الاستوائية', tr: 'Ekvator Ginesi', en: 'Eq. Guinea' },
  '232': { ar: 'إريتريا', tr: 'Eritre', en: 'Eritrea' },
  '233': { ar: 'إستونيا', tr: 'Estonya', en: 'Estonia' },
  '238': { ar: 'جزر فوكلاند', tr: 'Falkland Adaları', en: 'Falkland Is.' },
  '262': { ar: 'جيبوتي', tr: 'Cibuti', en: 'Djibouti' },
  '266': { ar: 'الغابون', tr: 'Gabon', en: 'Gabon' },
  '268': { ar: 'جورجيا', tr: 'Gürcistan', en: 'Georgia' },
  '270': { ar: 'غامبيا', tr: 'Gambiya', en: 'Gambia' },
  '296': { ar: 'كيريباتي', tr: 'Kiribati', en: 'Kiribati' },
  '308': { ar: 'غرينادا', tr: 'Grenada', en: 'Grenada' },
  '324': { ar: 'غينيا', tr: 'Gine', en: 'Guinea' },
  '328': { ar: 'غيانا', tr: 'Guyana', en: 'Guyana' },
  '336': { ar: 'الفاتيكان', tr: 'Vatikan', en: 'Vatican' },
  '340': { ar: 'هندوراس', tr: 'Honduras', en: 'Honduras' },
  '344': { ar: 'هونغ كونغ', tr: 'Hong Kong', en: 'Hong Kong' },
  '384': { ar: 'ساحل العاج', tr: 'Fildişi Sahili', en: "Côte d'Ivoire" },
  '417': { ar: 'قيرغيزستان', tr: 'Kırgızistan', en: 'Kyrgyzstan' },
  '418': { ar: 'لاوس', tr: 'Laos', en: 'Laos' },
  '426': { ar: 'ليسوتو', tr: 'Lesotho', en: 'Lesotho' },
  '428': { ar: 'لاتفيا', tr: 'Letonya', en: 'Latvia' },
  '430': { ar: 'ليبيريا', tr: 'Liberya', en: 'Liberia' },
  '438': { ar: 'ليختنشتاين', tr: 'Lihtenştayn', en: 'Liechtenstein' },
  '440': { ar: 'ليتوانيا', tr: 'Litvanya', en: 'Lithuania' },
  '454': { ar: 'مالاوي', tr: 'Malavi', en: 'Malawi' },
  '478': { ar: 'موريتانيا', tr: 'Moritanya', en: 'Mauritania' },
  '480': { ar: 'موريشيوس', tr: 'Mauritius', en: 'Mauritius' },
  '492': { ar: 'موناكو', tr: 'Monako', en: 'Monaco' },
  '498': { ar: 'مولدوفا', tr: 'Moldova', en: 'Moldova' },
  '499': { ar: 'الجبل الأسود', tr: 'Karadağ', en: 'Montenegro' },
  '548': { ar: 'فانواتو', tr: 'Vanuatu', en: 'Vanuatu' },
  '558': { ar: 'نيكاراغوا', tr: 'Nikaragua', en: 'Nicaragua' },
  '624': { ar: 'غينيا بيساو', tr: 'Gine-Bissau', en: 'Guinea-Bissau' },
  '626': { ar: 'تيمور الشرقية', tr: 'Doğu Timor', en: 'Timor-Leste' },
  '630': { ar: 'بورتوريكو', tr: 'Porto Riko', en: 'Puerto Rico' },
  '646': { ar: 'رواندا', tr: 'Ruanda', en: 'Rwanda' },
  '674': { ar: 'سان مارينو', tr: 'San Marino', en: 'San Marino' },
  '678': { ar: 'ساو تومي وبرينسيب', tr: 'São Tomé ve Príncipe', en: 'São Tomé & Príncipe' },
  '688': { ar: 'صربيا', tr: 'Sırbistan', en: 'Serbia' },
  '690': { ar: 'سيشل', tr: 'Seyşeller', en: 'Seychelles' },
  '694': { ar: 'سيراليون', tr: 'Sierra Leone', en: 'Sierra Leone' },
  '703': { ar: 'سلوفاكيا', tr: 'Slovakya', en: 'Slovakia' },
  '705': { ar: 'سلوفينيا', tr: 'Slovenya', en: 'Slovenia' },
  '732': { ar: 'الصحراء الغربية', tr: 'Batı Sahra', en: 'W. Sahara' },
  '740': { ar: 'سورينام', tr: 'Surinam', en: 'Suriname' },
  '748': { ar: 'إسواتيني', tr: 'Esvatini', en: 'eSwatini' },
  '762': { ar: 'طاجيكستان', tr: 'Tacikistan', en: 'Tajikistan' },
  '768': { ar: 'توغو', tr: 'Togo', en: 'Togo' },
  '776': { ar: 'تونغا', tr: 'Tonga', en: 'Tonga' },
  '780': { ar: 'ترينيداد وتوباغو', tr: 'Trinidad ve Tobago', en: 'Trinidad & Tobago' },
  '795': { ar: 'تركمانستان', tr: 'Türkmenistan', en: 'Turkmenistan' },
  '800': { ar: 'أوغندا', tr: 'Uganda', en: 'Uganda' },
  '807': { ar: 'مقدونيا الشمالية', tr: 'Kuzey Makedonya', en: 'N. Macedonia' },
  '854': { ar: 'بوركينا فاسو', tr: 'Burkina Faso', en: 'Burkina Faso' },
  '882': { ar: 'ساموا', tr: 'Samoa', en: 'Samoa' },
  '894': { ar: 'زامبيا', tr: 'Zambiya', en: 'Zambia' },
  '716': { ar: 'زيمبابوي', tr: 'Zimbabve', en: 'Zimbabwe' },
  XKX: { ar: 'كوسوفو', tr: 'Kosova', en: 'Kosovo' },
  NCY: { ar: 'قبرص الشمالية', tr: 'Kuzey Kıbrıs', en: 'N. Cyprus' },
  SML: { ar: 'صوماليلاند', tr: 'Somaliland', en: 'Somaliland' },
};

export function locMapCountryName(
  countryId: string,
  rawName: string,
  lang: Language
): string {
  const meta = COUNTRY_BY_ID[countryId];
  if (meta) {
    return locCountryName(meta, lang);
  }
  const extra = EXTRA_MAP_COUNTRY_NAMES[countryId];
  if (extra) {
    if (lang === 'ar') return extra.ar;
    if (lang === 'tr') return extra.tr;
    return extra.en ?? rawName;
  }
  return rawName;
}
