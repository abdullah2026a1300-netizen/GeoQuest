class SoundEngine {
  private ctx: AudioContext | null = null;
  private enabled = true;
  private volume = 0.6;

  private getContext(): AudioContext | null {
    if (!this.enabled || typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public configure(enabled: boolean, volume: number): void {
    this.enabled = enabled;
    this.volume = Math.max(0, Math.min(1, volume));
  }

  private playTone(
    freq: number,
    duration: number,
    type: OscillatorType = 'sine',
    delay = 0,
    gainScale = 0.25
  ): void {
    const ctx = this.getContext();
    if (!ctx || this.volume <= 0) return;

    const now = ctx.currentTime + delay;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = type;
    osc.frequency.setValueAtTime(freq, now);

    const peak = Math.max(0.001, this.volume * gainScale);
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(peak, now + 0.015);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + duration);

    osc.connect(gain);
    gain.connect(ctx.destination);

    osc.start(now);
    osc.stop(now + duration + 0.02);
  }

  public playClick(): void {
    this.playTone(540, 0.055, 'triangle', 0, 0.12);
  }

  public playCorrect(): void {
    this.playTone(523.25, 0.14, 'sine', 0, 0.24); // C5
    this.playTone(659.25, 0.14, 'sine', 0.07, 0.24); // E5
    this.playTone(783.99, 0.24, 'triangle', 0.14, 0.26); // G5
  }

  public playWrong(): void {
    this.playTone(210, 0.15, 'sawtooth', 0, 0.14);
    this.playTone(165, 0.22, 'triangle', 0.09, 0.18);
  }

  public playHint(): void {
    this.playTone(698.46, 0.11, 'sine', 0, 0.18); // F5
    this.playTone(880, 0.18, 'sine', 0.08, 0.16); // A5
  }

  public playTimeUp(): void {
    this.playTone(392, 0.16, 'triangle', 0, 0.2);
    this.playTone(349.23, 0.16, 'triangle', 0.14, 0.2);
    this.playTone(293.66, 0.28, 'triangle', 0.28, 0.2);
  }

  public playVictory(): void {
    const notes = [523.25, 659.25, 783.99, 1046.5];
    notes.forEach((n, idx) => {
      this.playTone(n, idx === 3 ? 0.45 : 0.16, 'triangle', idx * 0.09, 0.24);
    });
  }
}

export const soundEngine = new SoundEngine();
