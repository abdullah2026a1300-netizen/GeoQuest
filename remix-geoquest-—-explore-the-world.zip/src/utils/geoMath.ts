import { ContinentId, Language } from '../types/game';

const EARTH_RADIUS_KM = 6371;

export function toRad(deg: number): number {
  return (deg * Math.PI) / 180;
}

export function haversineDistanceKm(
  [lon1, lat1]: [number, number],
  [lon2, lat2]: [number, number]
): number {
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) *
      Math.cos(toRad(lat2)) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return Math.round(EARTH_RADIUS_KM * c);
}

/**
 * Returns the cardinal direction FROM point A TO point B (i.e. where the target lies relative to user's click)
 */
export function getBearingDirection(
  [lon1, lat1]: [number, number],
  [lon2, lat2]: [number, number],
  lang: Language
): string {
  const y = Math.sin(toRad(lon2 - lon1)) * Math.cos(toRad(lat2));
  const x =
    Math.cos(toRad(lat1)) * Math.sin(toRad(lat2)) -
    Math.sin(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.cos(toRad(lon2 - lon1));
  const brng = ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;

  const dirsEn = [
    'North',
    'Northeast',
    'East',
    'Southeast',
    'South',
    'Southwest',
    'West',
    'Northwest',
  ];
  const dirsAr = [
    'الشمال',
    'الشمال الشرقي',
    'الشرق',
    'الجنوب الشرقي',
    'الجنوب',
    'الجنوب الغربي',
    'الغرب',
    'الشمال الغربي',
  ];
  const dirsTr = [
    'Kuzey',
    'Kuzeydoğu',
    'Doğu',
    'Güneydoğu',
    'Güney',
    'Güneybatı',
    'Batı',
    'Kuzeybatı',
  ];
  const index = Math.round(brng / 45) % 8;
  return lang === 'ar' ? dirsAr[index] : lang === 'tr' ? dirsTr[index] : dirsEn[index];
}

export function formatCoords([lon, lat]: [number, number]): string {
  const ns = lat >= 0 ? 'N' : 'S';
  const ew = lon >= 0 ? 'E' : 'W';
  return `${Math.abs(lat).toFixed(1)}°${ns}, ${Math.abs(lon).toFixed(1)}°${ew}`;
}

export interface ContinentViewport {
  center: [number, number]; // [lon, lat]
  zoom: number;
}

export const CONTINENT_VIEWPORTS: Record<ContinentId, ContinentViewport> = {
  all: { center: [12, 18], zoom: 1 },
  africa: { center: [20, 2], zoom: 2.35 },
  asia: { center: [92, 34], zoom: 2.1 },
  europe: { center: [15, 52], zoom: 3.3 },
  north_america: { center: [-98, 42], zoom: 2.2 },
  south_america: { center: [-60, -20], zoom: 2.4 },
  oceania: { center: [140, -24], zoom: 2.7 },
};
