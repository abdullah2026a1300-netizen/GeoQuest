import { geoArea, geoBounds, geoCentroid, geoContains } from 'd3-geo';
import { feature, merge, neighbors as computeTopoNeighbors } from 'topojson-client';
import type { GeometryCollection, Topology } from 'topojson-specification';
import type { Feature, FeatureCollection, Geometry } from 'geojson';
import worldAtlas50m from 'world-atlas/countries-50m.json';
import worldAtlas110m from 'world-atlas/countries-110m.json';

interface CountryProperties {
  name?: string;
}

export type WorldCountryFeature = Feature<Geometry, CountryProperties> & {
  id?: string | number;
};

export interface WorldCountryGeometry {
  key: string;
  id: string;
  rawName: string;
  feat: Feature<Geometry, CountryProperties>;
  bounds: [[number, number], [number, number]];
  center: [number, number];
  area: number;
}

export interface NeighborColorStyle {
  fillSat: string;
  fillVecDark: string;
  fillVecLight: string;
  stroke: string;
  swatch: string;
}

// 14 distinct, high-contrast cartographic colors (emerald reserved for the selected country)
export const NEIGHBOR_COLOR_PALETTE: NeighborColorStyle[] = [
  {
    fillSat: 'rgba(245, 158, 11, 0.44)',
    fillVecDark: '#B45309',
    fillVecLight: '#FDE68A',
    stroke: '#FBBF24',
    swatch: '#F59E0B',
  },
  {
    fillSat: 'rgba(56, 189, 248, 0.44)',
    fillVecDark: '#0369A1',
    fillVecLight: '#BAE6FD',
    stroke: '#7DD3FC',
    swatch: '#38BDF8',
  },
  {
    fillSat: 'rgba(244, 63, 94, 0.44)',
    fillVecDark: '#BE123C',
    fillVecLight: '#FECDD3',
    stroke: '#FDA4AF',
    swatch: '#F43F5E',
  },
  {
    fillSat: 'rgba(168, 85, 247, 0.44)',
    fillVecDark: '#7E22CE',
    fillVecLight: '#E9D5FF',
    stroke: '#D8B4FE',
    swatch: '#A855F7',
  },
  {
    fillSat: 'rgba(249, 115, 22, 0.46)',
    fillVecDark: '#C2410C',
    fillVecLight: '#FED7AA',
    stroke: '#FDBA74',
    swatch: '#F97316',
  },
  {
    fillSat: 'rgba(236, 72, 153, 0.44)',
    fillVecDark: '#BE185D',
    fillVecLight: '#FBCFE8',
    stroke: '#F9A8D4',
    swatch: '#EC4899',
  },
  {
    fillSat: 'rgba(234, 179, 8, 0.44)',
    fillVecDark: '#A16207',
    fillVecLight: '#FEF08A',
    stroke: '#FDE047',
    swatch: '#EAB308',
  },
  {
    fillSat: 'rgba(99, 102, 241, 0.46)',
    fillVecDark: '#4338CA',
    fillVecLight: '#C7D2FE',
    stroke: '#A5B4FC',
    swatch: '#6366F1',
  },
  {
    fillSat: 'rgba(20, 184, 166, 0.44)',
    fillVecDark: '#0F766E',
    fillVecLight: '#99F6E4',
    stroke: '#5EEAD4',
    swatch: '#14B8A6',
  },
  {
    fillSat: 'rgba(132, 204, 22, 0.42)',
    fillVecDark: '#4D7C0F',
    fillVecLight: '#D9F99D',
    stroke: '#BEF264',
    swatch: '#84CC16',
  },
  {
    fillSat: 'rgba(239, 68, 68, 0.44)',
    fillVecDark: '#B91C1C',
    fillVecLight: '#FCA5A5',
    stroke: '#FCA5A5',
    swatch: '#EF4444',
  },
  {
    fillSat: 'rgba(6, 182, 212, 0.44)',
    fillVecDark: '#0E7490',
    fillVecLight: '#A5F3FC',
    stroke: '#67E8F9',
    swatch: '#06B6D4',
  },
  {
    fillSat: 'rgba(217, 70, 239, 0.42)',
    fillVecDark: '#A21CAF',
    fillVecLight: '#F5D0FE',
    stroke: '#F0ABFC',
    swatch: '#D946EF',
  },
  {
    fillSat: 'rgba(59, 130, 246, 0.46)',
    fillVecDark: '#1D4ED8',
    fillVecLight: '#BFDBFE',
    stroke: '#93C5FD',
    swatch: '#3B82F6',
  },
];

const NAMED_FALLBACK_IDS: Record<string, string> = {
  Kosovo: 'XKX',
  Somaliland: 'SML',
  'N. Cyprus': 'NCY',
  'Siachen Glacier': 'SIA',
  'Indian Ocean Ter.': 'IOT',
};

function normalizeId(
  rawId: string | number | undefined,
  rawName: string | undefined,
  idx: number
): string {
  if (rawId === undefined || rawId === null) {
    return (rawName && NAMED_FALLBACK_IDS[rawName]) || `anon-${idx}`;
  }
  const str = String(rawId).padStart(3, '0');
  return str === '376' ? '275' : str;
}

function computeVisualCenter(
  feat: Feature<Geometry, CountryProperties>,
  bounds: [[number, number], [number, number]]
): [number, number] {
  const geom = feat.geometry;
  if (geom && geom.type === 'MultiPolygon' && geom.coordinates.length > 0) {
    let bestPoly = geom.coordinates[0];
    let bestArea = -1;
    for (const coords of geom.coordinates) {
      const a = geoArea({ type: 'Polygon', coordinates: coords });
      if (a > bestArea) {
        bestArea = a;
        bestPoly = coords;
      }
    }
    const c = geoCentroid({ type: 'Polygon', coordinates: bestPoly });
    if (Number.isFinite(c[0]) && Number.isFinite(c[1])) {
      return [c[0], c[1]];
    }
  }
  const c = geoCentroid(feat);
  if (Number.isFinite(c[0]) && Number.isFinite(c[1])) {
    return [c[0], c[1]];
  }
  return [
    (bounds[0][0] + bounds[1][0]) / 2,
    (bounds[0][1] + bounds[1][1]) / 2,
  ];
}

function buildCountriesFromTopology(
  rawTopo: unknown,
  computeBounds: boolean
): {
  countries: WorldCountryGeometry[];
  rawNameMap: Record<string, string>;
  topology: Topology<{ countries: GeometryCollection<CountryProperties> }>;
} {
  const topology = rawTopo as Topology<{
    countries: GeometryCollection<CountryProperties>;
  }>;

  const allGeoms = topology.objects.countries.geometries;
  const palestinePair = allGeoms.filter(
    (g): g is typeof g & { type: 'Polygon' | 'MultiPolygon' } =>
      (String(g.id) === '275' || String(g.id) === '376') &&
      (g.type === 'Polygon' || g.type === 'MultiPolygon')
  );

  const unifiedPalestineGeom =
    palestinePair.length > 0 ? merge(topology, palestinePair) : null;

  const fc = feature(
    topology,
    topology.objects.countries
  ) as unknown as FeatureCollection<Geometry, CountryProperties>;

  const built: WorldCountryGeometry[] = [];
  const rawNameMap: Record<string, string> = {};

  (fc.features as WorldCountryFeature[]).forEach((feat, idx) => {
    const rawName = feat.properties?.name || '';
    const rawId = normalizeId(feat.id, rawName, idx);

    if (rawId === '010') {
      return;
    }

    // Remove separate '376' after normalizing — merged into '275'
    if (feat.id != null && String(feat.id).padStart(3, '0') === '376') {
      return;
    }

    if (rawId === '275' && unifiedPalestineGeom) {
      const palFeat: Feature<Geometry, CountryProperties> = {
        type: 'Feature',
        properties: { name: 'Palestine' },
        geometry: unifiedPalestineGeom,
      };
      rawNameMap['275'] = 'Palestine';
      const bounds = computeBounds ? geoBounds(palFeat) : ([[-180, -90], [180, 90]] as [[number, number], [number, number]]);
      built.push({
        key: '275-unified',
        id: '275',
        rawName: 'Palestine',
        feat: palFeat,
        bounds,
        center: computeBounds ? computeVisualCenter(palFeat, bounds) : [35.2, 31.9],
        area: computeBounds ? geoArea(palFeat) : 0,
      });
      return;
    }

    if (rawName) {
      rawNameMap[rawId] = rawName;
    }

    const bounds = computeBounds ? geoBounds(feat) : ([[-180, -90], [180, 90]] as [[number, number], [number, number]]);
    built.push({
      key: `${rawId}-${idx}`,
      id: rawId,
      rawName,
      feat,
      bounds,
      center: computeBounds ? computeVisualCenter(feat, bounds) : [0, 0],
      area: computeBounds ? geoArea(feat) : 0,
    });
  });

  return { countries: built, rawNameMap, topology };
}

const built50m = buildCountriesFromTopology(worldAtlas50m, true);
const built110m = buildCountriesFromTopology(worldAtlas110m, false);

// Build topological border neighbor map across all countries in world-atlas 50m
const allGeoms50 = built50m.topology.objects.countries.geometries;
const rawAdjIndices = computeTopoNeighbors(allGeoms50);
const topoNeighborsMap: Record<string, Set<string>> = {};

allGeoms50.forEach((geom, idx) => {
  const selfName = (geom.properties as CountryProperties | undefined)?.name;
  const selfId = normalizeId(geom.id, selfName, idx);
  if (selfId === '010') return;
  if (!topoNeighborsMap[selfId]) {
    topoNeighborsMap[selfId] = new Set<string>();
  }
  const adj = rawAdjIndices[idx] || [];
  for (const nIdx of adj) {
    const neighborGeom = allGeoms50[nIdx];
    if (!neighborGeom) continue;
    const neighborName = (neighborGeom.properties as CountryProperties | undefined)?.name;
    const neighborId = normalizeId(neighborGeom.id, neighborName, nIdx);
    if (neighborId !== selfId && neighborId !== '010') {
      topoNeighborsMap[selfId].add(neighborId);
    }
  }
});

export const WORLD_COUNTRIES: WorldCountryGeometry[] = built50m.countries;
export const WORLD_COUNTRIES_FAST: WorldCountryGeometry[] = built110m.countries;
export const RAW_COUNTRY_NAME_BY_ID: Record<string, string> = built50m.rawNameMap;
export const TOPO_NEIGHBORS_BY_ID: Record<string, string[]> = Object.fromEntries(
  Object.entries(topoNeighborsMap).map(([id, set]) => [id, Array.from(set)])
);

export function getCombinedNeighbors(
  countryId: string,
  curatedNeighbors: string[] = []
): string[] {
  const seen = new Set<string>();
  const out: string[] = [];

  const pushId = (raw: string) => {
    const id = raw === '376' ? '275' : raw;
    if (!id || id === countryId || id === '010' || seen.has(id)) return;
    seen.add(id);
    out.push(id);
  };

  for (const id of curatedNeighbors) pushId(id);
  for (const id of TOPO_NEIGHBORS_BY_ID[countryId] ?? []) pushId(id);

  return out;
}

export function findCountryAtLonLat(
  coords: [number, number]
): { id: string; rawName: string } | null {
  const [lon, lat] = coords;
  for (const c of WORLD_COUNTRIES) {
    const [[minLon, minLat], [maxLon, maxLat]] = c.bounds;
    if (lat < minLat - 0.35 || lat > maxLat + 0.35) continue;
    const inLon =
      minLon <= maxLon
        ? lon >= minLon - 0.35 && lon <= maxLon + 0.35
        : lon >= minLon - 0.35 || lon <= maxLon + 0.35;
    if (!inLon) continue;

    if (geoContains(c.feat, coords)) {
      return { id: c.id, rawName: c.rawName };
    }
  }
  return null;
}
