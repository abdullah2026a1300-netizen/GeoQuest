import {
  AchievementDef,
  ContinentId,
  GameMode,
  GameSettings,
  LocalizedText,
  PlayerProfile,
  RoundResult,
} from '../types/game';

const PROFILE_KEY = 'geoquest_player_profile_v1';
const SETTINGS_KEY = 'geoquest_settings_v1';

export const OFFICIAL_YOUTUBE_URL =
  'https://www.youtube.com/channel/UCvHX9jV4cLMzixlFb5oGUnw';

export const DEFAULT_SETTINGS: GameSettings = {
  language: 'ar',
  soundEnabled: true,
  volume: 0.65,
  darkMode: true,
  gameSpeed: 'normal',
  questionCount: 10,
  difficulty: 'mixed',
  youtubeUrl: OFFICIAL_YOUTUBE_URL,
};

export const DEFAULT_PROFILE: PlayerProfile = {
  xp: 0,
  gamesPlayed: 0,
  totalCorrect: 0,
  totalAnswered: 0,
  bestScore: 0,
  bestStreak: 0,
  modeBestScores: {},
  unlockedAchievements: [],
  continentsMastered: [],
  history: [],
};

export const ACHIEVEMENTS: AchievementDef[] = [
  {
    id: 'first_expedition',
    title: { ar: 'أول رحلة استكشافية', en: 'First Expedition', tr: 'İlk Keşif Yolculuğu' },
    description: { ar: 'أكمل أول جولة في GeoQuest.', en: 'Complete your first GeoQuest run.', tr: 'GeoQuest’teki ilk turunu tamamla.' },
    xpReward: 75,
  },
  {
    id: 'streak_5',
    title: { ar: 'بوصلة دقيقة', en: 'True Compass', tr: 'Keskin Pusula' },
    description: { ar: 'حقق سلسلة من 5 إجابات صحيحة متتالية.', en: 'Reach a streak of 5 correct answers in a row.', tr: 'Art arda 5 doğru cevaplık seri yakala.' },
    xpReward: 120,
  },
  {
    id: 'streak_10',
    title: { ar: 'صانع الخرائط', en: 'Master Cartographer', tr: 'Usta Haritacı' },
    description: { ar: 'حقق سلسلة من 10 إجابات صحيحة متتالية.', en: 'Reach a streak of 10 correct answers in a row.', tr: 'Art arda 10 doğru cevaplık seri yakala.' },
    xpReward: 250,
  },
  {
    id: 'sharp_shooter',
    title: { ar: 'دقة متناهية', en: 'Pinpoint Precision', tr: 'Tam İsabet' },
    description: { ar: 'أنهِ جولة بدقة 90% أو أعلى.', en: 'Finish a run with 90% accuracy or higher.', tr: 'Bir turu %90 veya üzeri isabet oranıyla bitir.' },
    xpReward: 180,
  },
  {
    id: 'no_hints_master',
    title: { ar: 'مستكشف بالفطرة', en: 'Pure Navigator', tr: 'Doğuştan Kâşif' },
    description: { ar: 'أكمل جولة كاملة من 10 أسئلة فأكثر دون استخدام أي تلميح.', en: 'Complete a 10+ question run without using a single hint.', tr: 'En az 10 soruluk bir turu hiç ipucu kullanmadan tamamla.' },
    xpReward: 200,
  },
  {
    id: 'score_2000',
    title: { ar: 'صائد النقاط', en: 'High Scorer', tr: 'Puan Avcısı' },
    description: { ar: 'اجمع 2000 نقطة أو أكثر في جولة واحدة.', en: 'Score 2,000+ points in a single expedition.', tr: 'Tek bir keşif turunda 2.000+ puan topla.' },
    xpReward: 220,
  },
  {
    id: 'world_50',
    title: { ar: 'أسطورة تحدي العالم', en: 'World Challenger', tr: 'Dünya Efsanesi' },
    description: { ar: 'أكمل تحدي العالم المكون من 50 سؤالاً.', en: 'Finish the 50-question World Challenge.', tr: '50 soruluk Dünya Meydan Okumasını tamamla.' },
    xpReward: 400,
  },
  {
    id: 'veteran_5',
    title: { ar: 'رحّالة مخضرم', en: 'Seasoned Traveler', tr: 'Deneyimli Gezgin' },
    description: { ar: 'أكمل 5 جولات لعب مختلفة.', en: 'Complete 5 expeditions.', tr: '5 keşif turu tamamla.' },
    xpReward: 150,
  },
];

export interface RankInfo {
  level: number;
  title: LocalizedText;
  currentXpInLevel: number;
  xpForNextLevel: number;
  progressPercent: number;
}

export function getRankInfo(xp: number): RankInfo {
  const level = Math.floor(xp / 500) + 1;
  const currentXpInLevel = xp % 500;
  const xpForNextLevel = 500;
  const progressPercent = Math.min(100, Math.round((currentXpInLevel / xpForNextLevel) * 100));

  let title: LocalizedText = { ar: 'مستكشف مبتدئ', en: 'Beginner Explorer', tr: 'Acemi Kâşif' };
  if (level >= 12) {
    title = { ar: 'مستكشف أسطوري', en: 'Legendary Explorer', tr: 'Efsanevi Kâşif' };
  } else if (level >= 8) {
    title = { ar: 'خبير العالم', en: 'World Expert', tr: 'Dünya Uzmanı' };
  } else if (level >= 5) {
    title = { ar: 'سيد الخرائط', en: 'Map Master', tr: 'Harita Ustası' };
  } else if (level >= 3) {
    title = { ar: 'كشّاف الجغرافيا', en: 'Geography Scout', tr: 'Coğrafya İzci' };
  }

  return {
    level,
    title,
    currentXpInLevel,
    xpForNextLevel,
    progressPercent,
  };
}

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(SETTINGS_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as Partial<GameSettings>;
    return { ...DEFAULT_SETTINGS, ...parsed, youtubeUrl: OFFICIAL_YOUTUBE_URL };
  } catch {
    return DEFAULT_SETTINGS;
  }
}

export function saveSettings(settings: GameSettings): void {
  try {
    localStorage.setItem(
      SETTINGS_KEY,
      JSON.stringify({ ...settings, youtubeUrl: OFFICIAL_YOUTUBE_URL })
    );
  } catch {
    // ignore storage quota failures
  }
}

export function loadProfile(): PlayerProfile {
  try {
    const raw = localStorage.getItem(PROFILE_KEY);
    if (!raw) return DEFAULT_PROFILE;
    return { ...DEFAULT_PROFILE, ...JSON.parse(raw) };
  } catch {
    return DEFAULT_PROFILE;
  }
}

export function saveProfile(profile: PlayerProfile): void {
  try {
    localStorage.setItem(PROFILE_KEY, JSON.stringify(profile));
  } catch {
    // ignore storage quota failures
  }
}

export function resetProfileStorage(): PlayerProfile {
  saveProfile(DEFAULT_PROFILE);
  return DEFAULT_PROFILE;
}

export function recordCompletedRun(params: {
  profile: PlayerProfile;
  mode: GameMode;
  continent: ContinentId;
  score: number;
  results: RoundResult[];
  runBestStreak: number;
}): {
  updatedProfile: PlayerProfile;
  xpEarned: number;
  newlyUnlocked: AchievementDef[];
} {
  const { profile, mode, continent, score, results, runBestStreak } = params;
  const correctCount = results.filter((r) => r.solved).length;
  const totalQuestions = results.length;
  const accuracy = totalQuestions > 0 ? (correctCount / totalQuestions) * 100 : 0;
  const totalHintsUsed = results.reduce((acc, r) => acc + r.hintsUsed, 0);

  let xpEarned = Math.max(25, Math.round(score * 0.18) + correctCount * 15);

  const nextUnlocked = new Set(profile.unlockedAchievements);
  const newlyUnlocked: AchievementDef[] = [];

  const tryUnlock = (id: string) => {
    if (!nextUnlocked.has(id)) {
      const def = ACHIEVEMENTS.find((a) => a.id === id);
      if (def) {
        nextUnlocked.add(id);
        newlyUnlocked.push(def);
        xpEarned += def.xpReward;
      }
    }
  };

  tryUnlock('first_expedition');
  if (runBestStreak >= 5) tryUnlock('streak_5');
  if (runBestStreak >= 10) tryUnlock('streak_10');
  if (totalQuestions >= 5 && accuracy >= 90) tryUnlock('sharp_shooter');
  if (totalQuestions >= 10 && totalHintsUsed === 0 && correctCount >= 7) {
    tryUnlock('no_hints_master');
  }
  if (score >= 2000) tryUnlock('score_2000');
  if (mode === 'world_challenge' && totalQuestions >= 50) tryUnlock('world_50');
  if (profile.gamesPlayed + 1 >= 5) tryUnlock('veteran_5');

  const continentsMastered = [...profile.continentsMastered];
  if (
    continent !== 'all' &&
    accuracy >= 70 &&
    !continentsMastered.includes(continent)
  ) {
    continentsMastered.push(continent);
  }

  const prevModeBest = profile.modeBestScores[mode] ?? 0;

  const updatedProfile: PlayerProfile = {
    xp: profile.xp + xpEarned,
    gamesPlayed: profile.gamesPlayed + 1,
    totalCorrect: profile.totalCorrect + correctCount,
    totalAnswered: profile.totalAnswered + totalQuestions,
    bestScore: Math.max(profile.bestScore, score),
    bestStreak: Math.max(profile.bestStreak, runBestStreak),
    modeBestScores: {
      ...profile.modeBestScores,
      [mode]: Math.max(prevModeBest, score),
    },
    unlockedAchievements: Array.from(nextUnlocked),
    continentsMastered,
    history: [
      {
        id: `${Date.now()}`,
        date: new Date().toISOString(),
        mode,
        score,
        correctCount,
        totalQuestions,
        bestStreak: runBestStreak,
      },
      ...profile.history,
    ].slice(0, 12),
  };

  saveProfile(updatedProfile);
  return { updatedProfile, xpEarned, newlyUnlocked };
}
