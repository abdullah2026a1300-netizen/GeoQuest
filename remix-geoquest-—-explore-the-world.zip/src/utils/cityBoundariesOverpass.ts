import { geoArea, geoCentroid } from 'd3-geo';
import type { Feature, MultiPolygon } from 'geojson';
import type { CityPoint } from '../types/game';

export interface CityBoundaryFeature {
  id: string;
  osmId: number;
  name: string;
  nameAr: string;
  nameEn: string;
  nameTr: string;
  adminLevel: string;
  center: [number, number];
  feature: Feature<MultiPolygon, { id: string; name: string; adminLevel: string }>;
}

interface OverpassLatLon {
  lat: number;
  lon: number;
}

interface OverpassMember {
  type: 'node' | 'way' | 'relation';
  ref: number;
  role: string;
  geometry?: OverpassLatLon[];
}

interface OverpassRelationElement {
  type: 'relation';
  id: number;
  tags?: Record<string, string>;
  members?: OverpassMember[];
  center?: OverpassLatLon;
}

interface OverpassResponse {
  elements?: OverpassRelationElement[];
}

const OVERPASS_ENDPOINTS = [
  'https://overpass-api.de/api/interpreter',
  'https://overpass.kumi.systems/api/interpreter',
  'https://maps.mail.ru/osm/tools/overpass/api/interpreter',
];

const boundaryCache = new Map<string, CityBoundaryFeature[]>();
const MAX_CACHE_ENTRIES = 64;

function saveToCache(key: string, items: CityBoundaryFeature[]) {
  if (boundaryCache.size >= MAX_CACHE_ENTRIES) {
    const firstKey = boundaryCache.keys().next().value;
    if (firstKey !== undefined) boundaryCache.delete(firstKey);
  }
  boundaryCache.set(key, items);
}

/**
 * Exact Overpass QL template for city/district administrative boundaries inside a named area.
 */
export function buildAreaCityBoundariesQuery(
  areaName: string,
  parentAdminLevel = '4',
  childAdminLevel = '8'
): string {
  const safeName = areaName.replace(/"/g, '\\"');
  return `[out:json][timeout:60];
area["name"="${safeName}"]["admin_level"="${parentAdminLevel}"]->.a;
relation["boundary"="administrative"]["admin_level"="${childAdminLevel}"](area.a);
out geom;`;
}

/**
 * Spatial Overpass QL query using coordinates (works worldwide across any language/script).
 * Fetches both admin_level=8 districts inside the enclosing city/province and nearby admin_level 6..9 city borders.
 */
export function buildPointCityBoundariesQuery(lat: number, lon: number): string {
  const fLat = lat.toFixed(5);
  const fLon = lon.toFixed(5);
  return `[out:json][timeout:45];
is_in(${fLat},${fLon})->.a;
area.a["boundary"="administrative"]["admin_level"~"^(4|5|6)$"]->.parent;
(
  relation["boundary"="administrative"]["admin_level"="8"](area.parent);
  relation["boundary"="administrative"]["admin_level"~"^(6|7|8|9)$"](around:16000,${fLat},${fLon});
);
out geom;`;
}

/**
 * Viewport bounding-box Overpass QL query when zoomed into any region of the world map.
 */
export function buildBboxCityBoundariesQuery(
  south: number,
  west: number,
  north: number,
  east: number
): string {
  const s = Math.max(-85, Math.min(85, south)).toFixed(4);
  const n = Math.max(-85, Math.min(85, north)).toFixed(4);
  const w = Math.max(-180, Math.min(180, west)).toFixed(4);
  const e = Math.max(-180, Math.min(180, east)).toFixed(4);
  return `[out:json][timeout:30];
(
  relation["boundary"="administrative"]["admin_level"="8"](${s},${w},${n},${e});
  relation["boundary"="administrative"]["admin_level"="7"](${s},${w},${n},${e});
);
out geom;`;
}

function ptsClose(a: [number, number], b: [number, number], eps = 1e-5): boolean {
  return Math.abs(a[0] - b[0]) <= eps && Math.abs(a[1] - b[1]) <= eps;
}

function decimateRing(ring: [number, number][], maxPts = 300): [number, number][] {
  if (ring.length <= maxPts) return ring;
  const step = Math.ceil(ring.length / maxPts);
  const out: [number, number][] = [];
  for (let i = 0; i < ring.length - 1; i += step) {
    out.push(ring[i]);
  }
  const first = out[0];
  const last = out[out.length - 1];
  if (first && (!last || !ptsClose(first, last, 1e-6))) {
    out.push([first[0], first[1]]);
  }
  return out.length >= 4 ? out : ring;
}

function stitchWaySegmentsToRings(segments: [number, number][][]): [number, number][][] {
  const remaining = segments
    .filter((s) => s.length >= 2)
    .map((s) => s.map((pt) => [pt[0], pt[1]] as [number, number]));
  const rings: [number, number][][] = [];

  while (remaining.length > 0) {
    const chain = remaining.shift()!;
    let extended = true;

    while (extended && remaining.length > 0) {
      extended = false;
      const chainStart = chain[0];
      const chainEnd = chain[chain.length - 1];
      if (ptsClose(chainStart, chainEnd)) break;

      for (let i = 0; i < remaining.length; i++) {
        const seg = remaining[i];
        const segStart = seg[0];
        const segEnd = seg[seg.length - 1];

        if (ptsClose(chainEnd, segStart)) {
          chain.push(...seg.slice(1));
          remaining.splice(i, 1);
          extended = true;
          break;
        }
        if (ptsClose(chainEnd, segEnd)) {
          const rev = [...seg].reverse();
          chain.push(...rev.slice(1));
          remaining.splice(i, 1);
          extended = true;
          break;
        }
        if (ptsClose(chainStart, segEnd)) {
          chain.unshift(...seg.slice(0, -1));
          remaining.splice(i, 1);
          extended = true;
          break;
        }
        if (ptsClose(chainStart, segStart)) {
          const rev = [...seg].reverse();
          chain.unshift(...rev.slice(0, -1));
          remaining.splice(i, 1);
          extended = true;
          break;
        }
      }
    }

    if (chain.length >= 3) {
      if (!ptsClose(chain[0], chain[chain.length - 1])) {
        chain.push([chain[0][0], chain[0][1]]);
      }
      if (chain.length >= 4) {
        const simplified = decimateRing(chain);
        // Ensure d3-geo spherical counter-clockwise outer ring winding
        const testArea = geoArea({
          type: 'Polygon',
          coordinates: [simplified],
        });
        if (testArea > Math.PI * 2) {
          simplified.reverse();
        }
        rings.push(simplified);
      }
    }
  }

  return rings;
}

export function parseOverpassRelationsToBoundaries(
  data: OverpassResponse
): CityBoundaryFeature[] {
  const elements = data?.elements || [];
  const results: CityBoundaryFeature[] = [];
  const seenIds = new Set<number>();

  for (const el of elements) {
    if (el.type !== 'relation' || seenIds.has(el.id)) continue;
    seenIds.add(el.id);

    const members = el.members || [];
    const outerWays: [number, number][][] = [];
    for (const m of members) {
      if (
        m.type === 'way' &&
        (m.role === 'outer' || m.role === '') &&
        Array.isArray(m.geometry) &&
        m.geometry.length >= 2
      ) {
        outerWays.push(m.geometry.map((g) => [g.lon, g.lat] as [number, number]));
      }
    }

    if (outerWays.length === 0) continue;
    const outerRings = stitchWaySegmentsToRings(outerWays);
    if (outerRings.length === 0) continue;

    const tags = el.tags || {};
    const nameDefault = tags.name || tags['name:en'] || tags['name:ar'] || `OSM-${el.id}`;
    const nameAr = tags['name:ar'] || nameDefault;
    const nameEn = tags['name:en'] || tags['int_name'] || nameDefault;
    const nameTr = tags['name:tr'] || nameDefault;
    const adminLevel = tags.admin_level || '8';

    const feature: Feature<MultiPolygon, { id: string; name: string; adminLevel: string }> = {
      type: 'Feature',
      properties: {
        id: `osm-rel-${el.id}`,
        name: nameDefault,
        adminLevel,
      },
      geometry: {
        type: 'MultiPolygon',
        coordinates: outerRings.map((ring) => [ring]),
      },
    };

    const centroid = geoCentroid(feature);
    const center: [number, number] =
      Number.isFinite(centroid[0]) && Number.isFinite(centroid[1])
        ? centroid
        : outerRings[0][0];

    results.push({
      id: `osm-rel-${el.id}`,
      osmId: el.id,
      name: nameDefault,
      nameAr,
      nameEn,
      nameTr,
      adminLevel,
      center,
      feature,
    });
  }

  return results;
}

async function runOverpassQuery(
  query: string,
  signal?: AbortSignal
): Promise<CityBoundaryFeature[]> {
  let lastError: unknown = null;

  for (const endpoint of OVERPASS_ENDPOINTS) {
    try {
      const controller = new AbortController();
      const timeoutId = window.setTimeout(() => controller.abort(), 20000);
      const onExternalAbort = () => controller.abort();
      if (signal) {
        if (signal.aborted) {
          window.clearTimeout(timeoutId);
          throw new DOMException('Aborted', 'AbortError');
        }
        signal.addEventListener('abort', onExternalAbort, { once: true });
      }

      const body = new URLSearchParams({ data: query }).toString();
      const res = await fetch(endpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          Accept: 'application/json',
        },
        body,
        signal: controller.signal,
      });

      window.clearTimeout(timeoutId);
      if (signal) signal.removeEventListener('abort', onExternalAbort);

      if (!res.ok) {
        lastError = new Error(`Overpass HTTP ${res.status}`);
        continue;
      }

      const json = (await res.json()) as OverpassResponse;
      return parseOverpassRelationsToBoundaries(json);
    } catch (err) {
      if (err instanceof DOMException && err.name === 'AbortError' && signal?.aborted) {
        throw err;
      }
      lastError = err;
    }
  }

  if (lastError) {
    throw lastError;
  }
  return [];
}

/**
 * Fetch real OpenStreetMap administrative city/district boundaries for a selected city.
 * Falls back to named area query (admin_level=4 -> admin_level=8) when helpful.
 */
export async function fetchCityBoundariesForCity(
  city: CityPoint,
  signal?: AbortSignal
): Promise<CityBoundaryFeature[]> {
  const [lon, lat] = city.coordinates;
  const cacheKey = `city:${city.id}:${lat.toFixed(3)},${lon.toFixed(3)}`;
  const cached = boundaryCache.get(cacheKey);
  if (cached) return cached;

  const pointQuery = buildPointCityBoundariesQuery(lat, lon);
  let items = await runOverpassQuery(pointQuery, signal);

  if (items.length === 0 && city.name.en) {
    const areaQuery = buildAreaCityBoundariesQuery(city.name.en, '4', '8');
    items = await runOverpassQuery(areaQuery, signal);
  }

  if (items.length > 0) {
    saveToCache(cacheKey, items);
  }
  return items;
}

/**
 * Fetch real OpenStreetMap administrative city/district boundaries inside a visible viewport bounding box.
 */
export async function fetchCityBoundariesForBbox(
  south: number,
  west: number,
  north: number,
  east: number,
  signal?: AbortSignal
): Promise<CityBoundaryFeature[]> {
  // Clamp query span so Overpass never times out over continental areas
  const latSpan = Math.abs(north - south);
  const lonSpan = Math.abs(east - west);
  if (latSpan > 8 || lonSpan > 11) {
    return [];
  }

  const cacheKey = `bbox:${south.toFixed(1)},${west.toFixed(1)},${north.toFixed(1)},${east.toFixed(1)}`;
  const cached = boundaryCache.get(cacheKey);
  if (cached) return cached;

  const query = buildBboxCityBoundariesQuery(south, west, north, east);
  const items = await runOverpassQuery(query, signal);
  saveToCache(cacheKey, items);
  return items;
}
