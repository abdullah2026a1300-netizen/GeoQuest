import { COUNTRY_META_EXTRA } from '../data/millionCategories';

const ISO_NUMERIC_TO_ALPHA2: Record<string, string> = {
  '004': 'af', '008': 'al', '012': 'dz', '016': 'as', '020': 'ad', '024': 'ao',
  '028': 'ag', '031': 'az', '032': 'ar', '036': 'au', '040': 'at', '044': 'bs',
  '048': 'bh', '050': 'bd', '051': 'am', '052': 'bb', '056': 'be', '060': 'bm',
  '064': 'bt', '068': 'bo', '070': 'ba', '072': 'bw', '076': 'br', '084': 'bz',
  '086': 'io', '090': 'sb', '092': 'vg', '096': 'bn', '100': 'bg', '104': 'mm',
  '108': 'bi', '112': 'by', '116': 'kh', '120': 'cm', '124': 'ca', '132': 'cv',
  '136': 'ky', '140': 'cf', '144': 'lk', '148': 'td', '152': 'cl', '156': 'cn',
  '158': 'tw', '170': 'co', '174': 'km', '175': 'yt', '178': 'cg', '180': 'cd',
  '184': 'ck', '188': 'cr', '191': 'hr', '192': 'cu', '196': 'cy', '203': 'cz',
  '204': 'bj', '208': 'dk', '212': 'dm', '214': 'do', '218': 'ec', '222': 'sv',
  '226': 'gq', '231': 'et', '232': 'er', '233': 'ee', '234': 'fo', '238': 'fk',
  '239': 'gs', '242': 'fj', '246': 'fi', '248': 'ax', '250': 'fr', '258': 'pf',
  '260': 'tf', '262': 'dj', '266': 'ga', '268': 'ge', '270': 'gm', '275': 'ps',
  '276': 'de', '288': 'gh', '292': 'gi', '296': 'ki', '300': 'gr', '304': 'gl',
  '308': 'gd', '316': 'gu', '320': 'gt', '324': 'gn', '328': 'gy', '332': 'ht',
  '334': 'hm', '336': 'va', '340': 'hn', '344': 'hk', '348': 'hu', '352': 'is',
  '356': 'in', '360': 'id', '364': 'ir', '368': 'iq', '372': 'ie', '380': 'it',
  '384': 'ci', '388': 'jm', '392': 'jp', '398': 'kz', '400': 'jo', '404': 'ke',
  '408': 'kp', '410': 'kr', '414': 'kw', '417': 'kg', '418': 'la', '422': 'lb',
  '426': 'ls', '428': 'lv', '430': 'lr', '434': 'ly', '438': 'li', '440': 'lt',
  '442': 'lu', '446': 'mo', '450': 'mg', '454': 'mw', '458': 'my', '462': 'mv',
  '466': 'ml', '470': 'mt', '478': 'mr', '480': 'mu', '484': 'mx', '492': 'mc',
  '496': 'mn', '498': 'md', '499': 'me', '500': 'ms', '504': 'ma', '508': 'mz',
  '512': 'om', '516': 'na', '520': 'nr', '524': 'np', '528': 'nl', '531': 'cw',
  '533': 'aw', '534': 'sx', '540': 'nc', '548': 'vu', '554': 'nz', '558': 'ni',
  '562': 'ne', '566': 'ng', '570': 'nu', '574': 'nf', '578': 'no', '580': 'mp',
  '583': 'fm', '584': 'mh', '585': 'pw', '586': 'pk', '591': 'pa', '598': 'pg',
  '600': 'py', '604': 'pe', '608': 'ph', '612': 'pn', '616': 'pl', '620': 'pt',
  '624': 'gw', '626': 'tl', '630': 'pr', '634': 'qa', '642': 'ro', '643': 'ru',
  '646': 'rw', '652': 'bl', '654': 'sh', '659': 'kn', '660': 'ai', '662': 'lc',
  '663': 'mf', '666': 'pm', '670': 'vc', '674': 'sm', '678': 'st', '682': 'sa',
  '686': 'sn', '688': 'rs', '690': 'sc', '694': 'sl', '702': 'sg', '703': 'sk',
  '704': 'vn', '705': 'si', '706': 'so', '710': 'za', '716': 'zw', '724': 'es',
  '728': 'ss', '729': 'sd', '732': 'eh', '740': 'sr', '748': 'sz', '752': 'se',
  '756': 'ch', '760': 'sy', '762': 'tj', '764': 'th', '768': 'tg', '776': 'to',
  '780': 'tt', '784': 'ae', '788': 'tn', '792': 'tr', '795': 'tm', '796': 'tc',
  '798': 'tv', '800': 'ug', '804': 'ua', '807': 'mk', '818': 'eg', '826': 'gb',
  '831': 'gg', '832': 'je', '833': 'im', '834': 'tz', '840': 'us', '850': 'vi',
  '854': 'bf', '858': 'uy', '860': 'uz', '862': 've', '876': 'wf', '882': 'ws',
  '887': 'ye', '894': 'zm',
  XKX: 'xk',
};

export function iso2ToFlagEmoji(iso2: string): string {
  if (!iso2 || iso2.length !== 2) return '🏳️';
  const upper = iso2.toUpperCase();
  const c1 = upper.charCodeAt(0) - 65 + 0x1f1e6;
  const c2 = upper.charCodeAt(1) - 65 + 0x1f1e6;
  return String.fromCodePoint(c1, c2);
}

export function flagEmojiToIso2(flagEmoji?: string): string | null {
  if (!flagEmoji) return null;
  const cps = [...flagEmoji].map((c) => c.codePointAt(0) || 0);
  if (cps.length === 2 && cps[0] >= 0x1f1e6 && cps[0] <= 0x1f1ff && cps[1] >= 0x1f1e6 && cps[1] <= 0x1f1ff) {
    return (
      String.fromCharCode(cps[0] - 0x1f1e6 + 97) +
      String.fromCharCode(cps[1] - 0x1f1e6 + 97)
    );
  }
  return null;
}

export function getCountryAlpha2(countryId?: string | null): string | null {
  if (!countryId) return null;
  const mapped = ISO_NUMERIC_TO_ALPHA2[countryId];
  if (mapped) return mapped;
  const extra = COUNTRY_META_EXTRA[countryId];
  if (extra?.flag) {
    return flagEmojiToIso2(extra.flag);
  }
  return null;
}

export function getCountryFlagEmoji(countryId?: string | null): string | null {
  if (!countryId) return null;
  const extra = COUNTRY_META_EXTRA[countryId];
  if (extra?.flag) return extra.flag;
  const iso2 = ISO_NUMERIC_TO_ALPHA2[countryId];
  return iso2 ? iso2ToFlagEmoji(iso2) : null;
}
